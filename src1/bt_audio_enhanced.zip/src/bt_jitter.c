
#include "bt_jitter.h"
#include <string.h>

#define JB_SIZE 64

static bt_audio_packet_t buf[JB_SIZE];
static int head=0, tail=0;

void jb_init(){ head=tail=0; }

int jb_push(bt_audio_packet_t *p){
    buf[head]=*p;
    head=(head+1)%JB_SIZE;
    return 0;
}

int jb_pop(bt_audio_packet_t *p){
    if(head==tail) return -1;
    *p = buf[tail];
    tail=(tail+1)%JB_SIZE;
    return 0;
}
