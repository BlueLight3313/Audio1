#ifndef BT_PAIR_H
#define BT_PAIR_H

#include "bt_common.h"

void bt_pair_options_init(bt_pair_options_t *options);
bt_pair_result_t bt_pair_bredr(int adapter_index, const char *mac,
                               const bt_pair_options_t *options);

#endif
