
#include <stdio.h>
#include <string.h>
#include "../include/bt.h"

void run_server();

int main(int argc,char**argv){

    if(argc<2){
        printf("Usage: scan | pair MAC | connect MAC | server\n");
        return 0;
    }

    if(!strcmp(argv[1],"scan")){
        bt_scan(0,8);
    }
    else if(!strcmp(argv[1],"pair")){
        bt_result_t r=bt_pair(0,argv[2]);
        printf("PAIR RESULT=%d\n",r.status);
    }
    else if(!strcmp(argv[1],"connect")){
        bt_connect(argv[2]);
    }
    else if(!strcmp(argv[1],"server")){
        run_server();
    }

    return 0;
}
