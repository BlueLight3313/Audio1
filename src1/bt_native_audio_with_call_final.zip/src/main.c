
#include <stdio.h>
#include <string.h>
#include "bt_call.h"

int main(){
 char cmd[128]; char id[]="DEV001";
 bt_call_init();
 while(1){
  printf("bt> "); fgets(cmd,128,stdin);
  if(strncmp(cmd,"dial",4)==0) bt_call_dial(cmd+5,id);
  else if(strncmp(cmd,"incoming",8)==0) bt_call_incoming(cmd+9,"REMOTE");
  else if(strncmp(cmd,"answer",6)==0) bt_call_accept();
  else if(strncmp(cmd,"reject",6)==0) bt_call_reject();
  else if(strncmp(cmd,"hangup",6)==0) bt_call_hangup();
  else if(strncmp(cmd,"status",6)==0) bt_call_print();
  else if(strncmp(cmd,"quit",4)==0) break;
 }
}
