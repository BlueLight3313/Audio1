
#ifndef BT_SCAN_H
#define BT_SCAN_H

#include <stddef.h>

int bt_scan_nearby_devices(int hci_sock, unsigned int duration_units_1_28s);

#endif
