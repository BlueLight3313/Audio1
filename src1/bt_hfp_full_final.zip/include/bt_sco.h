
#ifndef BT_SCO_H
#define BT_SCO_H
int bt_sco_connect(const char *mac);
#endif
