#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "../include/bt_scan.h"
#include "../include/bt_pair.h"
#include "../include/bt_connect.h"
#include "../include/bt_mgmt.h"

static void print_usage(const char *prog)
{
    printf("Usage:\n");
    printf("  %s scan [adapter] [seconds]\n", prog);
    printf("  %s pair <MAC> [adapter] [--io-cap N] [--pin CODE] [--passkey N] [--confirm yes|no] [--timeout-ms N] [--allow-no-link-key yes|no]\n", prog);
    printf("  %s connect <MAC> [adapter] [--verify-timeout-ms N] [--hold-ms N]\n", prog);
}

static int parse_yes_no(const char *value, int *out)
{
    if (!value || !out)
        return -1;

    if (strcmp(value, "yes") == 0 || strcmp(value, "true") == 0 || strcmp(value, "1") == 0) {
        *out = 1;
        return 0;
    }

    if (strcmp(value, "no") == 0 || strcmp(value, "false") == 0 || strcmp(value, "0") == 0) {
        *out = 0;
        return 0;
    }

    return -1;
}

static void print_scan_result(const bt_scan_result_t *r)
{
    int i;

    printf("SCAN status=%s mgmt_status=0x%02X (%s) found=%d\n",
           bt_status_str(r->status), r->mgmt_status, bt_mgmt_status_str(r->mgmt_status), r->count);

    for (i = 0; i < r->count; ++i) {
        printf("[%d] MAC=%s NAME=%s RSSI=%d ADDR_TYPE=%u FLAGS=0x%08X\n",
               i,
               r->entries[i].mac,
               r->entries[i].name[0] ? r->entries[i].name : "unknown",
               r->entries[i].rssi,
               r->entries[i].addr_type,
               r->entries[i].flags);
    }
}

static void print_pair_result(const bt_pair_result_t *r)
{
    printf("PAIR status=%s mgmt_status=0x%02X (%s) bonded=%d new_link_key=%d auth_failed=%d cancelled=%d connected=%d detail=%s\n",
           bt_status_str(r->status),
           r->mgmt_status,
           bt_mgmt_status_str(r->mgmt_status),
           r->bonded,
           r->new_link_key_seen,
           r->auth_failed,
           r->cancelled,
           r->connected,
           r->detail);
}

static void print_connect_result(const bt_connect_result_t *r)
{
    printf("CONNECT status=%s mgmt_status=0x%02X (%s) already_connected=%d transport_socket_connected=%d mgmt_connected_verified=%d detail=%s\n",
           bt_status_str(r->status),
           r->mgmt_status,
           bt_mgmt_status_str(r->mgmt_status),
           r->already_connected,
           r->transport_socket_connected,
           r->mgmt_connected_verified,
           r->detail);
}

int main(int argc, char **argv)
{
    if (argc < 2) {
        print_usage(argv[0]);
        return 1;
    }

    if (strcmp(argv[1], "scan") == 0) {
        int adapter = 0;
        int seconds = 8;
        bt_scan_result_t r;

        if (argc >= 3)
            adapter = atoi(argv[2]);
        if (argc >= 4)
            seconds = atoi(argv[3]);

        r = bt_scan_bredr(adapter, seconds);
        print_scan_result(&r);
        return (r.status == BT_STATUS_OK) ? 0 : 1;
    }

    if (strcmp(argv[1], "pair") == 0) {
        int adapter = 0;
        int i;
        bt_pair_options_t options;
        bt_pair_result_t r;

        if (argc < 3) {
            print_usage(argv[0]);
            return 1;
        }

        bt_pair_options_init(&options);

        if (argc >= 4 && argv[3][0] != '-')
            adapter = atoi(argv[3]);

        for (i = 3; i < argc; ++i) {
            if (strcmp(argv[i], "--io-cap") == 0 && i + 1 < argc) {
                options.io_capability = (uint8_t)atoi(argv[++i]);
            } else if (strcmp(argv[i], "--pin") == 0 && i + 1 < argc) {
                strncpy(options.pin, argv[++i], sizeof(options.pin) - 1);
                options.has_pin = 1;
            } else if (strcmp(argv[i], "--passkey") == 0 && i + 1 < argc) {
                options.passkey = (uint32_t)strtoul(argv[++i], NULL, 10);
                options.has_passkey = 1;
            } else if (strcmp(argv[i], "--confirm") == 0 && i + 1 < argc) {
                if (parse_yes_no(argv[++i], &options.auto_confirm) < 0) {
                    fprintf(stderr, "invalid value for --confirm\n");
                    return 1;
                }
            } else if (strcmp(argv[i], "--timeout-ms") == 0 && i + 1 < argc) {
                options.timeout_ms = atoi(argv[++i]);
            } else if (strcmp(argv[i], "--allow-no-link-key") == 0 && i + 1 < argc) {
                int v = 0;
                if (parse_yes_no(argv[++i], &v) < 0) {
                    fprintf(stderr, "invalid value for --allow-no-link-key\n");
                    return 1;
                }
                options.require_new_link_key = v ? 0 : 1;
            }
        }

        r = bt_pair_bredr(adapter, argv[2], &options);
        print_pair_result(&r);
        return (r.status == BT_STATUS_OK || r.status == BT_STATUS_ALREADY) ? 0 : 1;
    }

    if (strcmp(argv[1], "connect") == 0) {
        int adapter = 0;
        int verify_timeout_ms = 2000;
        int hold_ms = 0;
        int i;
        bt_connect_result_t r;

        if (argc < 3) {
            print_usage(argv[0]);
            return 1;
        }

        if (argc >= 4 && argv[3][0] != '-')
            adapter = atoi(argv[3]);

        for (i = 3; i < argc; ++i) {
            if (strcmp(argv[i], "--verify-timeout-ms") == 0 && i + 1 < argc) {
                verify_timeout_ms = atoi(argv[++i]);
            } else if (strcmp(argv[i], "--hold-ms") == 0 && i + 1 < argc) {
                hold_ms = atoi(argv[++i]);
            }
        }

        r = bt_connect_bredr_generic(adapter, argv[2], verify_timeout_ms, hold_ms);
        print_connect_result(&r);
        return (r.status == BT_STATUS_OK || r.status == BT_STATUS_ALREADY) ? 0 : 1;
    }

    print_usage(argv[0]);
    return 1;
}
