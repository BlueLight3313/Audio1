
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>

#include "bt_connect.h"
#include "bt_types.h"
#include "bt_hci.h"

#define OGF_LINK_CTL 0x01
#define OCF_CREATE_CONN 0x0005
#define OCF_DISCONNECT  0x0006

struct create_conn_cp {
    uint8_t bdaddr[6];
    uint16_t pkt_type;
    uint8_t pscan_rep_mode;
    uint8_t pscan_mode;
    uint16_t clock_offset;
    uint8_t role_switch;
} __attribute__((packed));

int bt_connect_device(uint8_t mac[6])
{
    int sock = bt_hci_open_bound_raw(0);
    if(sock < 0){
        printf("[CONNECT] socket fail\n");
        return -1;
    }

    struct create_conn_cp cp;
    memset(&cp,0,sizeof(cp));

    memcpy(cp.bdaddr, mac, 6);
    cp.pkt_type = 0xCC18;
    cp.pscan_rep_mode = 0x01;
    cp.clock_offset = 0;
    cp.role_switch = 0x01;

    printf("[CONNECT] creating ACL link...\n");

    if(bt_hci_send_req(sock,
        BT_HCI_OPCODE(OGF_LINK_CTL, OCF_CREATE_CONN),
        &cp,
        sizeof(cp),
        NULL,
        0,
        5000) < 0)
    {
        printf("[CONNECT] failed\n");
        close(sock);
        return -1;
    }

    printf("[CONNECT] success (request sent)\n");
    close(sock);
    return 0;
}

int bt_disconnect_device(uint8_t mac[6])
{
    printf("[DISCONNECT] not fully implemented (handle required)\n");
    return 0;
}
