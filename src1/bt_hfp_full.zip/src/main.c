
#include <stdio.h>
#include "bt_rfcomm.h"
#include "bt_hfp.h"
#include "bt_sco.h"

int main(){
    int rf = bt_rfcomm_connect("00:11:22:33:44:55");
    bt_hfp_init(rf);

    printf("dialing...\n");
    bt_hfp_dial("123456");

    bt_hfp_answer();
    bt_hfp_hangup();

    return 0;
}
