
#include <stdio.h>

int bt_rfcomm_server_start(unsigned char*);
int bt_rfcomm_accept(int);
int bt_sdp_register_ag(unsigned char);
void bt_hfp_ag_run(int,const char*);

int main(){
    unsigned char ch;
    int server = bt_rfcomm_server_start(&ch);

    bt_sdp_register_ag(ch);

    int client = bt_rfcomm_accept(server);
    printf("Client connected\n");

    bt_hfp_ag_run(client,"00:11:22:33:44:55");

    return 0;
}
