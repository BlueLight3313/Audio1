
#include <stdio.h>
#include <string.h>
#include "bt_device.h"
#include "bt_classify.h"

static bt_dev_t devs[BT_MAX_DEV];
static int count=0;

static void mac_to_str(uint8_t m[6], char* out){
    sprintf(out,"%02X:%02X:%02X:%02X:%02X:%02X",
        m[5],m[4],m[3],m[2],m[1],m[0]);
}

void bt_dev_add(uint8_t mac[6], uint8_t cod[3]){
    if(count>=BT_MAX_DEV) return;

    memcpy(devs[count].mac,mac,6);
    memcpy(devs[count].cod,cod,3);
    mac_to_str(mac,devs[count].mac_str);

    devs[count].type=bt_classify_cod(cod);
    devs[count].policy=bt_recommend_policy(devs[count].type);

    count++;
}

void bt_dev_print_all(){
    for(int i=0;i<count;i++){
        printf("[%d] %s type=%s policy=%s\n",
            i,
            devs[i].mac_str,
            bt_type_str(devs[i].type),
            bt_policy_str(devs[i].policy));
    }
}

bt_dev_t* bt_dev_get(int idx){
    if(idx<0 || idx>=count) return NULL;
    return &devs[idx];
}
