#ifndef BT_COMPAT_BLUETOOTH_H
#define BT_COMPAT_BLUETOOTH_H

#include <stdint.h>
#include <sys/socket.h>

#ifndef AF_BLUETOOTH
#define AF_BLUETOOTH 31
#endif

#ifndef PF_BLUETOOTH
#define PF_BLUETOOTH AF_BLUETOOTH
#endif

#ifndef BTPROTO_L2CAP
#define BTPROTO_L2CAP 0
#endif

#ifndef BTPROTO_HCI
#define BTPROTO_HCI 1
#endif

typedef struct {
    uint8_t b[6];
} __attribute__((packed)) bdaddr_t;

void bt_bacpy(bdaddr_t *dst, const bdaddr_t *src);
int bt_str2ba(const char *str, bdaddr_t *ba);
void bt_ba2str(const bdaddr_t *ba, char *str);

#endif
