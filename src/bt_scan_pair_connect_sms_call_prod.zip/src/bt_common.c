#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <poll.h>
#include <sys/socket.h>

#include "../include/bt_common.h"
#include "../include/bt_mgmt.h"

const char *bt_status_str(bt_status_t status)
{
    switch (status) {
    case BT_STATUS_OK: return "OK";
    case BT_STATUS_FAIL: return "FAIL";
    case BT_STATUS_TIMEOUT: return "TIMEOUT";
    case BT_STATUS_NOT_FOUND: return "NOT_FOUND";
    case BT_STATUS_PROTOCOL: return "PROTOCOL_ERROR";
    case BT_STATUS_REMOTE: return "REMOTE_ERROR";
    case BT_STATUS_ALREADY: return "ALREADY";
    case BT_STATUS_NOT_PAIRED: return "NOT_PAIRED";
    default: return "UNKNOWN";
    }
}

const char *bt_mgmt_status_str(uint8_t status)
{
    switch (status) {
    case MGMT_STATUS_SUCCESS: return "Success";
    case MGMT_STATUS_UNKNOWN_COMMAND: return "Unknown Command";
    case MGMT_STATUS_NOT_CONNECTED: return "Not Connected";
    case MGMT_STATUS_FAILED: return "Failed";
    case MGMT_STATUS_CONNECT_FAILED: return "Connect Failed";
    case MGMT_STATUS_AUTH_FAILED: return "Authentication Failed";
    case MGMT_STATUS_NOT_PAIRED: return "Not Paired";
    case MGMT_STATUS_NO_RESOURCES: return "No Resources";
    case MGMT_STATUS_TIMEOUT: return "Timeout";
    case MGMT_STATUS_ALREADY_CONNECTED: return "Already Connected";
    case MGMT_STATUS_BUSY: return "Busy";
    case MGMT_STATUS_REJECTED: return "Rejected";
    case MGMT_STATUS_NOT_SUPPORTED: return "Not Supported";
    case MGMT_STATUS_INVALID_PARAMS: return "Invalid Parameters";
    case MGMT_STATUS_DISCONNECTED: return "Disconnected";
    case MGMT_STATUS_NOT_POWERED: return "Not Powered";
    case MGMT_STATUS_CANCELLED: return "Cancelled";
    case MGMT_STATUS_INVALID_INDEX: return "Invalid Index";
    case MGMT_STATUS_RFKILLED: return "RFKilled";
    case MGMT_STATUS_ALREADY_PAIRED: return "Already Paired";
    case MGMT_STATUS_PERMISSION_DENIED: return "Permission Denied";
    default: return "Unknown Status";
    }
}

uint16_t bt_cpu_to_le16(uint16_t v)
{
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    return v;
#else
    return (uint16_t)((v << 8) | (v >> 8));
#endif
}

uint16_t bt_le16_to_cpu(uint16_t v)
{
    return bt_cpu_to_le16(v);
}

uint32_t bt_cpu_to_le32(uint32_t v)
{
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    return v;
#else
    return ((v & 0x000000FFU) << 24) |
           ((v & 0x0000FF00U) << 8) |
           ((v & 0x00FF0000U) >> 8) |
           ((v & 0xFF000000U) >> 24);
#endif
}

uint32_t bt_le32_to_cpu(uint32_t v)
{
    return bt_cpu_to_le32(v);
}

int bt_open_mgmt_socket(void)
{
    int sock;
    struct sockaddr_hci addr;

    sock = socket(AF_BLUETOOTH, SOCK_RAW, BTPROTO_HCI);
    if (sock < 0)
        return -1;

    memset(&addr, 0, sizeof(addr));
    addr.hci_family = AF_BLUETOOTH;
    addr.hci_dev = HCI_DEV_NONE;
    addr.hci_channel = HCI_CHANNEL_CONTROL;

    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        close(sock);
        return -1;
    }

    return sock;
}

int bt_send_mgmt_cmd(int sock, uint16_t opcode, uint16_t index,
                     const void *payload, uint16_t payload_len)
{
    uint8_t buf[1024];
    struct mgmt_hdr *hdr;

    if ((size_t)payload_len + sizeof(struct mgmt_hdr) > sizeof(buf))
        return -1;

    hdr = (struct mgmt_hdr *)buf;
    hdr->opcode = bt_cpu_to_le16(opcode);
    hdr->index = bt_cpu_to_le16(index);
    hdr->len = bt_cpu_to_le16(payload_len);

    if (payload_len && payload)
        memcpy(buf + sizeof(*hdr), payload, payload_len);

    if (write(sock, buf, sizeof(*hdr) + payload_len) < 0)
        return -1;

    return 0;
}

int bt_wait_mgmt_cmd_result(int sock, uint16_t want_opcode, uint16_t want_index,
                            uint8_t *out_status, uint8_t *out_data,
                            size_t *out_data_len, int timeout_ms)
{
    struct pollfd pfd;
    uint8_t buf[2048];

    pfd.fd = sock;
    pfd.events = POLLIN;

    while (1) {
        int pr = poll(&pfd, 1, timeout_ms);
        if (pr < 0)
            return -1;
        if (pr == 0)
            return -1;

        if (pfd.revents & POLLIN) {
            ssize_t n = read(sock, buf, sizeof(buf));
            struct mgmt_hdr *hdr;
            uint16_t evt, idx, len;

            if (n < (ssize_t)sizeof(struct mgmt_hdr))
                continue;

            hdr = (struct mgmt_hdr *)buf;
            evt = bt_le16_to_cpu(hdr->opcode);
            idx = bt_le16_to_cpu(hdr->index);
            len = bt_le16_to_cpu(hdr->len);

            if (want_index != MGMT_INDEX_NONE && idx != want_index)
                continue;

            if (evt == MGMT_EV_CMD_COMPLETE) {
                struct mgmt_ev_cmd_complete *cc;
                uint16_t cmd_opcode;
                size_t data_len;

                if (len < sizeof(*cc))
                    continue;

                cc = (struct mgmt_ev_cmd_complete *)(buf + sizeof(*hdr));
                cmd_opcode = bt_le16_to_cpu(cc->opcode);
                if (cmd_opcode != want_opcode)
                    continue;

                if (out_status)
                    *out_status = cc->status;

                data_len = len - sizeof(*cc);
                if (out_data_len)
                    *out_data_len = data_len;

                if (out_data && out_data_len)
                    memcpy(out_data, cc->data, data_len);

                return 0;
            }

            if (evt == MGMT_EV_CMD_STATUS) {
                struct mgmt_ev_cmd_status *cs;
                uint16_t cmd_opcode;

                if (len < sizeof(*cs))
                    continue;

                cs = (struct mgmt_ev_cmd_status *)(buf + sizeof(*hdr));
                cmd_opcode = bt_le16_to_cpu(cs->opcode);
                if (cmd_opcode != want_opcode)
                    continue;

                if (out_status)
                    *out_status = cs->status;
                if (out_data_len)
                    *out_data_len = 0;
                return 0;
            }
        }
    }
}

int bt_eir_extract_name(const uint8_t *eir, size_t eir_len,
                        char *name, size_t name_sz)
{
    size_t i = 0;

    if (!name || name_sz == 0)
        return -1;

    name[0] = '\0';

    while (i + 1 < eir_len) {
        uint8_t field_len = eir[i];
        uint8_t field_type;

        if (field_len == 0)
            break;

        if (i + 1 + field_len > eir_len)
            break;

        field_type = eir[i + 1];

        if (field_type == 0x09 || field_type == 0x08) {
            size_t copy_len = field_len - 1;
            if (copy_len >= name_sz)
                copy_len = name_sz - 1;

            memcpy(name, &eir[i + 2], copy_len);
            name[copy_len] = '\0';
            return 0;
        }

        i += (size_t)field_len + 1;
    }

    snprintf(name, name_sz, "unknown");
    return -1;
}

int bt_addr_equals(const bdaddr_t *a, const bdaddr_t *b)
{
    return memcmp(a, b, sizeof(*a)) == 0;
}
