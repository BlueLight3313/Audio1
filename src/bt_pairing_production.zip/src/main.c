#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../include/bt_pair_engine.h"

static void print_usage(const char *prog)
{
    printf("Usage:\n");
    printf("  %s pair <MAC> [options]\n", prog);
    printf("Options:\n");
    printf("  --adapter <index>\n");
    printf("  --pin <code>\n");
    printf("  --passkey <0-999999>\n");
    printf("  --confirm yes|no\n");
    printf("  --io-cap displayonly|displayyesno|keyboardonly|noinputnooutput|keyboarddisplay\n");
    printf("  --timeout-ms <milliseconds>\n");
    printf("  --non-interactive\n");
    printf("  --allow-no-link-key\n");
    printf("\n");
    printf("Examples:\n");
    printf("  sudo %s pair AA:BB:CC:DD:EE:FF --pin 0000\n", prog);
    printf("  sudo %s pair AA:BB:CC:DD:EE:FF --confirm yes --io-cap displayyesno\n", prog);
    printf("  sudo %s pair AA:BB:CC:DD:EE:FF --passkey 123456 --io-cap keyboardonly\n", prog);
}

static int parse_io_cap(const char *value, bt_io_capability_t *cap)
{
    if (strcmp(value, "displayonly") == 0) {
        *cap = BT_IO_CAP_DISPLAY_ONLY;
        return 0;
    }
    if (strcmp(value, "displayyesno") == 0) {
        *cap = BT_IO_CAP_DISPLAY_YES_NO;
        return 0;
    }
    if (strcmp(value, "keyboardonly") == 0) {
        *cap = BT_IO_CAP_KEYBOARD_ONLY;
        return 0;
    }
    if (strcmp(value, "noinputnooutput") == 0) {
        *cap = BT_IO_CAP_NO_INPUT_NO_OUTPUT;
        return 0;
    }
    if (strcmp(value, "keyboarddisplay") == 0) {
        *cap = BT_IO_CAP_KEYBOARD_DISPLAY;
        return 0;
    }
    return -1;
}

static void print_report(const bt_pair_report_t *r)
{
    printf("PAIR_RESULT=%s\n", bt_pair_result_code_str(r->code));
    printf("MGMT_STATUS=0x%02X (%s)\n", r->mgmt_status, bt_mgmt_status_str(r->mgmt_status));
    printf("TARGET=%s\n", r->target_mac);
    printf("PIN_REQUESTED=%d\n", r->pin_requested);
    printf("PIN_REPLIED=%d\n", r->pin_replied);
    printf("CONFIRM_REQUESTED=%d\n", r->confirm_requested);
    printf("CONFIRM_REPLIED=%d\n", r->confirm_replied);
    printf("PASSKEY_REQUESTED=%d\n", r->passkey_requested);
    printf("PASSKEY_REPLIED=%d\n", r->passkey_replied);
    printf("AUTH_FAILED=%d\n", r->auth_failed);
    printf("LINK_KEY_SEEN=%d\n", r->link_key_seen);
    printf("LINK_KEY_TYPE=%u\n", (unsigned)r->link_key_type);
    printf("LINK_KEY_PIN_LENGTH=%u\n", (unsigned)r->link_key_pin_length);
    printf("LINK_KEY_STORE_HINT=%u\n", (unsigned)r->link_key_store_hint);
    printf("CANCELLED_BY_LOCAL=%d\n", r->cancelled_by_local);
    printf("CANCELLED_BY_REMOTE_OR_STACK=%d\n", r->cancelled_by_remote_or_stack);
    printf("PAIR_CMD_COMPLETE=%d\n", r->command_complete_seen);
    printf("PAIR_CMD_STATUS=%d\n", r->command_status_seen);
}

int main(int argc, char **argv)
{
    bt_pair_options_t opt;
    bt_pair_report_t report;
    const char *mac;
    int i;
    int rc;

    bt_pair_options_init(&opt);

    if (argc < 3 || strcmp(argv[1], "pair") != 0) {
        print_usage(argv[0]);
        return 1;
    }

    mac = argv[2];

    for (i = 3; i < argc; ++i) {
        if (strcmp(argv[i], "--adapter") == 0 && i + 1 < argc) {
            opt.adapter_index = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--pin") == 0 && i + 1 < argc) {
            strncpy(opt.pin_code, argv[++i], sizeof(opt.pin_code) - 1);
            opt.pin_code[sizeof(opt.pin_code) - 1] = '\0';
            opt.has_pin_code = 1;
        } else if (strcmp(argv[i], "--passkey") == 0 && i + 1 < argc) {
            opt.passkey = (uint32_t)strtoul(argv[++i], NULL, 10);
            opt.has_passkey = 1;
        } else if (strcmp(argv[i], "--confirm") == 0 && i + 1 < argc) {
            ++i;
            if (strcmp(argv[i], "yes") == 0) {
                opt.confirm_default_yes = 1;
                opt.has_confirm_default = 1;
            } else if (strcmp(argv[i], "no") == 0) {
                opt.confirm_default_yes = 0;
                opt.has_confirm_default = 1;
            } else {
                fprintf(stderr, "Invalid --confirm value\n");
                return 2;
            }
        } else if (strcmp(argv[i], "--io-cap") == 0 && i + 1 < argc) {
            if (parse_io_cap(argv[++i], &opt.io_capability) < 0) {
                fprintf(stderr, "Invalid --io-cap value\n");
                return 2;
            }
        } else if (strcmp(argv[i], "--timeout-ms") == 0 && i + 1 < argc) {
            opt.timeout_ms = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--non-interactive") == 0) {
            opt.interactive = 0;
        } else if (strcmp(argv[i], "--allow-no-link-key") == 0) {
            opt.require_new_link_key = 0;
        } else {
            fprintf(stderr, "Unknown option: %s\n", argv[i]);
            return 2;
        }
    }

    rc = bt_pair_device_full(mac, &opt, &report);
    print_report(&report);
    return rc == 0 ? 0 : 1;
}
