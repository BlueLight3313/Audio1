
#include <stdio.h>
#include <stdarg.h>
#include "bt_log.h"

static void bt_vlog(const char *level, const char *fmt, va_list ap)
{
    fprintf(stdout, "[%s] ", level);
    vfprintf(stdout, fmt, ap);
    fputc('\n', stdout);
    fflush(stdout);
}

void bt_log_info(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    bt_vlog("INFO", fmt, ap);
    va_end(ap);
}

void bt_log_warn(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    bt_vlog("WARN", fmt, ap);
    va_end(ap);
}

void bt_log_error(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    bt_vlog("ERROR", fmt, ap);
    va_end(ap);
}
