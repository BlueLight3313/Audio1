#ifndef BT_LOG_H
#define BT_LOG_H

#include "bt_platform.h"

void bt_log_info(const char *fmt, ...);
void bt_log_warn(const char *fmt, ...);
void bt_log_error(const char *fmt, ...);

#endif
