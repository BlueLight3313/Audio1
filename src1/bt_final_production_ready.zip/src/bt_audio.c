
#include <alsa/asoundlib.h>
#include <pthread.h>
#include <stdint.h>
#include <unistd.h>

extern int bt_transport_send(void*,int);
extern int bt_transport_recv(void*,int);

static snd_pcm_t *cap,*play;
static pthread_t th;
static int run=0;

static void init_pcm(snd_pcm_t **h, snd_pcm_stream_t s)
{
    snd_pcm_hw_params_t *p;
    snd_pcm_open(h,"default",s,0);
    snd_pcm_hw_params_alloca(&p);
    snd_pcm_hw_params_any(*h,p);
    snd_pcm_hw_params_set_access(*h,p,SND_PCM_ACCESS_RW_INTERLEAVED);
    snd_pcm_hw_params_set_format(*h,p,SND_PCM_FORMAT_S16_LE);
    snd_pcm_hw_params_set_channels(*h,p,1);
    unsigned int r=8000;
    snd_pcm_hw_params_set_rate_near(*h,p,&r,0);
    snd_pcm_hw_params(*h,p);
}

static void* loop(void*arg)
{
    int16_t mic[160];
    int16_t spk[160];

    while(run){
        snd_pcm_readi(cap,mic,160);

        bt_transport_send(mic,320);

        int n = bt_transport_recv(spk,320);
        if(n>0){
            snd_pcm_writei(play,spk,160);
        }
    }
    return 0;
}

int bt_audio_start()
{
    if(run) return 0;

    init_pcm(&cap,SND_PCM_STREAM_CAPTURE);
    init_pcm(&play,SND_PCM_STREAM_PLAYBACK);

    run=1;
    pthread_create(&th,0,loop,0);
    return 0;
}

void bt_audio_stop()
{
    if(!run) return;
    run=0;
    pthread_join(th,0);
    snd_pcm_close(cap);
    snd_pcm_close(play);
}
