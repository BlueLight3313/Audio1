#ifndef BT_SMS_H
#define BT_SMS_H

#include <stdint.h>

#include "bt_device.h"

int bt_sms_send_to_device(
    const struct bt_device_record *device,
    const char *identifier,
    const char *text,
    uint8_t rfcomm_channel
);

#endif
