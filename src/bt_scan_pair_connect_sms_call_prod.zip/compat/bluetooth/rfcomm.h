#ifndef BT_COMPAT_RFCOMM_H
#define BT_COMPAT_RFCOMM_H

#include <stdint.h>
#include <sys/socket.h>
#include "bluetooth.h"

#ifndef BTPROTO_RFCOMM
#define BTPROTO_RFCOMM 3
#endif

struct sockaddr_rc {
    sa_family_t rc_family;
    bdaddr_t rc_bdaddr;
    uint8_t rc_channel;
};

#endif
