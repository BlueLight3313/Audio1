#ifndef COMPAT_BLUETOOTH_HCI_H
#define COMPAT_BLUETOOTH_HCI_H

#include <stdint.h>
#include <sys/socket.h>

#define HCI_DEV_NONE         0xffff
#define HCI_CHANNEL_RAW      0
#define HCI_CHANNEL_USER     1
#define HCI_CHANNEL_MONITOR  2
#define HCI_CHANNEL_CONTROL  3

struct sockaddr_hci {
    sa_family_t hci_family;
    uint16_t    hci_dev;
    uint16_t    hci_channel;
};

#endif
