#ifndef BT_CLI_H
#define BT_CLI_H

int bt_cli_run(uint16_t dev_id);

#endif
