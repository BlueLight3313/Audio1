
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/ioctl.h>

#include "bt_defs.h"
#include "bt_types.h"
#include "bt_adapter.h"

#define HCIDEVUP      _IOW('H', 201, int)
#define HCIDEVDOWN    _IOW('H', 202, int)
#define HCIGETDEVINFO _IOR('H', 211, int)

int bt_hci_open() {
    return socket(AF_BLUETOOTH, SOCK_RAW, BTPROTO_HCI);
}

int bt_hci_bind(int sock, int dev_id) {
    struct sockaddr_hci addr;
    addr.hci_family = AF_BLUETOOTH;
    addr.hci_dev = dev_id;
    addr.hci_channel = HCI_CHANNEL_RAW;

    return bind(sock, (struct sockaddr *)&addr, sizeof(addr));
}

int bt_adapter_check(int sock, int dev_id) {
    struct hci_dev_info di;
    memset(&di, 0, sizeof(di));
    di.dev_id = dev_id;
    return ioctl(sock, HCIGETDEVINFO, &di);
}

int bt_adapter_up(int sock, int dev_id) {
    return ioctl(sock, HCIDEVUP, dev_id);
}

int bt_adapter_down(int sock, int dev_id) {
    return ioctl(sock, HCIDEVDOWN, dev_id);
}

int bt_hci_send_cmd(int sock, uint16_t opcode, uint8_t *params, uint8_t plen) {
    uint8_t buffer[260];
    struct hci_command_hdr *hdr = (struct hci_command_hdr *)buffer;

    hdr->opcode = opcode;
    hdr->plen = plen;

    if (plen > 0)
        memcpy(buffer + sizeof(*hdr), params, plen);

    return write(sock, buffer, sizeof(*hdr) + plen);
}

int bt_set_discoverable(int sock) {
    uint8_t mode = SCAN_BOTH;
    return bt_hci_send_cmd(sock, HCI_OPCODE(0x03, 0x001A), &mode, 1);
}
