
#include <sys/socket.h>
#include <unistd.h>
#include <string.h>
#include "bt_bt.h"

static void str2ba(const char *str, unsigned char *ba){
    int b[6];
    sscanf(str,"%x:%x:%x:%x:%x:%x",&b[5],&b[4],&b[3],&b[2],&b[1],&b[0]);
    for(int i=0;i<6;i++) ba[i]=b[i];
}

int bt_rfcomm_connect(const char *mac){
    int s=socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);

    struct sockaddr_rc addr={0};
    addr.rc_family=AF_BLUETOOTH;
    addr.rc_channel=1;
    str2ba(mac, addr.rc_bdaddr);

    if(connect(s,(struct sockaddr*)&addr,sizeof(addr))<0) return -1;
    return s;
}

int bt_rfcomm_send(int fd,const char*cmd){
    return write(fd,cmd,strlen(cmd));
}

int bt_rfcomm_recv(int fd,char*buf,int len){
    return read(fd,buf,len);
}
