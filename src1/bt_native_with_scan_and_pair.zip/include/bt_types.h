
#ifndef BT_TYPES_H
#define BT_TYPES_H

#include <stdint.h>

typedef struct {
    uint8_t b[6];
} bt_bdaddr_t;

struct sockaddr_hci {
    unsigned short hci_family;
    unsigned short hci_dev;
    unsigned short hci_channel;
};

struct hci_filter {
    uint32_t type_mask;
    uint32_t event_mask[2];
    uint16_t opcode;
};

struct hci_command_hdr {
    uint16_t opcode;
    uint8_t plen;
} __attribute__((packed));

struct hci_event_hdr {
    uint8_t evt;
    uint8_t plen;
} __attribute__((packed));

struct bt_hci_ev_cmd_complete {
    uint8_t ncmd;
    uint16_t opcode;
} __attribute__((packed));

struct bt_hci_ev_cmd_status {
    uint8_t status;
    uint8_t ncmd;
    uint16_t opcode;
} __attribute__((packed));

struct bt_hci_dev_req {
    uint16_t dev_id;
    uint32_t dev_opt;
} __attribute__((packed));

struct bt_hci_dev_list_req {
    uint16_t dev_num;
    struct bt_hci_dev_req dev_req[16];
} __attribute__((packed));

struct hci_dev_info_ex {
    uint16_t dev_id;
    char name[8];
    bt_bdaddr_t bdaddr;
    uint32_t flags;
    uint8_t type;
    uint8_t features[8];
    uint32_t pkt_type;
    uint32_t link_policy;
    uint32_t link_mode;
    uint16_t acl_mtu;
    uint16_t acl_pkts;
    uint16_t sco_mtu;
    uint16_t sco_pkts;
    uint32_t stat_err_rx;
    uint32_t stat_err_tx;
    uint32_t stat_cmd_tx;
    uint32_t stat_evt_rx;
    uint32_t stat_acl_tx;
    uint32_t stat_acl_rx;
    uint32_t stat_sco_tx;
    uint32_t stat_sco_rx;
    uint32_t stat_byte_rx;
    uint32_t stat_byte_tx;
} __attribute__((packed));

struct bt_hci_rp_read_local_name {
    uint8_t status;
    char name[248];
} __attribute__((packed));

struct bt_hci_rp_read_scan_enable {
    uint8_t status;
    uint8_t scan_enable;
} __attribute__((packed));

struct bt_hci_cp_write_scan_enable {
    uint8_t scan_enable;
} __attribute__((packed));

struct bt_hci_cp_write_simple_pairing_mode {
    uint8_t mode;
} __attribute__((packed));

struct bt_hci_cp_inquiry {
    uint8_t lap[3];
    uint8_t inquiry_length;
    uint8_t num_responses;
} __attribute__((packed));

struct bt_hci_cp_remote_name_req {
    bt_bdaddr_t bdaddr;
    uint8_t page_scan_rep_mode;
    uint8_t reserved;
    uint16_t clock_offset;
} __attribute__((packed));

struct bt_hci_cp_create_conn {
    bt_bdaddr_t bdaddr;
    uint16_t pkt_type;
    uint8_t page_scan_rep_mode;
    uint8_t reserved;
    uint16_t clock_offset;
    uint8_t allow_role_switch;
} __attribute__((packed));

struct bt_hci_cp_pin_code_reply {
    bt_bdaddr_t bdaddr;
    uint8_t pin_len;
    uint8_t pin_code[16];
} __attribute__((packed));

struct bt_hci_cp_pin_code_neg_reply {
    bt_bdaddr_t bdaddr;
} __attribute__((packed));

struct bt_hci_cp_link_key_neg_reply {
    bt_bdaddr_t bdaddr;
} __attribute__((packed));

struct bt_hci_cp_link_key_reply {
    bt_bdaddr_t bdaddr;
    uint8_t link_key[16];
} __attribute__((packed));

struct bt_hci_cp_io_capability_reply {
    bt_bdaddr_t bdaddr;
    uint8_t io_capability;
    uint8_t oob_data_present;
    uint8_t authentication_requirements;
} __attribute__((packed));

struct bt_hci_cp_user_confirm_reply {
    bt_bdaddr_t bdaddr;
} __attribute__((packed));

struct bt_hci_cp_user_confirm_neg_reply {
    bt_bdaddr_t bdaddr;
} __attribute__((packed));

struct bt_hci_cp_user_passkey_reply {
    bt_bdaddr_t bdaddr;
    uint32_t passkey;
} __attribute__((packed));

struct bt_hci_cp_user_passkey_neg_reply {
    bt_bdaddr_t bdaddr;
} __attribute__((packed));

struct bt_hci_cp_remote_oob_data_neg_reply {
    bt_bdaddr_t bdaddr;
} __attribute__((packed));

struct bt_hci_cp_auth_requested {
    uint16_t handle;
} __attribute__((packed));

struct bt_hci_ev_inquiry_complete {
    uint8_t status;
} __attribute__((packed));

struct bt_hci_ev_inquiry_info {
    bt_bdaddr_t bdaddr;
    uint8_t page_scan_rep_mode;
    uint8_t reserved1;
    uint8_t reserved2;
    uint8_t dev_class[3];
    uint16_t clock_offset;
} __attribute__((packed));

struct bt_hci_ev_inquiry_result_rssi_info {
    bt_bdaddr_t bdaddr;
    uint8_t page_scan_rep_mode;
    uint8_t reserved;
    uint8_t dev_class[3];
    uint16_t clock_offset;
    int8_t rssi;
} __attribute__((packed));

struct bt_hci_ev_extended_inquiry_result {
    bt_bdaddr_t bdaddr;
    uint8_t page_scan_rep_mode;
    uint8_t reserved;
    uint8_t dev_class[3];
    uint16_t clock_offset;
    int8_t rssi;
    uint8_t eir[240];
} __attribute__((packed));

struct bt_hci_ev_remote_name_req_complete {
    uint8_t status;
    bt_bdaddr_t bdaddr;
    char name[248];
} __attribute__((packed));

struct bt_hci_ev_conn_complete {
    uint8_t status;
    uint16_t handle;
    bt_bdaddr_t bdaddr;
    uint8_t link_type;
    uint8_t encryption_mode;
} __attribute__((packed));

struct bt_hci_ev_disconn_complete {
    uint8_t status;
    uint16_t handle;
    uint8_t reason;
} __attribute__((packed));

struct bt_hci_ev_auth_complete {
    uint8_t status;
    uint16_t handle;
} __attribute__((packed));

struct bt_hci_ev_pin_code_req {
    bt_bdaddr_t bdaddr;
} __attribute__((packed));

struct bt_hci_ev_link_key_req {
    bt_bdaddr_t bdaddr;
} __attribute__((packed));

struct bt_hci_ev_link_key_notify {
    bt_bdaddr_t bdaddr;
    uint8_t link_key[16];
    uint8_t key_type;
} __attribute__((packed));

struct bt_hci_ev_io_capability_request {
    bt_bdaddr_t bdaddr;
} __attribute__((packed));

struct bt_hci_ev_user_confirm_request {
    bt_bdaddr_t bdaddr;
    uint32_t numeric_value;
} __attribute__((packed));

struct bt_hci_ev_user_passkey_request {
    bt_bdaddr_t bdaddr;
} __attribute__((packed));

struct bt_hci_ev_simple_pairing_complete {
    uint8_t status;
    bt_bdaddr_t bdaddr;
} __attribute__((packed));

#endif
