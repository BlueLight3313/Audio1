
#ifndef BT_PAIR_H
#define BT_PAIR_H

typedef enum {
    BT_PAIR_SUCCESS = 0,
    BT_PAIR_FAILED,
    BT_PAIR_CANCELLED,
    BT_PAIR_TIMEOUT
} bt_pair_status_t;

typedef struct {
    bt_pair_status_t status;
    int mgmt_status;
} bt_pair_result_t;

bt_pair_result_t bt_pair_device(int adapter, const char *mac);

#endif
