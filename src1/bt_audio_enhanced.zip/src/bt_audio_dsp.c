
#include "bt_audio_dsp.h"

static int16_t prev=0;

void dsp_process(int16_t *buf, int n){
    for(int i=0;i<n;i++){
        int16_t x=buf[i];
        int16_t y = x - prev + (prev>>1);
        prev = x;
        buf[i]=y;
    }
}
