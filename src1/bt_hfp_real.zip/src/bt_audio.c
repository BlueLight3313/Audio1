
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <stdint.h>
#include <string.h>

extern int bt_sco_send(int,void*,int);
extern int bt_sco_recv(int,void*,int);

static int sco_fd;
static int dsp_in, dsp_out;
static pthread_t th;
static int run=0;

static void* loop(void*arg){
    int16_t buf[160];

    while(run){
        read(dsp_in,buf,320);
        bt_sco_send(sco_fd,buf,320);

        int n=bt_sco_recv(sco_fd,buf,320);
        if(n>0) write(dsp_out,buf,320);
    }
    return 0;
}

int bt_audio_start(int sco){
    sco_fd=sco;
    dsp_in=open("/dev/dsp",O_RDONLY);
    dsp_out=open("/dev/dsp",O_WRONLY);

    run=1;
    pthread_create(&th,0,loop,0);
    return 0;
}

void bt_audio_stop(){
    run=0;
    pthread_join(th,0);
}
