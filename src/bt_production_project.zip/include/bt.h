
#ifndef BT_H
#define BT_H

typedef enum {
    BT_OK = 0,
    BT_FAIL,
    BT_TIMEOUT,
    BT_CANCELLED
} bt_status_t;

typedef struct {
    bt_status_t status;
    int mgmt_status;
} bt_result_t;

int bt_scan(int adapter, int timeout);
bt_result_t bt_pair(int adapter, const char *mac);
bt_result_t bt_connect(const char *mac);

#endif
