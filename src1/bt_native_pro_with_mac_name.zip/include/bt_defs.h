
#ifndef BT_DEFS_H
#define BT_DEFS_H

#include <sys/ioctl.h>

/* Address family / protocol */
#define AF_BLUETOOTH 31
#define BTPROTO_HCI 1

/* HCI channels */
#define HCI_CHANNEL_RAW      0
#define HCI_CHANNEL_USER     1
#define HCI_CHANNEL_MONITOR  2
#define HCI_CHANNEL_CONTROL  3
#define HCI_CHANNEL_LOGGING  4

/* HCI packet types */
#define BT_HCI_COMMAND_PKT   0x01
#define BT_HCI_ACLDATA_PKT   0x02
#define BT_HCI_SCODATA_PKT   0x03
#define BT_HCI_EVENT_PKT     0x04

/* HCI event codes */
#define BT_HCI_EV_INQUIRY_COMPLETE     0x01
#define BT_HCI_EV_INQUIRY_RESULT       0x02
#define BT_HCI_EV_CONN_COMPLETE        0x03
#define BT_HCI_EV_CONN_REQUEST         0x04
#define BT_HCI_EV_DISCONN_COMPLETE     0x05
#define BT_HCI_EV_AUTH_COMPLETE        0x06
#define BT_HCI_EV_REMOTE_NAME_REQ_COMPLETE 0x07
#define BT_HCI_EV_ENCRYPT_CHANGE       0x08
#define BT_HCI_EV_CHANGE_CONN_LINK_KEY_COMPLETE 0x09
#define BT_HCI_EV_MASTER_LINK_KEY_COMPLETE 0x0A
#define BT_HCI_EV_READ_REMOTE_FEATURES_COMPLETE 0x0B
#define BT_HCI_EV_READ_REMOTE_VERSION_COMPLETE 0x0C
#define BT_HCI_EV_QOS_SETUP_COMPLETE   0x0D
#define BT_HCI_EV_CMD_COMPLETE         0x0E
#define BT_HCI_EV_CMD_STATUS           0x0F

/* OGF / OCF helpers */
#define BT_HCI_OPCODE(ogf, ocf) ((unsigned short)(((ocf) & 0x03ff) | ((ogf) << 10)))
#define BT_HCI_OGF(opcode) (((opcode) >> 10) & 0x003f)
#define BT_HCI_OCF(opcode) ((opcode) & 0x03ff)

/* OGF groups */
#define BT_OGF_LINK_CTL       0x01
#define BT_OGF_LINK_POLICY    0x02
#define BT_OGF_CTRL_BASEBAND  0x03
#define BT_OGF_INFO_PARAM     0x04
#define BT_OGF_STATUS_PARAM   0x05
#define BT_OGF_TESTING        0x06
#define BT_OGF_LE_CTL         0x08
#define BT_OGF_VENDOR_CMD     0x3F

/* Common OCF */
#define BT_OCF_RESET               0x0003
#define BT_OCF_READ_LOCAL_NAME     0x0014
#define BT_OCF_READ_SCAN_ENABLE    0x0019
#define BT_OCF_WRITE_SCAN_ENABLE   0x001A
#define BT_OCF_READ_BD_ADDR        0x0009

/* Scan enable values */
#define BT_SCAN_DISABLED  0x00
#define BT_SCAN_INQUIRY   0x01
#define BT_SCAN_PAGE      0x02
#define BT_SCAN_BOTH      0x03

/* ioctl numbers */
#define HCIDEVUP       _IOW('H', 201, int)
#define HCIDEVDOWN     _IOW('H', 202, int)
#define HCIDEVRESET    _IOW('H', 203, int)
#define HCIGETDEVLIST  _IOR('H', 210, int)
#define HCIGETDEVINFO  _IOR('H', 211, int)

#define BT_HCI_MAX_NAME_LENGTH 248
#define BT_MAX_HCI_EVENT_SIZE  260
#define BT_ADAPTER_NAME_SIZE   8

#endif
