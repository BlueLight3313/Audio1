
#ifndef BT_CLASSIFY_H
#define BT_CLASSIFY_H

#include <stdint.h>

typedef enum {
    BT_REMOTE_UNKNOWN = 0,
    BT_REMOTE_AUDIO,
    BT_REMOTE_PHONE,
    BT_REMOTE_COMPUTER
} bt_remote_type_t;

typedef enum {
    BT_PAIR_AUTO = 0,
    BT_PAIR_CONFIRM,
    BT_PAIR_PIN_CONFIRM
} bt_pair_policy_t;

bt_remote_type_t bt_classify_cod(const uint8_t cod[3]);
bt_pair_policy_t bt_recommend_policy(bt_remote_type_t type);

const char* bt_type_str(bt_remote_type_t t);
const char* bt_policy_str(bt_pair_policy_t p);

#endif
