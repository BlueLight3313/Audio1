
#ifndef BT_TYPES_H
#define BT_TYPES_H

#include <stdint.h>

struct sockaddr_hci {
    unsigned short hci_family;
    unsigned short hci_dev;
    unsigned short hci_channel;
};

struct hci_command_hdr {
    uint16_t opcode;
    uint8_t plen;
} __attribute__((packed));

struct hci_dev_info {
    uint16_t dev_id;
    char name[8];
    uint8_t bdaddr[6];
    uint32_t flags;
};

#endif
