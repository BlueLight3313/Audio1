
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include "bt_hci.h"
#include "bt_adapter.h"
#include "bt_log.h"

static void print_status(int ctl_sock, int hci_sock, int dev_id)
{
    struct hci_dev_info_ex info;
    uint8_t mac[6];
    char mac_text[32];
    char local_name[249];
    uint8_t scan_enable = 0;

    if (bt_adapter_get_info(ctl_sock, dev_id, &info) == 0) {
        bt_log_info("Adapter id      : %d", dev_id);
        bt_log_info("Adapter name    : %s", info.name);
        bt_log_info("Flags           : 0x%08X", info.flags);
        bt_log_info("ACL MTU/PKTS    : %u / %u", info.acl_mtu, info.acl_pkts);
        bt_log_info("SCO MTU/PKTS    : %u / %u", info.sco_mtu, info.sco_pkts);
    } else {
        bt_log_error("Failed to get adapter info: %s", strerror(errno));
    }

    if (bt_adapter_get_local_mac(ctl_sock, dev_id, mac) == 0) {
        bt_format_bdaddr(mac, mac_text, sizeof(mac_text));
        bt_log_info("Local MAC       : %s", mac_text);
    } else {
        bt_log_error("Failed to get local MAC: %s", strerror(errno));
    }

    if (bt_adapter_get_local_name(hci_sock, local_name, sizeof(local_name)) == 0) {
        bt_log_info("Local Name      : %s", local_name);
    } else {
        bt_log_error("Failed to get local name: %s", strerror(errno));
    }

    if (bt_adapter_get_scan_enable(hci_sock, &scan_enable) == 0) {
        bt_log_info("Scan Enable     : %s (0x%02X)", bt_scan_enable_to_text(scan_enable), scan_enable);
    } else {
        bt_log_error("Failed to get scan enable: %s", strerror(errno));
    }
}

int main(void)
{
    int ctl_sock = -1;
    int hci_sock = -1;
    int dev_id = -1;
    char line[256];

    ctl_sock = bt_hci_open_raw();
    if (ctl_sock < 0) {
        bt_log_error("Failed to open HCI control socket: %s", strerror(errno));
        return 1;
    }

    if (bt_adapter_find_first(ctl_sock, &dev_id) < 0) {
        bt_log_error("No Bluetooth adapter found: %s", strerror(errno));
        close(ctl_sock);
        return 1;
    }

    bt_log_info("Found adapter with dev_id=%d", dev_id);

    if (bt_adapter_power_on(ctl_sock, dev_id) < 0) {
        bt_log_warn("Power on returned error: %s", strerror(errno));
    } else {
        bt_log_info("Adapter powered on");
    }

    hci_sock = bt_hci_open_bound_raw(dev_id);
    if (hci_sock < 0) {
        bt_log_error("Failed to open bound raw HCI socket: %s", strerror(errno));
        close(ctl_sock);
        return 1;
    }

    bt_log_info("Type commands: status | discoverable on | discoverable off | power on | power off | quit");

    for (;;) {
        printf("bt> ");
        fflush(stdout);

        if (fgets(line, sizeof(line), stdin) == NULL) {
            break;
        }

        line[strcspn(line, "\r\n")] = '\0';

        if (strcmp(line, "status") == 0) {
            print_status(ctl_sock, hci_sock, dev_id);
            continue;
        }

        if (strcmp(line, "discoverable on") == 0) {
            if (bt_adapter_set_discoverable(hci_sock, 1) == 0) {
                bt_log_info("Discoverable enabled");
            } else {
                bt_log_error("Failed to enable discoverable: %s", strerror(errno));
            }
            continue;
        }

        if (strcmp(line, "discoverable off") == 0) {
            if (bt_adapter_set_discoverable(hci_sock, 0) == 0) {
                bt_log_info("Discoverable disabled");
            } else {
                bt_log_error("Failed to disable discoverable: %s", strerror(errno));
            }
            continue;
        }

        if (strcmp(line, "power on") == 0) {
            if (bt_adapter_power_on(ctl_sock, dev_id) == 0) {
                bt_log_info("Adapter powered on");
            } else {
                bt_log_error("Failed to power on adapter: %s", strerror(errno));
            }
            continue;
        }

        if (strcmp(line, "power off") == 0) {
            if (bt_adapter_power_off(ctl_sock, dev_id) == 0) {
                bt_log_info("Adapter powered off");
            } else {
                bt_log_error("Failed to power off adapter: %s", strerror(errno));
            }
            continue;
        }

        if (strcmp(line, "quit") == 0 || strcmp(line, "exit") == 0) {
            break;
        }

        bt_log_warn("Unknown command: %s", line);
    }

    if (hci_sock >= 0) {
        close(hci_sock);
    }
    if (ctl_sock >= 0) {
        close(ctl_sock);
    }

    return 0;
}
