
#ifndef BT_CALL_H
#define BT_CALL_H
typedef enum { CALL_IDLE=0,CALL_OUTGOING,CALL_INCOMING,CALL_ACTIVE } call_state_t;
void bt_call_init();
void bt_call_dial(const char*,const char*);
void bt_call_incoming(const char*,const char*);
void bt_call_accept();
void bt_call_reject();
void bt_call_hangup();
void bt_call_remote_event(int,const char*);
void bt_call_print();
#endif
