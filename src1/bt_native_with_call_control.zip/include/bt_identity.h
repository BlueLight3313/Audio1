#ifndef BT_IDENTITY_H
#define BT_IDENTITY_H

#include <stddef.h>

int bt_identity_load_or_create_from_mac(const char *file_path, const char *mac_text);
int bt_identity_set_and_save(const char *file_path, const char *identifier);
const char *bt_identity_get(void);
void bt_identity_compose_message(const char *text, char *out, size_t out_size);

#endif
