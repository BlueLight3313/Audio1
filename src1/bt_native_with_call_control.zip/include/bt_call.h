#ifndef BT_CALL_H
#define BT_CALL_H

#include "bt_device.h"

typedef enum {
    BT_CALL_STATE_IDLE = 0,
    BT_CALL_STATE_OUTGOING_DIALING,
    BT_CALL_STATE_INCOMING_RINGING,
    BT_CALL_STATE_ACTIVE
} bt_call_state_t;

struct bt_call_session {
    bt_call_state_t state;
    bt_bdaddr_t remote_bdaddr;
    char remote_address_text[18];
    uint8_t remote_present;
};

void bt_call_init(void);
bt_call_state_t bt_call_get_state(void);
const char *bt_call_state_to_text(bt_call_state_t state);

int bt_call_dial_address_text(const char *address_text);
int bt_call_incoming_address_text(const char *address_text);
int bt_call_answer(void);
int bt_call_reject(void);
int bt_call_hangup(void);

void bt_call_print_status(void);

#endif
