
#ifndef BT_HFP_H
#define BT_HFP_H

int bt_hfp_init(int rfcomm_fd);
void bt_hfp_handle();
void bt_hfp_dial(const char *number);
void bt_hfp_answer();
void bt_hfp_hangup();

#endif
