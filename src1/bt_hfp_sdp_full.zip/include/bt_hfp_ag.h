
#ifndef BT_HFP_AG_H
#define BT_HFP_AG_H
void bt_hfp_ag_run(int fd);
#endif
