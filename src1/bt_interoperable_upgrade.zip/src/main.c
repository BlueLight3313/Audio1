
#include <stdio.h>

int bt_rfcomm_server_start(unsigned char*);
int bt_rfcomm_accept(int,unsigned char*);
void bt_hfp_ag_run(int,unsigned char*);

int main(){
    unsigned char ch;
    unsigned char mac[6];

    int s = bt_rfcomm_server_start(&ch);
    int c = bt_rfcomm_accept(s,mac);

    bt_hfp_ag_run(c,mac);
    return 0;
}
