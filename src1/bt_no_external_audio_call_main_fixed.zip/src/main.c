
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "bt_hci.h"
#include "bt_adapter.h"
#include "bt_connect.h"
#include "bt_defs.h"
#include "bt_device.h"
#include "bt_identity.h"
#include "bt_log.h"
#include "bt_pair.h"
#include "bt_scan.h"
#include "bt_sms.h"
#include "bt_call.h"

static void print_status(int ctl_sock, int hci_sock, int dev_id)
{
    struct hci_dev_info_ex info;
    uint8_t mac[6];
    char mac_text[32];
    char local_name[249];
    uint8_t scan_enable = 0;

    if (bt_adapter_get_info(ctl_sock, dev_id, &info) == 0) {
        bt_log_info("Adapter id      : %d", dev_id);
        bt_log_info("Adapter name    : %s", info.name);
        bt_log_info("Flags           : 0x%08X", info.flags);
        bt_log_info("ACL MTU/PKTS    : %u / %u", info.acl_mtu, info.acl_pkts);
        bt_log_info("SCO MTU/PKTS    : %u / %u", info.sco_mtu, info.sco_pkts);
    } else {
        bt_log_error("Failed to get adapter info: %s", strerror(errno));
    }

    if (bt_adapter_get_local_mac(ctl_sock, dev_id, mac) == 0) {
        bt_format_bdaddr(mac, mac_text, sizeof(mac_text));
        bt_log_info("Local MAC       : %s", mac_text);
    } else {
        bt_log_error("Failed to get local MAC: %s", strerror(errno));
        mac_text[0] = '\0';
    }

    if (bt_adapter_get_local_name(hci_sock, local_name, sizeof(local_name)) == 0) {
        bt_log_info("Local Name      : %s", local_name);
    } else {
        bt_log_error("Failed to get local name: %s", strerror(errno));
    }

    if (bt_adapter_get_scan_enable(hci_sock, &scan_enable) == 0) {
        bt_log_info("Scan Enable     : %s (0x%02X)", bt_scan_enable_to_text(scan_enable), scan_enable);
    } else {
        bt_log_error("Failed to get scan enable: %s", strerror(errno));
    }

    bt_log_info("App Identifier  : %s", bt_identity_get());
    bt_call_print();
    bt_log_info("Cached Devices  : %lu", (unsigned long)bt_device_cache_count());
    bt_log_info("Bonded Devices  : %lu", (unsigned long)bt_bond_cache_count());
}

static void print_help(void)
{
    puts("Commands:");
    puts("  status");
    puts("  discoverable on");
    puts("  discoverable off");
    puts("  power on");
    puts("  power off");
    puts("  scan");
    puts("  devices");
    puts("  paired");
    puts("  pair auto <index>");
    puts("  pair confirm <index>");
    puts("  pair phone <index> [pin]");
    puts("  connect <index>");
    puts("  id");
    puts("  id set <identifier>");
    puts("  sms <index> <text>");
    puts("  dial <MAC>");
    puts("  incoming call <MAC>");
    puts("  answer");
    puts("  reject");
    puts("  hangup");
    puts("  call");
    puts("  help");
    puts("  quit");
}

static const struct bt_device_record *bt_get_device_by_index_string(const char *text)
{
    long idx;
    char *endp;

    idx = strtol(text, &endp, 10);
    if (text[0] == '\0' || *endp != '\0' || idx <= 0) {
        return NULL;
    }

    return bt_device_cache_get_const((size_t)(idx - 1));
}

static const char *bt_skip_n_tokens(const char *line, int tokens_to_skip)
{
    int skipped = 0;
    const char *p = line;

    while (*p != '\0' && skipped < tokens_to_skip) {
        while (*p == ' ') {
            ++p;
        }
        while (*p != '\0' && *p != ' ') {
            ++p;
        }
        ++skipped;
    }

    while (*p == ' ') {
        ++p;
    }

    return p;
}

int main(void)
{
    int ctl_sock = -1;
    int hci_sock = -1;
    int dev_id = -1;
    char line[256];
    char raw_line[256];
    uint8_t mac[6];
    char mac_text[32];

    ctl_sock = bt_hci_open_raw();
    if (ctl_sock < 0) {
        bt_log_error("Failed to open HCI control socket: %s", strerror(errno));
        return 1;
    }

    if (bt_adapter_find_first(ctl_sock, &dev_id) < 0) {
        bt_log_error("No Bluetooth adapter found: %s", strerror(errno));
        close(ctl_sock);
        return 1;
    }

    bt_log_info("Found adapter with dev_id=%d", dev_id);

    if (bt_adapter_power_on(ctl_sock, dev_id) < 0) {
        bt_log_warn("Power on returned error: %s", strerror(errno));
    } else {
        bt_log_info("Adapter powered on");
    }

    hci_sock = bt_hci_open_bound_raw(dev_id);
    if (hci_sock < 0) {
        bt_log_error("Failed to open bound raw HCI socket: %s", strerror(errno));
        close(ctl_sock);
        return 1;
    }

    if (bt_adapter_get_local_mac(ctl_sock, dev_id, mac) == 0) {
        bt_format_bdaddr(mac, mac_text, sizeof(mac_text));
    } else {
        memcpy(mac_text, "UNKNOWN", 8);
    }

    if (bt_identity_load_or_create_from_mac(BT_IDENTITY_FILE_NAME, mac_text) < 0) {
        bt_log_warn("Failed to load app identifier file");
    }

    bt_call_init();

    bt_log_info("App Identifier  : %s", bt_identity_get());
    bt_log_info("Type 'help' to see supported commands");

    for (;;) {
        char *argv[8];
        int argc = 0;
        char *tok;

        printf("bt> ");
        fflush(stdout);

        if (fgets(line, sizeof(line), stdin) == NULL) {
            break;
        }

        memcpy(raw_line, line, sizeof(raw_line));
        raw_line[sizeof(raw_line) - 1] = '\0';

        line[strcspn(line, "\r\n")] = '\0';
        raw_line[strcspn(raw_line, "\r\n")] = '\0';

        tok = strtok(line, " ");
        while (tok != NULL && argc < 8) {
            argv[argc++] = tok;
            tok = strtok(NULL, " ");
        }

        if (argc == 0) {
            continue;
        }

        if (argc == 1 && strcmp(argv[0], "status") == 0) {
            print_status(ctl_sock, hci_sock, dev_id);
            continue;
        }

        if (argc == 2 && strcmp(argv[0], "discoverable") == 0 && strcmp(argv[1], "on") == 0) {
            if (bt_adapter_set_discoverable(hci_sock, 1) == 0) {
                bt_log_info("Discoverable enabled");
            } else {
                bt_log_error("Failed to enable discoverable: %s", strerror(errno));
            }
            continue;
        }

        if (argc == 2 && strcmp(argv[0], "discoverable") == 0 && strcmp(argv[1], "off") == 0) {
            if (bt_adapter_set_discoverable(hci_sock, 0) == 0) {
                bt_log_info("Discoverable disabled");
            } else {
                bt_log_error("Failed to disable discoverable: %s", strerror(errno));
            }
            continue;
        }

        if (argc == 2 && strcmp(argv[0], "power") == 0 && strcmp(argv[1], "on") == 0) {
            if (bt_adapter_power_on(ctl_sock, dev_id) == 0) {
                bt_log_info("Adapter powered on");
            } else {
                bt_log_error("Failed to power on adapter: %s", strerror(errno));
            }
            continue;
        }

        if (argc == 2 && strcmp(argv[0], "power") == 0 && strcmp(argv[1], "off") == 0) {
            if (bt_adapter_power_off(ctl_sock, dev_id) == 0) {
                bt_log_info("Adapter powered off");
            } else {
                bt_log_error("Failed to power off adapter: %s", strerror(errno));
            }
            continue;
        }

        if (argc == 1 && strcmp(argv[0], "scan") == 0) {
            if (bt_scan_nearby_devices(hci_sock, 8) == 0) {
                bt_device_cache_print();
            } else {
                bt_log_error("Scan failed: %s", strerror(errno));
            }
            continue;
        }

        if (argc == 1 && strcmp(argv[0], "devices") == 0) {
            bt_device_cache_print();
            continue;
        }

        if (argc == 1 && strcmp(argv[0], "paired") == 0) {
            bt_bond_cache_print();
            continue;
        }

        if (argc == 2 && strcmp(argv[0], "connect") == 0) {
            const struct bt_device_record *device = bt_get_device_by_index_string(argv[1]);
            if (device == NULL) {
                bt_log_error("Invalid device index");
                continue;
            }

            if (bt_connect_device(hci_sock, device) < 0) {
                bt_log_error("Connect failed: %s", strerror(errno));
            }
            continue;
        }

        if (argc >= 3 && strcmp(argv[0], "pair") == 0) {
            const struct bt_device_record *device = bt_get_device_by_index_string(argv[2]);
            if (device == NULL) {
                bt_log_error("Invalid device index");
                continue;
            }

            if (strcmp(argv[1], "auto") == 0) {
                if (bt_pair_device(hci_sock, device, BT_PAIR_PROFILE_AUDIO_ONLY, NULL) < 0) {
                    bt_log_error("Audio-only pairing failed: %s", strerror(errno));
                }
                continue;
            }

            if (strcmp(argv[1], "confirm") == 0) {
                if (bt_pair_device(hci_sock, device, BT_PAIR_PROFILE_SMART_HEADSET, NULL) < 0) {
                    bt_log_error("Smart-headset pairing failed: %s", strerror(errno));
                }
                continue;
            }

            if (strcmp(argv[1], "phone") == 0) {
                const char *pin = argc >= 4 ? argv[3] : NULL;
                if (bt_pair_device(hci_sock, device, BT_PAIR_PROFILE_SMARTPHONE, pin) < 0) {
                    bt_log_error("Smartphone pairing failed: %s", strerror(errno));
                }
                continue;
            }
        }

        if (argc == 1 && strcmp(argv[0], "id") == 0) {
            bt_log_info("App Identifier  : %s", bt_identity_get());
            continue;
        }

        if (argc >= 3 && strcmp(argv[0], "id") == 0 && strcmp(argv[1], "set") == 0) {
            const char *new_identifier = bt_skip_n_tokens(raw_line, 2);
            if (bt_identity_set_and_save(BT_IDENTITY_FILE_NAME, new_identifier) < 0) {
                bt_log_error("Failed to set identifier. Allowed chars: A-Z a-z 0-9 - _ .");
            } else {
                bt_log_info("App Identifier  : %s", bt_identity_get());
            }
            continue;
        }

        if (argc >= 3 && strcmp(argv[0], "sms") == 0) {
            const struct bt_device_record *device = bt_get_device_by_index_string(argv[1]);
            const char *text = bt_skip_n_tokens(raw_line, 2);

            if (device == NULL) {
                bt_log_error("Invalid device index");
                continue;
            }

            if (bt_sms_send_to_device(device, bt_identity_get(), text, BT_SMS_DEFAULT_RFCOMM_CHANNEL) < 0) {
                bt_log_error("SMS send failed: %s", strerror(errno));
            }
            continue;
        }

        if (argc == 2 && strcmp(argv[0], "dial") == 0) {
            bt_call_dial(argv[1], bt_identity_get());
            continue;
        }

        if (argc == 3 && strcmp(argv[0], "incoming") == 0 && strcmp(argv[1], "call") == 0) {
            bt_call_incoming(argv[2], "REMOTE");
            continue;
        }

        if (argc == 1 && strcmp(argv[0], "answer") == 0) {
            bt_call_accept();
            continue;
        }

        if (argc == 1 && strcmp(argv[0], "reject") == 0) {
            bt_call_reject();
            continue;
        }

        if (argc == 1 && strcmp(argv[0], "hangup") == 0) {
            bt_call_hangup();
            continue;
        }

        if (argc == 1 && strcmp(argv[0], "call") == 0) {
            bt_call_print();
            continue;
        }

        if (argc == 1 && strcmp(argv[0], "help") == 0) {
            print_help();
            continue;
        }

        if (argc == 1 && (strcmp(argv[0], "quit") == 0 || strcmp(argv[0], "exit") == 0)) {
            break;
        }

        bt_log_warn("Unknown command");
    }

    if (hci_sock >= 0) {
        close(hci_sock);
    }
    if (ctl_sock >= 0) {
        close(ctl_sock);
    }

    return 0;
}
