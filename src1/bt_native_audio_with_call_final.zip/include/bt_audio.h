#ifndef BT_AUDIO_H
#define BT_AUDIO_H

int bt_audio_start(void);
void bt_audio_stop(void);

#endif
