
#ifndef BT_COMPAT_H
#define BT_COMPAT_H
#include <stdint.h>

#define AF_BLUETOOTH 31
#define BTPROTO_HCI 1

typedef struct {
    uint8_t b[6];
} bdaddr_t;

int str2ba(const char *str, bdaddr_t *ba);

#endif
