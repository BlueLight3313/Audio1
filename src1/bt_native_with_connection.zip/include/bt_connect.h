
#ifndef BT_CONNECT_H
#define BT_CONNECT_H
#include <stdint.h>

int bt_connect_device(uint8_t mac[6]);
int bt_disconnect_device(uint8_t mac[6]);

#endif
