#ifndef BT_TYPES_H
#define BT_TYPES_H

#include "bt_platform.h"
#include "bt_defs.h"

struct bt_bdaddr {
    uint8_t b[6];
};

struct sockaddr_hci {
    sa_family_t hci_family;
    unsigned short hci_dev;
    unsigned short hci_channel;
};

struct hci_filter {
    unsigned long type_mask;
    unsigned long event_mask[2];
    uint16_t opcode;
};

struct hci_command_hdr {
    uint16_t opcode;
    uint8_t plen;
} __attribute__((packed));

struct hci_event_hdr {
    uint8_t evt;
    uint8_t plen;
} __attribute__((packed));

struct hci_dev_stats {
    uint32_t err_rx;
    uint32_t err_tx;
    uint32_t cmd_tx;
    uint32_t evt_rx;
    uint32_t acl_tx;
    uint32_t acl_rx;
    uint32_t sco_tx;
    uint32_t sco_rx;
    uint32_t byte_rx;
    uint32_t byte_tx;
};

struct hci_dev_info {
    uint16_t dev_id;
    char name[8];
    struct bt_bdaddr bdaddr;
    uint32_t flags;
    uint8_t type;
    uint8_t features[8];
    uint32_t pkt_type;
    uint32_t link_policy;
    uint32_t link_mode;
    uint16_t acl_mtu;
    uint16_t acl_pkts;
    uint16_t sco_mtu;
    uint16_t sco_pkts;
    struct hci_dev_stats stat;
};

struct hci_dev_req {
    uint16_t dev_id;
    uint32_t dev_opt;
};

struct hci_dev_list_req {
    uint16_t dev_num;
    struct hci_dev_req dev_req[];
};

struct bt_hci_cmd_complete {
    uint8_t ncmd;
    uint16_t opcode;
    uint8_t params[];
} __attribute__((packed));

struct bt_hci_cmd_status {
    uint8_t status;
    uint8_t ncmd;
    uint16_t opcode;
} __attribute__((packed));

struct bt_hci_rp_read_scan_enable {
    uint8_t status;
    uint8_t scan_enable;
} __attribute__((packed));

struct bt_hci_rp_read_local_name {
    uint8_t status;
    uint8_t name[HCI_MAX_NAME_LENGTH];
} __attribute__((packed));

struct bt_hci_rp_read_bd_addr {
    uint8_t status;
    struct bt_bdaddr bdaddr;
} __attribute__((packed));

struct bt_hci_cp_write_local_name {
    uint8_t name[HCI_MAX_NAME_LENGTH];
} __attribute__((packed));

struct bt_adapter_summary {
    uint16_t dev_id;
    char name[8];
};

struct bt_adapter_status {
    uint16_t dev_id;
    char name[8];
    struct bt_bdaddr bdaddr;
    uint32_t flags;
    uint8_t scan_enable;
    char local_name[HCI_MAX_NAME_LENGTH + 1];
};

#endif
