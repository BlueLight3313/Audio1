
#ifndef BT_DEFS_H
#define BT_DEFS_H

#include <sys/ioctl.h>

#ifndef AF_BLUETOOTH
#define AF_BLUETOOTH 31
#endif
#define BTPROTO_HCI 1

#define BT_SOL_HCI       0
#define BT_HCI_FILTER    2
#define BT_SOL_SOCKET    1
#define BT_SO_RCVTIMEO   20

#define HCI_CHANNEL_RAW      0
#define HCI_CHANNEL_USER     1
#define HCI_CHANNEL_MONITOR  2
#define HCI_CHANNEL_CONTROL  3
#define HCI_CHANNEL_LOGGING  4

#define BT_HCI_COMMAND_PKT   0x01
#define BT_HCI_ACLDATA_PKT   0x02
#define BT_HCI_SCODATA_PKT   0x03
#define BT_HCI_EVENT_PKT     0x04

#define BT_HCI_EV_INQUIRY_COMPLETE               0x01
#define BT_HCI_EV_INQUIRY_RESULT                 0x02
#define BT_HCI_EV_CONN_COMPLETE                  0x03
#define BT_HCI_EV_CONN_REQUEST                   0x04
#define BT_HCI_EV_DISCONN_COMPLETE               0x05
#define BT_HCI_EV_AUTH_COMPLETE                  0x06
#define BT_HCI_EV_REMOTE_NAME_REQ_COMPLETE       0x07
#define BT_HCI_EV_ENCRYPT_CHANGE                 0x08
#define BT_HCI_EV_CHANGE_CONN_LINK_KEY_COMPLETE  0x09
#define BT_HCI_EV_MASTER_LINK_KEY_COMPLETE       0x0A
#define BT_HCI_EV_READ_REMOTE_FEATURES_COMPLETE  0x0B
#define BT_HCI_EV_READ_REMOTE_VERSION_COMPLETE   0x0C
#define BT_HCI_EV_QOS_SETUP_COMPLETE             0x0D
#define BT_HCI_EV_CMD_COMPLETE                   0x0E
#define BT_HCI_EV_CMD_STATUS                     0x0F
#define BT_HCI_EV_HARDWARE_ERROR                 0x10
#define BT_HCI_EV_ROLE_CHANGE                    0x12
#define BT_HCI_EV_NUM_COMP_PKTS                  0x13
#define BT_HCI_EV_MODE_CHANGE                    0x14
#define BT_HCI_EV_RETURN_LINK_KEYS               0x15
#define BT_HCI_EV_PIN_CODE_REQ                   0x16
#define BT_HCI_EV_LINK_KEY_REQ                   0x17
#define BT_HCI_EV_LINK_KEY_NOTIFY                0x18
#define BT_HCI_EV_INQUIRY_RESULT_WITH_RSSI       0x22
#define BT_HCI_EV_IO_CAPABILITY_REQUEST          0x31
#define BT_HCI_EV_IO_CAPABILITY_RESPONSE         0x32
#define BT_HCI_EV_USER_CONFIRM_REQUEST           0x33
#define BT_HCI_EV_USER_PASSKEY_REQUEST           0x34
#define BT_HCI_EV_REMOTE_OOB_DATA_REQUEST        0x35
#define BT_HCI_EV_SIMPLE_PAIRING_COMPLETE        0x36
#define BT_HCI_EV_USER_PASSKEY_NOTIFY            0x3B
#define BT_HCI_EV_KEYPRESS_NOTIFY                0x3C
#define BT_HCI_EV_REMOTE_HOST_SUPPORTED_FEATURES 0x3D
#define BT_HCI_EV_EXTENDED_INQUIRY_RESULT        0x2F

#define BT_HCI_OPCODE(ogf, ocf) ((unsigned short)(((ocf) & 0x03ff) | ((ogf) << 10)))
#define BT_HCI_OGF(opcode) (((opcode) >> 10) & 0x003f)
#define BT_HCI_OCF(opcode) ((opcode) & 0x03ff)

#define BT_OGF_LINK_CTL       0x01
#define BT_OGF_LINK_POLICY    0x02
#define BT_OGF_CTRL_BASEBAND  0x03
#define BT_OGF_INFO_PARAM     0x04
#define BT_OGF_STATUS_PARAM   0x05
#define BT_OGF_TESTING        0x06
#define BT_OGF_LE_CTL         0x08
#define BT_OGF_VENDOR_CMD     0x3F

#define BT_OCF_INQUIRY                 0x0001
#define BT_OCF_INQUIRY_CANCEL          0x0002
#define BT_OCF_CREATE_CONN             0x0005
#define BT_OCF_DISCONNECT              0x0006
#define BT_OCF_LINK_KEY_REPLY          0x000B
#define BT_OCF_LINK_KEY_NEG_REPLY      0x000C
#define BT_OCF_PIN_CODE_REPLY          0x000D
#define BT_OCF_PIN_CODE_NEG_REPLY      0x000E
#define BT_OCF_AUTH_REQUESTED          0x0011
#define BT_OCF_SET_CONN_ENCRYPT        0x0013
#define BT_OCF_CHANGE_CONN_LINK_KEY    0x0015
#define BT_OCF_REMOTE_NAME_REQ         0x0019
#define BT_OCF_RESET                   0x0003
#define BT_OCF_READ_LOCAL_NAME         0x0014
#define BT_OCF_READ_SCAN_ENABLE        0x0019
#define BT_OCF_WRITE_SCAN_ENABLE       0x001A
#define BT_OCF_WRITE_SIMPLE_PAIRING_MODE 0x0056
#define BT_OCF_READ_BD_ADDR            0x0009
#define BT_OCF_IO_CAPABILITY_REPLY     0x002B
#define BT_OCF_USER_CONFIRM_REPLY      0x002C
#define BT_OCF_USER_CONFIRM_NEG_REPLY  0x002D
#define BT_OCF_USER_PASSKEY_REPLY      0x002E
#define BT_OCF_USER_PASSKEY_NEG_REPLY  0x002F
#define BT_OCF_REMOTE_OOB_DATA_NEG_REPLY 0x0033

#define BT_SCAN_DISABLED  0x00
#define BT_SCAN_INQUIRY   0x01
#define BT_SCAN_PAGE      0x02
#define BT_SCAN_BOTH      0x03

#define BT_PAIR_IO_DISPLAY_ONLY     0x00
#define BT_PAIR_IO_DISPLAY_YES_NO   0x01
#define BT_PAIR_IO_KEYBOARD_ONLY    0x02
#define BT_PAIR_IO_NO_INPUT_OUTPUT  0x03
#define BT_PAIR_IO_KEYBOARD_DISPLAY 0x04

#define BT_PAIR_AUTH_NO_BONDING         0x00
#define BT_PAIR_AUTH_GENERAL_BONDING    0x01
#define BT_PAIR_AUTH_MITM_GENERAL_BOND  0x05

#define HCIDEVUP       _IOW('H', 201, int)
#define HCIDEVDOWN     _IOW('H', 202, int)
#define HCIDEVRESET    _IOW('H', 203, int)
#define HCIGETDEVLIST  _IOR('H', 210, int)
#define HCIGETDEVINFO  _IOR('H', 211, int)

#define BT_HCI_MAX_NAME_LENGTH 248
#define BT_MAX_HCI_EVENT_SIZE  260
#define BT_ADAPTER_NAME_SIZE   8
#define BT_DEVICE_CACHE_CAPACITY 128
#define BT_LINK_KEY_SIZE 16
#define BT_BOND_CACHE_CAPACITY 64

#endif
