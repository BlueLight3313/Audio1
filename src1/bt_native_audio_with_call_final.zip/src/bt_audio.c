
#include <alsa/asoundlib.h>
#include <pthread.h>
#include <unistd.h>
#include "bt_audio.h"
#include "bt_log.h"

static pthread_t th;
static int running = 0;

static snd_pcm_t *capture_handle = NULL;
static snd_pcm_t *playback_handle = NULL;

static int init_pcm(snd_pcm_t **handle, const char *name, snd_pcm_stream_t stream)
{
    snd_pcm_hw_params_t *params;
    snd_pcm_open(handle, name, stream, 0);

    snd_pcm_hw_params_alloca(&params);
    snd_pcm_hw_params_any(*handle, params);
    snd_pcm_hw_params_set_access(*handle, params, SND_PCM_ACCESS_RW_INTERLEAVED);
    snd_pcm_hw_params_set_format(*handle, params, SND_PCM_FORMAT_S16_LE);
    snd_pcm_hw_params_set_channels(*handle, params, 1);
    unsigned int rate = 8000;
    snd_pcm_hw_params_set_rate_near(*handle, params, &rate, 0);
    snd_pcm_hw_params(*handle, params);

    return 0;
}

static void* loop(void *arg)
{
    int16_t buffer[160];

    bt_log_info("[AUDIO] ALSA loop started");

    while(running){
        snd_pcm_readi(capture_handle, buffer, 160);

        // TODO: send buffer to SCO

        // TODO: receive buffer from SCO

        snd_pcm_writei(playback_handle, buffer, 160);
    }

    return NULL;
}

int bt_audio_start()
{
    if(running) return 0;

    init_pcm(&capture_handle, "default", SND_PCM_STREAM_CAPTURE);
    init_pcm(&playback_handle, "default", SND_PCM_STREAM_PLAYBACK);

    running = 1;
    pthread_create(&th, NULL, loop, NULL);
    return 0;
}

void bt_audio_stop()
{
    if(!running) return;
    running = 0;
    pthread_join(th, NULL);

    snd_pcm_close(capture_handle);
    snd_pcm_close(playback_handle);
}
