
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

#include "bt_defs.h"
#include "bt_types.h"
#include "bt_hci.h"
#include "bt_adapter.h"


static size_t bt_local_strnlen_adapter(const char *s, size_t maxlen)
{
    size_t i = 0;
    while (i < maxlen && s[i] != '\0') {
        ++i;
    }
    return i;
}


int bt_adapter_find_first(int ctl_sock, int *dev_id_out)
{
    struct bt_hci_dev_list_req list;

    if (dev_id_out == NULL) {
        errno = EINVAL;
        return -1;
    }

    memset(&list, 0, sizeof(list));
    list.dev_num = 16;

    if (ioctl(ctl_sock, HCIGETDEVLIST, &list) < 0) {
        return -1;
    }

    if (list.dev_num == 0) {
        errno = ENODEV;
        return -1;
    }

    *dev_id_out = (int)list.dev_req[0].dev_id;
    return 0;
}

int bt_adapter_get_info(int ctl_sock, int dev_id, struct hci_dev_info_ex *out_info)
{
    if (out_info == NULL) {
        errno = EINVAL;
        return -1;
    }

    memset(out_info, 0, sizeof(*out_info));
    out_info->dev_id = (uint16_t)dev_id;

    if (ioctl(ctl_sock, HCIGETDEVINFO, out_info) < 0) {
        return -1;
    }

    return 0;
}

int bt_adapter_power_on(int ctl_sock, int dev_id)
{
    int rc = ioctl(ctl_sock, HCIDEVUP, dev_id);
    if (rc < 0 && errno == EALREADY) {
        return 0;
    }
    return rc;
}

int bt_adapter_power_off(int ctl_sock, int dev_id)
{
    int rc = ioctl(ctl_sock, HCIDEVDOWN, dev_id);
    if (rc < 0 && errno == EALREADY) {
        return 0;
    }
    return rc;
}

int bt_adapter_get_local_mac(int ctl_sock, int dev_id, uint8_t mac_out[6])
{
    struct hci_dev_info_ex info;

    if (mac_out == NULL) {
        errno = EINVAL;
        return -1;
    }

    if (bt_adapter_get_info(ctl_sock, dev_id, &info) < 0) {
        return -1;
    }

    memcpy(mac_out, info.bdaddr.b, 6);
    return 0;
}

int bt_adapter_get_local_name(int hci_sock, char *name_out, size_t name_out_size)
{
    struct bt_hci_rp_read_local_name rp;
    size_t len;

    if (name_out == NULL || name_out_size == 0) {
        errno = EINVAL;
        return -1;
    }

    memset(&rp, 0, sizeof(rp));

    if (bt_hci_send_req(
            hci_sock,
            BT_HCI_OPCODE(BT_OGF_CTRL_BASEBAND, BT_OCF_READ_LOCAL_NAME),
            NULL,
            0,
            &rp,
            sizeof(rp),
            2000) < 0) {
        return -1;
    }

    if (rp.status != 0x00) {
        errno = EIO;
        return -1;
    }

    len = bt_local_strnlen_adapter(rp.name, sizeof(rp.name));
    if (len >= name_out_size) {
        len = name_out_size - 1;
    }

    memcpy(name_out, rp.name, len);
    name_out[len] = '\0';
    return 0;
}

int bt_adapter_get_scan_enable(int hci_sock, uint8_t *scan_enable)
{
    struct bt_hci_rp_read_scan_enable rp;

    if (scan_enable == NULL) {
        errno = EINVAL;
        return -1;
    }

    memset(&rp, 0, sizeof(rp));

    if (bt_hci_send_req(
            hci_sock,
            BT_HCI_OPCODE(BT_OGF_CTRL_BASEBAND, BT_OCF_READ_SCAN_ENABLE),
            NULL,
            0,
            &rp,
            sizeof(rp),
            2000) < 0) {
        return -1;
    }

    if (rp.status != 0x00) {
        errno = EIO;
        return -1;
    }

    *scan_enable = rp.scan_enable;
    return 0;
}

int bt_adapter_set_discoverable(int hci_sock, uint8_t enable)
{
    struct bt_hci_cp_write_scan_enable cp;
    uint8_t verify_scan = 0;

    memset(&cp, 0, sizeof(cp));
    cp.scan_enable = enable ? BT_SCAN_BOTH : BT_SCAN_PAGE;

    if (bt_hci_send_req(
            hci_sock,
            BT_HCI_OPCODE(BT_OGF_CTRL_BASEBAND, BT_OCF_WRITE_SCAN_ENABLE),
            &cp,
            sizeof(cp),
            NULL,
            0,
            2000) < 0) {
        return -1;
    }

    if (bt_adapter_get_scan_enable(hci_sock, &verify_scan) < 0) {
        return -1;
    }

    if (enable) {
        if (verify_scan != BT_SCAN_BOTH) {
            errno = EIO;
            return -1;
        }
    } else {
        if (verify_scan != BT_SCAN_PAGE && verify_scan != BT_SCAN_DISABLED) {
            errno = EIO;
            return -1;
        }
    }

    return 0;
}

void bt_format_bdaddr(const uint8_t mac[6], char *out, size_t out_size)
{
    if (mac == NULL || out == NULL || out_size == 0) {
        return;
    }

    snprintf(
        out,
        out_size,
        "%02X:%02X:%02X:%02X:%02X:%02X",
        mac[5], mac[4], mac[3], mac[2], mac[1], mac[0]
    );
}

const char *bt_scan_enable_to_text(uint8_t scan_enable)
{
    switch (scan_enable) {
        case BT_SCAN_DISABLED: return "disabled";
        case BT_SCAN_INQUIRY:  return "inquiry";
        case BT_SCAN_PAGE:     return "page";
        case BT_SCAN_BOTH:     return "inquiry+page";
        default:               return "unknown";
    }
}
