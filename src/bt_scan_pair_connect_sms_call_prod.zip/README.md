# bt_scan_pair_connect_prod_all_ctx_sms

A native C Bluetooth BR/EDR project with **scan + pair + connect + sms** and a persistent device registry.

## Commands

```bash
make
./bt_prod hostid MY-DEVICE-ID
sudo ./bt_prod scan 0 8
sudo ./bt_prod pair all 0 8 --io-cap 3 --confirm yes
sudo ./bt_prod connect all 0 8 --verify-timeout-ms 3000 --hold-ms 1000
./bt_prod state
./bt_prod sms AA:BB:CC:DD:EE:FF hello from host
./bt_prod sms all broadcast message
```

## Host identifier

The project keeps a host identifier string in the runtime registry. You can set it with:

```bash
./bt_prod hostid MY-DEVICE-ID
```

You can also initialize it with the environment variable `BT_HOST_ID`.

## SMS behavior

The `sms` command sends an application-level SMS request payload over **RFCOMM channel 1**:

```text
SMS|<HOST-ID>|<MESSAGE-ID>|<TEXT>\n
```

### Logical error handler

Before sending, the project runs a **sendable-check**:
- device must exist in the registry
- device must be marked connected
- host identifier must exist
- text must be non-empty and within the size limit

After writing the payload, the project waits for a peer acknowledgement line for up to 5 seconds:

```text
SMS-RESULT|<MESSAGE-ID>|<CODE>|<DETAIL>\n
```

A simplified reply of only the numeric code is also accepted.

### Delivery result codes

- `2` = received
- `3` = not sent
- `4` = confirming
- `7` = unknown

The CLI prints:
- `sendable`
- `ack_received`
- `result=<code>(<meaning>)`
- `message_id`
- detailed text

### Important

This does **not** send a cellular SMS by itself.
The remote Bluetooth device must run a peer application or service that listens on RFCOMM channel 1, parses the payload, sends the real SMS on that remote device, and replies with the logical result line above.

- `sms <MAC> <TEXT>` sends to one target in the registry.
- `sms all <TEXT>` sends to all devices currently marked `connected=1` in the saved registry.

## State persistence

The registry is saved to `bt_runtime_state.txt` in the current working directory and keeps:

- host identifier
- index
- mac
- name
- paired
- connected

This lets separate CLI runs reuse the same state file.

## Audio call support

The project now includes an **application-level audio-call pipeline** for one
selected client:

```bash
sudo ./bt_prod call AA:BB:CC:DD:EE:FF 0 \
  --rfcomm-channel 1 \
  --control-timeout-ms 8000 \
  --sco-timeout-ms 5000 \
  --hold-seconds 10 \
  --require-audio-ready yes \
  --require-sco-write-probe yes
```

### Important scope

This call feature is **not a full HFP stack replacement**. It is a checked
project-level call flow built on:

- RFCOMM control messages for call setup and readiness
- SCO socket setup for voice transport

That means the remote device must run a peer service that understands these
control messages:

```text
CALL-SETUP|<HOST-ID>|<CALL-ID>|VOICE
CALL-ACCEPT|<CALL-ID>
CALL-REJECT|<CALL-ID>|<DETAIL>
AUDIO-CHECK|<CALL-ID>
AUDIO-READY|<CALL-ID>
CALL-END|<CALL-ID>|<DETAIL>
```

### Why the call flow is split into steps

The project intentionally checks every stage **before** it runs and **after** it
finishes. The main reason is that Bluetooth audio problems often come from one
layer succeeding while the next layer is still not ready.

The checked order is:

1. **Precheck**
   - device exists in registry
   - device is paired
   - device is connected
   - no other call is already active
2. **Control connect**
   - open RFCOMM socket
   - verify socket becomes writable
   - verify `SO_ERROR == 0`
3. **Call setup request**
   - send `CALL-SETUP`
   - wait for `CALL-ACCEPT` or `CALL-REJECT`
4. **Audio connect**
   - open SCO socket
   - verify socket becomes writable
   - verify `SO_ERROR == 0`
5. **Audio verification**
   - send `AUDIO-CHECK`
   - wait for `AUDIO-READY`
   - optionally perform a silent SCO write probe
6. **Active call monitoring**
   - watch control socket for `CALL-END`
   - watch both sockets for drop/error events
7. **Cleanup**
   - send `CALL-END`
   - close SCO
   - close RFCOMM
   - clear runtime call flags

### Why each value is needed

#### `rfcomm_channel`
The control socket needs a destination channel. We keep it configurable because
application-level peer services may not always use the same RFCOMM channel.
Using a value in the options structure makes future service migration easy.

#### `control_timeout_ms`
The control plane handles logical call acceptance and peer readiness. A timeout
is needed here because a connected control socket does **not** guarantee that the
remote application accepted the call request.

#### `sco_timeout_ms`
The SCO link is the voice transport path. It can fail independently from the
control socket, so it gets its own timeout instead of reusing the control one.

#### `hold_seconds`
This keeps the sample call active long enough to verify that the control and
SCO links stay healthy. It is useful in testing and later automation.

#### `require_audio_ready_ack`
This check exists because a peer can logically accept a call but still not be
ready to move audio. Waiting for `AUDIO-READY` prevents the local side from
assuming that audio is usable too early.

#### `require_sco_write_probe`
The SCO write probe is a local post-check. It validates that the local audio
transport path accepts frames. Without it, `connect()` success would be the only
local proof of audio readiness, which is weaker.

### Runtime registry notes

The persistent registry still stores only long-lived fields:

- host identifier
- index
- mac
- name
- paired
- connected

Call-related fields such as `rfcomm_connected`, `sco_connected`,
`audio_verified`, `call_selected`, and `call_state` are runtime-only and exist
only while the process is running. This is intentional because live socket file
descriptors cannot be restored safely by a later CLI run.

### Source files to read first for future updates

- `include/bt_call.h`
  - call option meanings and result structure
- `src/bt_call.c`
  - full checked call pipeline
- `include/bt_context.h`
  - per-device runtime call state fields
- `src/main.c`
  - CLI argument parsing for call options
