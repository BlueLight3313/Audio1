#ifndef BT_ADAPTER_H
#define BT_ADAPTER_H

#include "bt_platform.h"
#include "bt_types.h"

int bt_adapter_list(struct bt_adapter_summary *items, size_t capacity, size_t *count_out);
int bt_adapter_get_info(int ctl_sock, uint16_t dev_id, struct hci_dev_info *info);
int bt_adapter_power_set(uint16_t dev_id, bool power_on);
int bt_adapter_get_status(uint16_t dev_id, struct bt_adapter_status *status);
int bt_adapter_set_discoverable(uint16_t dev_id, bool enable);
int bt_adapter_set_local_name(uint16_t dev_id, const char *name);

#endif
