
#include <stdio.h>
#include "../include/bt.h"

bt_result_t bt_connect(const char*mac){
    bt_result_t r={BT_OK,0};
    printf("Connect to %s (stub)\n",mac);
    return r;
}
