
#include <unistd.h>
#include <stdio.h>

int bt_sco_connect(const char *mac){
    (void)mac;
    return 2; // fake fd
}

int bt_sco_send(int fd, void *buf, int len){
    return write(fd, buf, len);
}

int bt_sco_recv(int fd, void *buf, int len){
    return read(fd, buf, len);
}
