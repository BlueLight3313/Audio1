# bt_native

Minimal native C Bluetooth utility project with no dependency on BlueZ development headers or `-lbluetooth`.

## Features

- Adapter existence check
- Classic BR/EDR scan using BlueZ kernel management interface
- Classic pairing using Just Works / NoInputNoOutput
- Classic transport-level connect test using L2CAP SDP
- Connected device listing

## Build

```bash
make
```

## Run

```bash
sudo ./bt_native check
sudo ./bt_native scan 0 8
sudo ./bt_native pair AA:BB:CC:DD:EE:FF 0
sudo ./bt_native connect AA:BB:CC:DD:EE:FF
sudo ./bt_native connections 0
```

## Result semantics

- `CHECK: SUCCESS` means the requested adapter index exists.
- `SCAN: SUCCESS` means discovery started and at least one device was found.
- `PAIR: SUCCESS` means the mgmt pairing command completed successfully.
- `CONNECT: SUCCESS` means the L2CAP SDP transport connection succeeded.
- `CONNECTIONS: SUCCESS` means the connected-device query completed successfully.

## Notes

- This project is intentionally minimal and native-C only.
- The `connect` step validates a concrete classic transport-level connection, not higher-level profile connection state.
- For PIN-based pairing, you would need to add management event handling for PIN requests and replies.
