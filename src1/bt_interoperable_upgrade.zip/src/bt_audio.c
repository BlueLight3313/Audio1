
#define _XOPEN_SOURCE 600
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#define FRAME 160

static int sco_fd;
static int mic, spk;
static pthread_t t1, t2;
static int run=0;

void* tx(void*arg){
    int16_t buf[80];
    while(run){
        int n = read(mic, buf, FRAME);
        if(n>0) write(sco_fd, buf, n);
    }
    return 0;
}

void* rx(void*arg){
    int16_t buf[80];
    while(run){
        int n = read(sco_fd, buf, FRAME);
        if(n>0) write(spk, buf, n);
    }
    return 0;
}

int bt_audio_start(int sco){
    sco_fd = sco;
    mic = open("/dev/dsp", O_RDONLY);
    spk = open("/dev/dsp", O_WRONLY);

    run=1;
    pthread_create(&t1,NULL,tx,NULL);
    pthread_create(&t2,NULL,rx,NULL);
    return 0;
}
