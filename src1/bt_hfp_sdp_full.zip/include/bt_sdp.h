
#ifndef BT_SDP_H
#define BT_SDP_H
int bt_sdp_register_ag(uint8_t channel);
#endif
