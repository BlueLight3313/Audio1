#ifndef BT_COMPAT_SCO_H
#define BT_COMPAT_SCO_H

#include <stdint.h>
#include <sys/socket.h>
#include "bluetooth.h"

#ifndef BTPROTO_SCO
#define BTPROTO_SCO 2
#endif

struct sockaddr_sco {
    sa_family_t sco_family;
    bdaddr_t sco_bdaddr;
};

#endif
