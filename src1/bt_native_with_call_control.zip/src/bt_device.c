#include <stdio.h>
#include <string.h>

#include "bt_defs.h"
#include "bt_adapter.h"
#include "bt_device.h"

static struct bt_device_record g_device_cache[BT_DEVICE_CACHE_CAPACITY];
static size_t g_device_count = 0;

static int bt_bdaddr_equal(const bt_bdaddr_t *a, const bt_bdaddr_t *b)
{
    return memcmp(a->b, b->b, 6) == 0;
}

static void bt_device_update_classification(struct bt_device_record *record)
{
    if (record == NULL) {
        return;
    }

    if (!record->has_cod) {
        record->type = BT_REMOTE_UNKNOWN;
        record->policy = BT_PAIR_CONFIRM;
        return;
    }

    record->type = bt_classify_cod(record->cod);
    record->policy = bt_recommend_policy(record->type);
}

void bt_device_cache_clear(void)
{
    memset(g_device_cache, 0, sizeof(g_device_cache));
    g_device_count = 0;
}

size_t bt_device_cache_count(void)
{
    return g_device_count;
}

struct bt_device_record *bt_device_cache_get(size_t index)
{
    if (index >= g_device_count) {
        return NULL;
    }
    return &g_device_cache[index];
}

const struct bt_device_record *bt_device_cache_get_const(size_t index)
{
    if (index >= g_device_count) {
        return NULL;
    }
    return &g_device_cache[index];
}

const struct bt_device_record *bt_device_cache_find_by_address_text(const char *address_text)
{
    size_t i;

    if (address_text == NULL) {
        return NULL;
    }

    for (i = 0; i < g_device_count; ++i) {
        if (strcmp(g_device_cache[i].address_text, address_text) == 0) {
            return &g_device_cache[i];
        }
    }

    return NULL;
}

struct bt_device_record *bt_device_cache_add_or_update_basic(
    const bt_bdaddr_t *bdaddr,
    const uint8_t cod[3],
    uint8_t page_scan_rep_mode,
    uint16_t clock_offset,
    int has_rssi,
    int8_t rssi
)
{
    size_t i;
    char mac_text[18];

    if (bdaddr == NULL) {
        return NULL;
    }

    for (i = 0; i < g_device_count; ++i) {
        if (bt_bdaddr_equal(&g_device_cache[i].bdaddr, bdaddr)) {
            if (cod != NULL) {
                memcpy(g_device_cache[i].cod, cod, sizeof(g_device_cache[i].cod));
                g_device_cache[i].has_cod = 1;
                bt_device_update_classification(&g_device_cache[i]);
            }

            g_device_cache[i].page_scan_rep_mode = page_scan_rep_mode;
            g_device_cache[i].clock_offset = clock_offset;

            if (has_rssi) {
                g_device_cache[i].rssi = rssi;
                g_device_cache[i].has_rssi = 1;
            }

            return &g_device_cache[i];
        }
    }

    if (g_device_count >= BT_DEVICE_CACHE_CAPACITY) {
        return NULL;
    }

    memset(&g_device_cache[g_device_count], 0, sizeof(g_device_cache[g_device_count]));
    g_device_cache[g_device_count].bdaddr = *bdaddr;
    g_device_cache[g_device_count].page_scan_rep_mode = page_scan_rep_mode;
    g_device_cache[g_device_count].clock_offset = clock_offset;

    if (cod != NULL) {
        memcpy(g_device_cache[g_device_count].cod, cod, sizeof(g_device_cache[g_device_count].cod));
        g_device_cache[g_device_count].has_cod = 1;
    }

    if (has_rssi) {
        g_device_cache[g_device_count].rssi = rssi;
        g_device_cache[g_device_count].has_rssi = 1;
    }

    bt_format_bdaddr(bdaddr->b, mac_text, sizeof(mac_text));
    memcpy(g_device_cache[g_device_count].address_text, mac_text, sizeof(mac_text));

    bt_device_update_classification(&g_device_cache[g_device_count]);

    ++g_device_count;
    return &g_device_cache[g_device_count - 1];
}

void bt_device_cache_set_name(const bt_bdaddr_t *bdaddr, const char *name)
{
    size_t i;
    size_t len;

    if (bdaddr == NULL || name == NULL) {
        return;
    }

    for (i = 0; i < g_device_count; ++i) {
        if (bt_bdaddr_equal(&g_device_cache[i].bdaddr, bdaddr)) {
            len = 0;
            while (len < sizeof(g_device_cache[i].name) - 1 && name[len] != '\0') {
                g_device_cache[i].name[len] = name[len];
                ++len;
            }
            g_device_cache[i].name[len] = '\0';
            g_device_cache[i].has_name = 1;
            return;
        }
    }
}

void bt_device_cache_print(void)
{
    size_t i;

    if (g_device_count == 0) {
        printf("No scanned devices stored.\n");
        return;
    }

    printf("Stored devices: %lu\n", (unsigned long)g_device_count);

    for (i = 0; i < g_device_count; ++i) {
        printf(
            "%3lu. %s | %s | type=%s | policy=%s",
            (unsigned long)(i + 1),
            g_device_cache[i].address_text,
            g_device_cache[i].has_name ? g_device_cache[i].name : "<unknown>",
            bt_type_str(g_device_cache[i].type),
            bt_policy_str(g_device_cache[i].policy)
        );

        if (g_device_cache[i].has_rssi) {
            printf(" | RSSI %d", (int)g_device_cache[i].rssi);
        }

        printf("\n");
    }
}
