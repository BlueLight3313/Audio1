#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include "bt_defs.h"
#include "bt_types.h"
#include "bt_log.h"
#include "bt_sms.h"

static int bt_sms_validate_text(const char *text)
{
    size_t len;

    if (text == NULL) {
        errno = EINVAL;
        return -1;
    }

    len = strlen(text);
    if (len == 0 || len > BT_SMS_MAX_TEXT_LENGTH) {
        errno = EINVAL;
        return -1;
    }

    return 0;
}

int bt_sms_send_to_device(
    const struct bt_device_record *device,
    const char *identifier,
    const char *text,
    uint8_t rfcomm_channel
)
{
    int sock;
    struct sockaddr_rc addr;
    char payload[BT_SMS_MAX_PAYLOAD_LENGTH];
    int written;
    ssize_t sent_len;

    if (device == NULL || identifier == NULL) {
        errno = EINVAL;
        return -1;
    }

    if (bt_sms_validate_text(text) < 0) {
        return -1;
    }

    written = snprintf(payload, sizeof(payload), "%s %s", identifier, text);
    if (written < 0 || written >= (int)sizeof(payload)) {
        errno = EMSGSIZE;
        return -1;
    }

    memset(&addr, 0, sizeof(addr));
    addr.rc_family = AF_BLUETOOTH;
    addr.rc_bdaddr = device->bdaddr;
    addr.rc_channel = rfcomm_channel;

    sock = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);
    if (sock < 0) {
        return -1;
    }

    bt_log_info(
        "Sending app message to %s on RFCOMM channel %u",
        device->address_text,
        (unsigned int)rfcomm_channel
    );

    if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        close(sock);
        return -1;
    }

    sent_len = send(sock, payload, (size_t)written, 0);
    if (sent_len != written) {
        close(sock);
        errno = EIO;
        return -1;
    }

    bt_log_info("Message sent to %s", device->address_text);

    close(sock);
    return 0;
}
