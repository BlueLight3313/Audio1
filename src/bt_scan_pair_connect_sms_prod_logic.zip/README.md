# bt_scan_pair_connect_prod_all_ctx_sms

A native C Bluetooth BR/EDR project with **scan + pair + connect + sms** and a persistent device registry.

## Commands

```bash
make
./bt_prod hostid MY-DEVICE-ID
sudo ./bt_prod scan 0 8
sudo ./bt_prod pair all 0 8 --io-cap 3 --confirm yes
sudo ./bt_prod connect all 0 8 --verify-timeout-ms 3000 --hold-ms 1000
./bt_prod state
./bt_prod sms AA:BB:CC:DD:EE:FF hello from host
./bt_prod sms all broadcast message
```

## Host identifier

The project keeps a host identifier string in the runtime registry. You can set it with:

```bash
./bt_prod hostid MY-DEVICE-ID
```

You can also initialize it with the environment variable `BT_HOST_ID`.

## SMS behavior

The `sms` command sends an application-level SMS request payload over **RFCOMM channel 1**:

```text
SMS|<HOST-ID>|<MESSAGE-ID>|<TEXT>\n
```

### Logical error handler

Before sending, the project runs a **sendable-check**:
- device must exist in the registry
- device must be marked connected
- host identifier must exist
- text must be non-empty and within the size limit

After writing the payload, the project waits for a peer acknowledgement line for up to 5 seconds:

```text
SMS-RESULT|<MESSAGE-ID>|<CODE>|<DETAIL>\n
```

A simplified reply of only the numeric code is also accepted.

### Delivery result codes

- `2` = received
- `3` = not sent
- `4` = confirming
- `7` = unknown

The CLI prints:
- `sendable`
- `ack_received`
- `result=<code>(<meaning>)`
- `message_id`
- detailed text

### Important

This does **not** send a cellular SMS by itself.
The remote Bluetooth device must run a peer application or service that listens on RFCOMM channel 1, parses the payload, sends the real SMS on that remote device, and replies with the logical result line above.

- `sms <MAC> <TEXT>` sends to one target in the registry.
- `sms all <TEXT>` sends to all devices currently marked `connected=1` in the saved registry.

## State persistence

The registry is saved to `bt_runtime_state.txt` in the current working directory and keeps:

- host identifier
- index
- mac
- name
- paired
- connected

This lets separate CLI runs reuse the same state file.
