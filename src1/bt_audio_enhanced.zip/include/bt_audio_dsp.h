
#ifndef BT_AUDIO_DSP_H
#define BT_AUDIO_DSP_H
#include <stdint.h>
void dsp_process(int16_t *buf, int n);
#endif
