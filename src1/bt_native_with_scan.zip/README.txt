
bt_native_with_scan

Added:
- inquiry scan support
- in-memory device cache for nearby devices
- local MAC getter via HCIGETDEVINFO
- local name getter via HCI Read Local Name
- remote name resolution after inquiry
- devices command to list stored scan results

Build:
    make

Run:
    sudo systemctl stop bluetooth
    sudo ./bt_native

Commands:
    status
    discoverable on
    discoverable off
    power on
    power off
    scan
    devices
    help
    quit
