
#define _XOPEN_SOURCE 600
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#define FRAME_SAMPLES 80
#define FRAME_BYTES 160
#define JB_SIZE 64

static int sco_fd;
static int dsp_in, dsp_out;
static pthread_t th_cap, th_play;
static int run=0;

/* jitter buffer */
static int16_t jb[JB_SIZE][FRAME_SAMPLES];
static int jb_head=0, jb_tail=0;

/* push */
static void jb_push(int16_t *data){
    memcpy(jb[jb_head], data, FRAME_BYTES);
    jb_head=(jb_head+1)%JB_SIZE;
}

/* pop */
static int jb_pop(int16_t *out){
    if(jb_head==jb_tail) return -1;
    memcpy(out, jb[jb_tail], FRAME_BYTES);
    jb_tail=(jb_tail+1)%JB_SIZE;
    return 0;
}

/* simple DSP */
static void dsp(int16_t *buf){
    static int16_t prev=0;
    for(int i=0;i<FRAME_SAMPLES;i++){
        int16_t x=buf[i];
        int16_t y=x - prev + (prev>>1);
        prev=x;
        buf[i]=y;
    }
}

/* capture thread */
static void* capture_thread(void*arg){
    (void)arg;
    int16_t buf[FRAME_SAMPLES];

    while(run){
        int n=read(dsp_in, buf, FRAME_BYTES);
        if(n<=0) continue;

        dsp(buf);
        write(sco_fd, buf, FRAME_BYTES);
    }
    return NULL;
}

/* playback thread */
static void* playback_thread(void*arg){
    (void)arg;
    int16_t buf[FRAME_SAMPLES];
    int16_t out[FRAME_SAMPLES];

    while(run){
        int n=read(sco_fd, buf, FRAME_BYTES);
        if(n>0){
            jb_push(buf);
        }

        if(jb_pop(out)==0){
            write(dsp_out, out, FRAME_BYTES);
        }else{
            memset(out,0,FRAME_BYTES);
            write(dsp_out, out, FRAME_BYTES);
        }

        usleep(10000); // 10ms pacing
    }
    return NULL;
}

int bt_audio_start(int sco){
    sco_fd=sco;

    dsp_in=open("/dev/dsp",O_RDONLY);
    dsp_out=open("/dev/dsp",O_WRONLY);

    if(dsp_in<0 || dsp_out<0){
        perror("dsp open");
        return -1;
    }

    run=1;
    pthread_create(&th_cap,NULL,capture_thread,NULL);
    pthread_create(&th_play,NULL,playback_thread,NULL);

    return 0;
}

void bt_audio_stop(){
    run=0;
    pthread_join(th_cap,NULL);
    pthread_join(th_play,NULL);
    close(dsp_in);
    close(dsp_out);
}
