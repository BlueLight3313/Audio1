#ifndef BT_DEVICE_H
#define BT_DEVICE_H

#include <stddef.h>
#include <stdint.h>

#include "bt_classify.h"
#include "bt_types.h"

struct bt_device_record {
    bt_bdaddr_t bdaddr;
    char address_text[18];
    char name[249];
    uint8_t cod[3];
    bt_remote_type_t type;
    bt_pair_policy_t policy;
    uint8_t page_scan_rep_mode;
    uint16_t clock_offset;
    int8_t rssi;
    uint8_t has_rssi;
    uint8_t has_name;
    uint8_t has_cod;
};

void bt_device_cache_clear(void);
size_t bt_device_cache_count(void);
struct bt_device_record *bt_device_cache_get(size_t index);
const struct bt_device_record *bt_device_cache_get_const(size_t index);
const struct bt_device_record *bt_device_cache_find_by_address_text(const char *address_text);

struct bt_device_record *bt_device_cache_add_or_update_basic(
    const bt_bdaddr_t *bdaddr,
    const uint8_t cod[3],
    uint8_t page_scan_rep_mode,
    uint16_t clock_offset,
    int has_rssi,
    int8_t rssi
);

void bt_device_cache_set_name(const bt_bdaddr_t *bdaddr, const char *name);
void bt_device_cache_print(void);

#endif
