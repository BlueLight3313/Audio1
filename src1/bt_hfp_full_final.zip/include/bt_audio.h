
#ifndef BT_AUDIO_H
#define BT_AUDIO_H
int bt_audio_start(int sco_fd);
void bt_audio_stop();
#endif
