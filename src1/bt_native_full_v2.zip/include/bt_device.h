
#ifndef BT_DEVICE_H
#define BT_DEVICE_H

#include <stdint.h>
#include "bt_classify.h"

#define BT_MAX_DEV 64

typedef struct {
    uint8_t mac[6];
    char mac_str[18];
    char name[248];

    uint8_t cod[3];
    int has_cod;

    bt_remote_type_t type;
    bt_pair_policy_t policy;

} bt_dev_t;

void bt_dev_add(uint8_t mac[6], uint8_t cod[3]);
void bt_dev_print_all(void);
bt_dev_t* bt_dev_get(int idx);

#endif
