#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <poll.h>

#include "../include/bt_pair.h"
#include "../include/bt_mgmt.h"

static int bt_pair_send_pin_reply(int sock, int adapter_index,
                                  const bdaddr_t *addr, uint8_t addr_type,
                                  const bt_pair_options_t *options,
                                  bt_pair_result_t *result)
{
    if (options->has_pin) {
        struct mgmt_cp_pin_code_reply cp;
        size_t pin_len = strlen(options->pin);

        memset(&cp, 0, sizeof(cp));
        bt_bacpy(&cp.addr, addr);
        cp.addr_type = addr_type;
        cp.pin_len = (uint8_t)pin_len;
        memcpy(cp.pin_code, options->pin, pin_len);

        if (bt_send_mgmt_cmd(sock, MGMT_OP_PIN_CODE_REPLY, (uint16_t)adapter_index,
                             &cp, sizeof(cp)) < 0)
            return -1;

        return 0;
    }

    {
        struct mgmt_cp_pin_code_neg_reply cp;
        memset(&cp, 0, sizeof(cp));
        bt_bacpy(&cp.addr, addr);
        cp.addr_type = addr_type;

        if (bt_send_mgmt_cmd(sock, MGMT_OP_PIN_CODE_NEG_REPLY, (uint16_t)adapter_index,
                             &cp, sizeof(cp)) < 0)
            return -1;

        result->cancelled = 1;
        snprintf(result->detail, sizeof(result->detail), "PIN requested but no PIN was provided");
        return 0;
    }
}

static int bt_pair_send_confirm_reply(int sock, int adapter_index,
                                      const bdaddr_t *addr, uint8_t addr_type,
                                      const bt_pair_options_t *options,
                                      bt_pair_result_t *result)
{
    if (options->auto_confirm) {
        struct mgmt_cp_user_confirm_reply cp;
        memset(&cp, 0, sizeof(cp));
        bt_bacpy(&cp.addr, addr);
        cp.addr_type = addr_type;

        return bt_send_mgmt_cmd(sock, MGMT_OP_USER_CONFIRM_REPLY, (uint16_t)adapter_index,
                                &cp, sizeof(cp));
    }

    {
        struct mgmt_cp_user_confirm_neg_reply cp;
        memset(&cp, 0, sizeof(cp));
        bt_bacpy(&cp.addr, addr);
        cp.addr_type = addr_type;

        result->cancelled = 1;
        snprintf(result->detail, sizeof(result->detail), "confirmation requested but auto-confirm is disabled");
        return bt_send_mgmt_cmd(sock, MGMT_OP_USER_CONFIRM_NEG_REPLY, (uint16_t)adapter_index,
                                &cp, sizeof(cp));
    }
}

static int bt_pair_send_passkey_reply(int sock, int adapter_index,
                                      const bdaddr_t *addr, uint8_t addr_type,
                                      const bt_pair_options_t *options,
                                      bt_pair_result_t *result)
{
    if (options->has_passkey) {
        struct mgmt_cp_user_passkey_reply cp;
        memset(&cp, 0, sizeof(cp));
        bt_bacpy(&cp.addr, addr);
        cp.addr_type = addr_type;
        cp.passkey = bt_cpu_to_le32(options->passkey);

        if (bt_send_mgmt_cmd(sock, MGMT_OP_USER_PASSKEY_REPLY, (uint16_t)adapter_index,
                             &cp, sizeof(cp)) < 0)
            return -1;

        return 0;
    }

    {
        struct mgmt_cp_user_passkey_neg_reply cp;
        memset(&cp, 0, sizeof(cp));
        bt_bacpy(&cp.addr, addr);
        cp.addr_type = addr_type;

        result->cancelled = 1;
        snprintf(result->detail, sizeof(result->detail), "passkey requested but no passkey was provided");
        return bt_send_mgmt_cmd(sock, MGMT_OP_USER_PASSKEY_NEG_REPLY, (uint16_t)adapter_index,
                                &cp, sizeof(cp));
    }
}

void bt_pair_options_init(bt_pair_options_t *options)
{
    memset(options, 0, sizeof(*options));
    options->io_capability = MGMT_IO_CAP_NO_INPUT_NO_OUTPUT;
    options->timeout_ms = 30000;
    options->require_new_link_key = 1;
    options->auto_confirm = 1;
}

bt_pair_result_t bt_pair_bredr(int adapter_index, const char *mac,
                               const bt_pair_options_t *options)
{
    bt_pair_result_t result;
    int sock;
    struct mgmt_cp_pair_device cp;
    uint8_t cmd_status = 0xff;
    uint8_t cmd_data[64];
    size_t cmd_data_len = sizeof(cmd_data);
    struct pollfd pfd;
    uint8_t buf[2048];
    int remaining_ms;
    bdaddr_t target;

    memset(&result, 0, sizeof(result));
    result.status = BT_STATUS_FAIL;
    result.mgmt_status = 0xff;
    snprintf(result.detail, sizeof(result.detail), "pairing did not complete");

    if (bt_str2ba(mac, &target) < 0) {
        result.status = BT_STATUS_PROTOCOL;
        snprintf(result.detail, sizeof(result.detail), "invalid MAC address");
        return result;
    }

    sock = bt_open_mgmt_socket();
    if (sock < 0) {
        result.status = BT_STATUS_FAIL;
        snprintf(result.detail, sizeof(result.detail), "failed to open mgmt socket");
        return result;
    }

    memset(&cp, 0, sizeof(cp));
    bt_bacpy(&cp.addr, &target);
    cp.addr_type = MGMT_ADDR_BREDR;
    cp.io_cap = options->io_capability;

    if (bt_send_mgmt_cmd(sock, MGMT_OP_PAIR_DEVICE, (uint16_t)adapter_index,
                         &cp, sizeof(cp)) < 0) {
        close(sock);
        result.status = BT_STATUS_FAIL;
        snprintf(result.detail, sizeof(result.detail), "failed to send Pair Device");
        return result;
    }

    if (bt_wait_mgmt_cmd_result(sock, MGMT_OP_PAIR_DEVICE, (uint16_t)adapter_index,
                                &cmd_status, cmd_data, &cmd_data_len, 3000) < 0) {
        close(sock);
        result.status = BT_STATUS_TIMEOUT;
        snprintf(result.detail, sizeof(result.detail), "timed out waiting for Pair Device command result");
        return result;
    }

    result.mgmt_status = cmd_status;

    if (cmd_status == MGMT_STATUS_ALREADY_PAIRED) {
        result.status = BT_STATUS_ALREADY;
        result.bonded = 1;
        snprintf(result.detail, sizeof(result.detail), "device is already paired");
        close(sock);
        return result;
    }

    if (cmd_status != MGMT_STATUS_SUCCESS) {
        result.status = (cmd_status == MGMT_STATUS_TIMEOUT) ? BT_STATUS_TIMEOUT :
                        (cmd_status == MGMT_STATUS_NOT_PAIRED) ? BT_STATUS_NOT_PAIRED :
                        BT_STATUS_REMOTE;
        snprintf(result.detail, sizeof(result.detail), "Pair Device failed: %s",
                 bt_mgmt_status_str(cmd_status));
        close(sock);
        return result;
    }

    pfd.fd = sock;
    pfd.events = POLLIN;
    remaining_ms = options->timeout_ms;

    while (remaining_ms > 0) {
        int step = remaining_ms > 1000 ? 1000 : remaining_ms;
        int pr = poll(&pfd, 1, step);

        remaining_ms -= step;

        if (pr < 0) {
            result.status = BT_STATUS_FAIL;
            snprintf(result.detail, sizeof(result.detail), "poll failed during pairing");
            break;
        }

        if (pr == 0)
            continue;

        if (pfd.revents & POLLIN) {
            ssize_t n = read(sock, buf, sizeof(buf));
            struct mgmt_hdr *hdr;
            uint16_t evt, idx, len;

            if (n < (ssize_t)sizeof(*hdr))
                continue;

            hdr = (struct mgmt_hdr *)buf;
            evt = bt_le16_to_cpu(hdr->opcode);
            idx = bt_le16_to_cpu(hdr->index);
            len = bt_le16_to_cpu(hdr->len);

            if ((int)idx != adapter_index)
                continue;

            if (evt == MGMT_EV_PIN_CODE_REQUEST) {
                struct mgmt_ev_pin_code_request *ev;
                ev = (struct mgmt_ev_pin_code_request *)(buf + sizeof(*hdr));

                if (len < sizeof(*ev) || !bt_addr_equals(&ev->addr, &target))
                    continue;

                if (bt_pair_send_pin_reply(sock, adapter_index, &ev->addr, ev->addr_type,
                                           options, &result) < 0) {
                    result.status = BT_STATUS_FAIL;
                    snprintf(result.detail, sizeof(result.detail), "failed to send PIN reply");
                    break;
                }
            } else if (evt == MGMT_EV_USER_CONFIRM_REQUEST) {
                struct mgmt_ev_user_confirm_request *ev;
                ev = (struct mgmt_ev_user_confirm_request *)(buf + sizeof(*hdr));

                if (len < sizeof(*ev) || !bt_addr_equals(&ev->addr, &target))
                    continue;

                if (bt_pair_send_confirm_reply(sock, adapter_index, &ev->addr, ev->addr_type,
                                               options, &result) < 0) {
                    result.status = BT_STATUS_FAIL;
                    snprintf(result.detail, sizeof(result.detail), "failed to send confirmation reply");
                    break;
                }
            } else if (evt == MGMT_EV_USER_PASSKEY_REQUEST) {
                struct mgmt_ev_user_passkey_request *ev;
                ev = (struct mgmt_ev_user_passkey_request *)(buf + sizeof(*hdr));

                if (len < sizeof(*ev) || !bt_addr_equals(&ev->addr, &target))
                    continue;

                if (bt_pair_send_passkey_reply(sock, adapter_index, &ev->addr, ev->addr_type,
                                               options, &result) < 0) {
                    result.status = BT_STATUS_FAIL;
                    snprintf(result.detail, sizeof(result.detail), "failed to send passkey reply");
                    break;
                }
            } else if (evt == MGMT_EV_NEW_LINK_KEY) {
                struct mgmt_ev_new_link_key *ev;
                ev = (struct mgmt_ev_new_link_key *)(buf + sizeof(*hdr));

                if (len < sizeof(*ev) || !bt_addr_equals(&ev->addr, &target))
                    continue;

                result.new_link_key_seen = 1;
            } else if (evt == MGMT_EV_AUTH_FAILED) {
                struct mgmt_ev_auth_failed *ev;
                ev = (struct mgmt_ev_auth_failed *)(buf + sizeof(*hdr));

                if (len < sizeof(*ev) || !bt_addr_equals(&ev->addr, &target))
                    continue;

                result.auth_failed = 1;
                result.mgmt_status = ev->status;
                result.status = (ev->status == MGMT_STATUS_CANCELLED) ?
                                BT_STATUS_TIMEOUT : BT_STATUS_REMOTE;
                snprintf(result.detail, sizeof(result.detail), "authentication failed: %s",
                         bt_mgmt_status_str(ev->status));
                break;
            } else if (evt == MGMT_EV_DEVICE_CONNECTED) {
                struct mgmt_ev_device_connected *ev;
                ev = (struct mgmt_ev_device_connected *)(buf + sizeof(*hdr));

                if (len < sizeof(*ev) || !bt_addr_equals(&ev->addr, &target))
                    continue;

                result.connected = 1;
            } else if (evt == MGMT_EV_CMD_COMPLETE) {
                struct mgmt_ev_cmd_complete *cc;
                uint16_t cmd_opcode;

                if (len < sizeof(*cc))
                    continue;

                cc = (struct mgmt_ev_cmd_complete *)(buf + sizeof(*hdr));
                cmd_opcode = bt_le16_to_cpu(cc->opcode);

                if (cmd_opcode == MGMT_OP_PIN_CODE_REPLY ||
                    cmd_opcode == MGMT_OP_USER_CONFIRM_REPLY ||
                    cmd_opcode == MGMT_OP_USER_PASSKEY_REPLY) {
                    if (cc->status != MGMT_STATUS_SUCCESS) {
                        result.mgmt_status = cc->status;
                        result.status = BT_STATUS_REMOTE;
                        snprintf(result.detail, sizeof(result.detail),
                                 "authentication reply failed: %s",
                                 bt_mgmt_status_str(cc->status));
                        break;
                    }
                } else if (cmd_opcode == MGMT_OP_PIN_CODE_NEG_REPLY ||
                           cmd_opcode == MGMT_OP_USER_CONFIRM_NEG_REPLY ||
                           cmd_opcode == MGMT_OP_USER_PASSKEY_NEG_REPLY ||
                           cmd_opcode == MGMT_OP_CANCEL_PAIR_DEVICE) {
                    result.mgmt_status = cc->status;
                    result.cancelled = 1;
                    result.status = BT_STATUS_REMOTE;
                    snprintf(result.detail, sizeof(result.detail),
                             "pairing cancelled or rejected");
                    break;
                } else if (cmd_opcode == MGMT_OP_PAIR_DEVICE) {
                    result.mgmt_status = cc->status;
                    if (cc->status == MGMT_STATUS_SUCCESS) {
                        if (!options->require_new_link_key || result.new_link_key_seen) {
                            result.status = BT_STATUS_OK;
                            result.bonded = 1;
                            snprintf(result.detail, sizeof(result.detail), "pairing completed successfully");
                            break;
                        }
                    } else if (cc->status == MGMT_STATUS_ALREADY_PAIRED) {
                        result.status = BT_STATUS_ALREADY;
                        result.bonded = 1;
                        snprintf(result.detail, sizeof(result.detail), "device already paired");
                        break;
                    } else {
                        result.status = BT_STATUS_REMOTE;
                        snprintf(result.detail, sizeof(result.detail), "pairing failed: %s",
                                 bt_mgmt_status_str(cc->status));
                        break;
                    }
                }
            } else if (evt == MGMT_EV_CMD_STATUS) {
                struct mgmt_ev_cmd_status *cs;
                uint16_t cmd_opcode;

                if (len < sizeof(*cs))
                    continue;

                cs = (struct mgmt_ev_cmd_status *)(buf + sizeof(*hdr));
                cmd_opcode = bt_le16_to_cpu(cs->opcode);

                if (cmd_opcode == MGMT_OP_PAIR_DEVICE ||
                    cmd_opcode == MGMT_OP_PIN_CODE_REPLY ||
                    cmd_opcode == MGMT_OP_PIN_CODE_NEG_REPLY ||
                    cmd_opcode == MGMT_OP_USER_CONFIRM_REPLY ||
                    cmd_opcode == MGMT_OP_USER_CONFIRM_NEG_REPLY ||
                    cmd_opcode == MGMT_OP_USER_PASSKEY_REPLY ||
                    cmd_opcode == MGMT_OP_USER_PASSKEY_NEG_REPLY) {
                    result.mgmt_status = cs->status;
                    result.status = BT_STATUS_REMOTE;
                    snprintf(result.detail, sizeof(result.detail), "pairing command status error: %s",
                             bt_mgmt_status_str(cs->status));
                    break;
                }
            }
        }
    }

    if (result.status == BT_STATUS_FAIL && remaining_ms <= 0) {
        struct mgmt_cp_pin_code_neg_reply cancel_cp;
        memset(&cancel_cp, 0, sizeof(cancel_cp));
        bt_bacpy(&cancel_cp.addr, &target);
        cancel_cp.addr_type = MGMT_ADDR_BREDR;
        bt_send_mgmt_cmd(sock, MGMT_OP_CANCEL_PAIR_DEVICE, (uint16_t)adapter_index,
                         &cancel_cp, sizeof(cancel_cp));

        result.status = BT_STATUS_TIMEOUT;
        result.cancelled = 1;
        snprintf(result.detail, sizeof(result.detail), "pairing timed out");
    }

    if (result.status == BT_STATUS_OK && options->require_new_link_key && !result.new_link_key_seen) {
        result.status = BT_STATUS_FAIL;
        result.bonded = 0;
        snprintf(result.detail, sizeof(result.detail),
                 "pair command completed but New Link Key was not observed");
    }

    close(sock);
    return result;
}
