#include <errno.h>

#include "bt_log.h"
#include "bt_sco.h"

static int g_bt_sco_open = 0;

int bt_sco_open(const bt_bdaddr_t *bdaddr)
{
    if (bdaddr == NULL) {
        errno = EINVAL;
        return -1;
    }

    if (g_bt_sco_open) {
        return 0;
    }

    /*
     * Placeholder for future SCO/eSCO transport:
     *   - create SCO socket
     *   - bind to local adapter
     *   - connect to remote device
     */
    g_bt_sco_open = 1;
    bt_log_info("SCO audio transport opened");
    return 0;
}

void bt_sco_close(void)
{
    if (!g_bt_sco_open) {
        return;
    }

    g_bt_sco_open = 0;
    bt_log_info("SCO audio transport closed");
}
