#ifndef BT_SMS_H
#define BT_SMS_H

#include "bt_common.h"
#include "bt_context.h"

typedef struct {
    bt_status_t status;
    int targets_attempted;
    int targets_sent;
    char detail[128];
} bt_sms_result_t;

void bt_sms_result_init(bt_sms_result_t *result);
bt_sms_result_t bt_sms_send_to_mac(bt_context_t *ctx, const char *mac,
                                   const char *text, uint8_t channel);
bt_sms_result_t bt_sms_send_all_connected(bt_context_t *ctx, const char *text,
                                          uint8_t channel);

#endif
