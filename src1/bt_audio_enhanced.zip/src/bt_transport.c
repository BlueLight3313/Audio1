
#include "bt_transport.h"
#include <stdio.h>

int bt_transport_send_packet(bt_audio_packet_t *p){
    (void)p;
    return 0;
}

int bt_transport_recv_packet(bt_audio_packet_t *p){
    (void)p;
    return -1;
}
