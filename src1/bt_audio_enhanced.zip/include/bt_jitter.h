
#ifndef BT_JITTER_H
#define BT_JITTER_H

#include "bt_audio_packet.h"

void jb_init();
int jb_push(bt_audio_packet_t *p);
int jb_pop(bt_audio_packet_t *p);

#endif
