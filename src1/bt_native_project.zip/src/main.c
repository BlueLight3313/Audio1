
#include <stdio.h>
#include <unistd.h>

#include "bt_adapter.h"
#include "bt_log.h"

int main() {
    int sock = bt_hci_open();
    if (sock < 0) {
        bt_log("ERROR", "Failed to open HCI socket");
        return -1;
    }

    if (bt_hci_bind(sock, 0) < 0) {
        bt_log("ERROR", "Bind failed");
        return -1;
    }

    if (bt_adapter_check(sock, 0) < 0) {
        bt_log("ERROR", "No adapter");
        return -1;
    }

    bt_log("INFO", "Adapter found");

    bt_adapter_up(sock, 0);
    bt_log("INFO", "Power ON");

    bt_set_discoverable(sock);
    bt_log("INFO", "Discoverable enabled");

    while (1) {
        printf("bt> ");
        char cmd[64];
        fgets(cmd, sizeof(cmd), stdin);

        if (strncmp(cmd, "exit", 4) == 0)
            break;
    }

    close(sock);
    return 0;
}
