
#ifndef BT_CALL_H
#define BT_CALL_H

typedef enum {
    CALL_IDLE = 0,
    CALL_OUTGOING,
    CALL_INCOMING,
    CALL_ACTIVE
} call_state_t;

void bt_call_init(void);
void bt_call_dial(const char *mac, const char *identifier);
void bt_call_incoming(const char *mac, const char *identifier);
void bt_call_accept(void);
void bt_call_reject(void);
void bt_call_hangup(void);
void bt_call_remote_event(int type, const char *payload);
void bt_call_print(void);

#endif
