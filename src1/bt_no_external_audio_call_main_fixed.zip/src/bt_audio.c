
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <stdint.h>
#include <pthread.h>

#define AFMT_S16_LE 0x10

static int dsp_in = -1;
static int dsp_out = -1;
static pthread_t th;
static int run = 0;

extern int bt_transport_send(void*,int);
extern int bt_transport_recv(void*,int);

static int open_dsp(int *fd, int flags)
{
    *fd = open("/dev/dsp", flags);
    if(*fd < 0) return -1;

    int format = AFMT_S16_LE;
    int channels = 1;
    int rate = 8000;

    ioctl(*fd, 0x5005, &format);   // SNDCTL_DSP_SETFMT
    ioctl(*fd, 0x5006, &channels); // SNDCTL_DSP_CHANNELS
    ioctl(*fd, 0x5002, &rate);     // SNDCTL_DSP_SPEED

    return 0;
}

static void* loop(void*arg)
{
    int16_t mic[160];
    int16_t spk[160];

    while(run){
        read(dsp_in, mic, 320);

        bt_transport_send(mic, 320);

        int n = bt_transport_recv(spk, 320);
        if(n > 0){
            write(dsp_out, spk, 320);
        }
    }
    return 0;
}

int bt_audio_start()
{
    if(run) return 0;

    if(open_dsp(&dsp_in, O_RDONLY) < 0) return -1;
    if(open_dsp(&dsp_out, O_WRONLY) < 0) return -1;

    run = 1;
    pthread_create(&th, 0, loop, 0);
    return 0;
}

void bt_audio_stop()
{
    if(!run) return;

    run = 0;
    pthread_join(th, 0);

    close(dsp_in);
    close(dsp_out);
}
