
#ifndef BT_TRANSPORT_H
#define BT_TRANSPORT_H
#include "bt_audio_packet.h"
int bt_transport_send_packet(bt_audio_packet_t *p);
int bt_transport_recv_packet(bt_audio_packet_t *p);
#endif
