#include <stdio.h>
#include <stdarg.h>
#include <time.h>

#include "../include/bt_log.h"

const char *bt_log_state_str(bt_log_state_t state)
{
    switch (state) {
    case BT_LOG_READY: return "ready";
    case BT_LOG_STARTED: return "started";
    case BT_LOG_DOING: return "doing";
    case BT_LOG_DONE: return "done";
    case BT_LOG_RESULT: return "result";
    case BT_LOG_ERROR: return "error";
    default: return "unknown";
    }
}

static void bt_log_timestamp(char *out, size_t out_sz)
{
    time_t now;
    struct tm tm_now;

    if (!out || out_sz == 0)
        return;

    now = time(NULL);
    if (localtime_r(&now, &tm_now) == NULL) {
        snprintf(out, out_sz, "0000-00-00 00:00:00");
        return;
    }

    strftime(out, out_sz, "%Y-%m-%d %H:%M:%S", &tm_now);
}

void bt_logf(const char *scope, bt_log_state_t state, const char *fmt, ...)
{
    va_list ap;
    char ts[32];

    bt_log_timestamp(ts, sizeof(ts));
    fprintf(stderr, "[%s] [%s] [%s] ", ts, scope ? scope : "core", bt_log_state_str(state));

    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);

    fputc('\n', stderr);
}

void bt_log_result_status(const char *scope, bt_status_t status, const char *fmt, ...)
{
    va_list ap;
    char ts[32];

    bt_log_timestamp(ts, sizeof(ts));
    fprintf(stderr, "[%s] [%s] [result] status=%s", ts, scope ? scope : "core", bt_status_str(status));
    if (fmt && fmt[0]) {
        fprintf(stderr, " ");
        va_start(ap, fmt);
        vfprintf(stderr, fmt, ap);
        va_end(ap);
    }
    fputc('\n', stderr);
}
