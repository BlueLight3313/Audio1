#ifndef BT_SMS_H
#define BT_SMS_H

#include "bt_common.h"
#include "bt_context.h"

typedef enum {
    BT_SMS_RESULT_RECEIVED = 2,
    BT_SMS_RESULT_NOT_SENT = 3,
    BT_SMS_RESULT_CONFIRMING = 4,
    BT_SMS_RESULT_UNKNOWN = 7
} bt_sms_delivery_code_t;

typedef struct {
    bt_status_t status;
    int sendable;
    int targets_attempted;
    int targets_sent;
    int ack_received;
    int delivery_code;
    char message_id[32];
    char detail[128];
} bt_sms_result_t;

void bt_sms_result_init(bt_sms_result_t *result);
bt_sms_result_t bt_sms_send_to_mac(bt_context_t *ctx, const char *mac,
                                   const char *text, uint8_t channel);
bt_sms_result_t bt_sms_send_all_connected(bt_context_t *ctx, const char *text,
                                          uint8_t channel);
const char *bt_sms_delivery_code_str(int code);

#endif
