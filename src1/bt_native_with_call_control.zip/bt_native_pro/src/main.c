#include "bt_adapter.h"
#include "bt_cli.h"
#include "bt_log.h"
#include "bt_util.h"

static void bt_print_adapter_table(void)
{
    struct bt_adapter_summary items[BT_MAX_ADAPTERS];
    size_t count = 0;
    size_t i;
    int rc;

    rc = bt_adapter_list(items, BT_MAX_ADAPTERS, &count);
    if (rc < 0) {
        bt_log_error("adapter enumeration failed: %s", strerror(-rc));
        return;
    }

    if (count == 0) {
        bt_log_warn("no bluetooth adapters found");
        return;
    }

    printf("Detected adapters:\n");
    for (i = 0; i < count; ++i) {
        printf("  id=%u name=%s\n", items[i].dev_id, items[i].name);
    }
}

static uint16_t bt_parse_dev_id(int argc, char **argv)
{
    int i;
    for (i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--dev") == 0 && i + 1 < argc) {
            return (uint16_t)strtoul(argv[i + 1], NULL, 10);
        }
    }
    return 0;
}

int main(int argc, char **argv)
{
    uint16_t dev_id;

    dev_id = bt_parse_dev_id(argc, argv);

    bt_log_info("This application expects system bluetoothd to be stopped before use.");
    bt_print_adapter_table();
    bt_log_info("opening CLI for adapter %u", dev_id);

    return bt_cli_run(dev_id);
}
