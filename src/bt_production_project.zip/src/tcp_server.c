
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "../include/bt.h"

void run_server(){
    int s=socket(AF_INET,SOCK_STREAM,0);
    struct sockaddr_in addr={0};

    addr.sin_family=AF_INET;
    addr.sin_port=htons(3333);
    addr.sin_addr.s_addr=INADDR_ANY;

    bind(s,(void*)&addr,sizeof(addr));
    listen(s,5);

    printf("TCP control server on 3333\n");

    while(1){
        int c=accept(s,NULL,NULL);
        char buf[256]={0};
        read(c,buf,sizeof(buf));

        if(strncmp(buf,"PAIR",4)==0){
            char mac[32];
            sscanf(buf,"PAIR %s",mac);
            bt_result_t r=bt_pair(0,mac);
            dprintf(c,"PAIR=%d\n",r.status);
        }

        close(c);
    }
}
