bt_native_with_sms

Added:
- inquiry scan support
- in-memory device cache for nearby devices
- CoD-based device classification and pairing policy recommendation
- local MAC getter via HCIGETDEVINFO
- local name getter via HCI Read Local Name
- remote name resolution after inquiry
- pairing support for three policies:
  * pair auto <index>
  * pair confirm <index>
  * pair phone <index> [pin]
- connection request support:
  * connect <index>
- app identifier support:
  * id
  * id set <identifier>
- RFCOMM text message sending:
  * sms <index> <text>

Build:
    make

Run:
    sudo systemctl stop bluetooth
    sudo ./bt_native

Notes:
- The app identifier is stored in bt_app_id.txt. If the file does not exist,
  a default identifier is generated from the local Bluetooth MAC address.
- The sms command sends an application-level text payload over RFCOMM channel 9
  in the form: "<identifier> <text>".
- The remote device must run a compatible app-side RFCOMM listener on the same
  channel. This is not carrier-network SMS and it is not Bluetooth MAP.
- This project currently targets classic BR/EDR inquiry + pairing flows.


Added call-control commands:
- dial <MAC>
- incoming call <MAC>
- answer
- reject
- hangup
- call

Important:
- This update adds a professional call-control state manager and CLI integration.
- It does NOT yet implement full interoperable Bluetooth audio calling.
- Real cross-device audio calling requires HFP/HSP signaling, SDP records, RFCOMM AT command handling,
  SCO/eSCO audio transport, PCM/CVSD or mSBC audio processing, and event-driven connection management.
- The current commands manage call intent and session state inside the app, which is the correct control-layer
  foundation for a later HFP/SCO implementation.
