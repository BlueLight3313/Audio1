
#include <stdio.h>
#include <stdint.h>

int bt_sdp_register_ag(uint8_t channel){
    printf("SDP: Register HFP AG on RFCOMM channel %d\n", channel);
    printf("UUID: 0x111F (AG), Profile: 0x111E\n");
    return 0;
}
