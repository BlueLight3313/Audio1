
#include <stdio.h>
#include "../include/bt_pair.h"

int main(int argc,char**argv)
{
    if(argc<2){
        printf("usage: pair <MAC>\n");
        return 0;
    }

    bt_pair_result_t r = bt_pair_device(0, argv[1]);

    printf("PAIR RESULT = %d (mgmt=%d)\n", r.status, r.mgmt_status);

    return 0;
}
