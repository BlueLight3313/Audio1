
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int bt_sco_connect(const char*);
int bt_audio_start(int);

void bt_hfp_ag_run(int fd, const char *mac){
    char buf[256];
    int sco_fd = -1;

    while(1){
        int n=read(fd,buf,sizeof(buf)-1);
        if(n<=0) break;
        buf[n]=0;

        printf("HFP RX: %s\n", buf);

        if(strstr(buf,"ATA")){
            write(fd,"OK\r\n",4);

            if(sco_fd<0){
                sco_fd = bt_sco_connect(mac);
                bt_audio_start(sco_fd);
                printf("SCO + AUDIO START\n");
            }
        }
        else if(strstr(buf,"AT+CHUP")){
            write(fd,"OK\r\n",4);
        }
        else if(strstr(buf,"ATD")){
            write(fd,"OK\r\n",4);
        }
    }
}
