# bt_native

Self-contained Linux Bluetooth adapter control sample in native C without BlueZ headers, BlueZ libraries, or D-Bus.

## What this project does

- Enumerates Bluetooth adapters with `HCIGETDEVLIST`
- Reads adapter information with `HCIGETDEVINFO`
- Powers adapter on and off with `HCIDEVUP` and `HCIDEVDOWN`
- Enables and disables discoverability with raw HCI `Write Scan Enable`
- Verifies discoverability with raw HCI `Read Scan Enable`
- Reads local name and BD_ADDR for status output
- Provides a CLI shell for future expansion

## Important runtime expectation

Stop the system Bluetooth service before running this program:

```bash
sudo systemctl stop bluetooth
```

## Build

```bash
make
```

## Run

```bash
sudo ./bt_native
sudo ./bt_native --dev 1
```

## Notes

- This is Linux-only.
- It still depends on the Linux kernel Bluetooth subsystem and the controller driver.
- It does not depend on BlueZ user-space libraries or D-Bus.
- This code is a realistic adapter-management core, not a full messaging app stack.
