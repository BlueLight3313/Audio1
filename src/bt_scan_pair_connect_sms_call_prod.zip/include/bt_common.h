#ifndef BT_COMMON_H
#define BT_COMMON_H

#include <stddef.h>
#include <stdint.h>
#include "../compat/bluetooth/bluetooth.h"
#include "../compat/bluetooth/hci.h"

#define BT_MAX_SCAN_RESULTS 128
#define BT_MAX_NAME_LEN 248

typedef enum {
    BT_STATUS_OK = 0,
    BT_STATUS_FAIL = -1,
    BT_STATUS_TIMEOUT = -2,
    BT_STATUS_NOT_FOUND = -3,
    BT_STATUS_PROTOCOL = -4,
    BT_STATUS_REMOTE = -5,
    BT_STATUS_ALREADY = -6,
    BT_STATUS_NOT_PAIRED = -7
} bt_status_t;

typedef struct {
    char mac[18];
    char name[BT_MAX_NAME_LEN + 1];
    int rssi;
    uint8_t addr_type;
    uint32_t flags;
} bt_scan_entry_t;

typedef struct {
    bt_status_t status;
    uint8_t mgmt_status;
    int count;
    bt_scan_entry_t entries[BT_MAX_SCAN_RESULTS];
} bt_scan_result_t;

typedef struct {
    bt_status_t status;
    uint8_t mgmt_status;
    int bonded;
    int new_link_key_seen;
    int auth_failed;
    int cancelled;
    int connected;
    char detail[128];
} bt_pair_result_t;

typedef struct {
    bt_status_t status;
    uint8_t mgmt_status;
    int already_connected;
    int transport_socket_connected;
    int mgmt_connected_verified;
    char detail[128];
} bt_connect_result_t;

typedef struct {
    uint8_t io_capability;
    int timeout_ms;
    int require_new_link_key;
    int auto_confirm;
    int has_pin;
    char pin[17];
    int has_passkey;
    uint32_t passkey;
} bt_pair_options_t;

const char *bt_status_str(bt_status_t status);
const char *bt_mgmt_status_str(uint8_t status);

uint16_t bt_cpu_to_le16(uint16_t v);
uint16_t bt_le16_to_cpu(uint16_t v);
uint32_t bt_cpu_to_le32(uint32_t v);
uint32_t bt_le32_to_cpu(uint32_t v);

int bt_open_mgmt_socket(void);
int bt_send_mgmt_cmd(int sock, uint16_t opcode, uint16_t index,
                     const void *payload, uint16_t payload_len);
int bt_wait_mgmt_cmd_result(int sock, uint16_t want_opcode, uint16_t want_index,
                            uint8_t *out_status, uint8_t *out_data,
                            size_t *out_data_len, int timeout_ms);

int bt_eir_extract_name(const uint8_t *eir, size_t eir_len,
                        char *name, size_t name_sz);
int bt_addr_equals(const bdaddr_t *a, const bdaddr_t *b);

#endif
