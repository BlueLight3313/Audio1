#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <poll.h>
#include <sys/socket.h>

#include "bluetooth/bluetooth.h"
#include "bluetooth/hci.h"
#include "bluetooth/l2cap.h"
#include "bt_native.h"

#define MGMT_INDEX_NONE                 0xFFFF

#define MGMT_OP_READ_INDEX_LIST         0x0003
#define MGMT_OP_GET_CONNECTIONS         0x0015
#define MGMT_OP_PAIR_DEVICE             0x0019
#define MGMT_OP_START_DISCOVERY         0x0023
#define MGMT_OP_STOP_DISCOVERY          0x0024

#define MGMT_EV_CMD_COMPLETE            0x0001
#define MGMT_EV_CMD_STATUS              0x0002
#define MGMT_EV_DEVICE_FOUND            0x0012
#define MGMT_EV_DISCOVERING             0x0013

#define MGMT_ADDR_BREDR                 0x00
#define MGMT_DISCOV_TYPE_BREDR          0x01
#define MGMT_IO_CAP_NO_INPUT_NO_OUTPUT  0x03

struct mgmt_hdr {
    uint16_t opcode;
    uint16_t index;
    uint16_t len;
} __attribute__((packed));

struct mgmt_ev_cmd_complete {
    uint16_t opcode;
    uint8_t status;
    uint8_t data[0];
} __attribute__((packed));

struct mgmt_ev_cmd_status {
    uint16_t opcode;
    uint8_t status;
} __attribute__((packed));

struct mgmt_rp_read_index_list {
    uint16_t num_controllers;
    uint16_t index[0];
} __attribute__((packed));

struct mgmt_cp_start_discovery {
    uint8_t type;
} __attribute__((packed));

struct mgmt_cp_stop_discovery {
    uint8_t type;
} __attribute__((packed));

struct mgmt_cp_pair_device {
    bdaddr_t addr;
    uint8_t addr_type;
    uint8_t io_cap;
} __attribute__((packed));

struct mgmt_rp_get_connections {
    uint16_t conn_count;
    uint8_t entries[0];
} __attribute__((packed));

struct mgmt_addr_info {
    bdaddr_t addr;
    uint8_t addr_type;
} __attribute__((packed));

struct mgmt_ev_device_found {
    bdaddr_t addr;
    uint8_t addr_type;
    int8_t rssi;
    uint32_t flags;
    uint16_t eir_len;
    uint8_t eir[0];
} __attribute__((packed));

struct mgmt_ev_discovering {
    uint8_t type;
    uint8_t discovering;
} __attribute__((packed));

static uint16_t bt_cpu_to_le16(uint16_t v)
{
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    return v;
#else
    return (uint16_t)((v << 8) | (v >> 8));
#endif
}

static uint16_t bt_le16_to_cpu(uint16_t v)
{
    return bt_cpu_to_le16(v);
}

static int mgmt_open(void)
{
    int sock;
    struct sockaddr_hci addr;

    sock = socket(AF_BLUETOOTH, SOCK_RAW, BTPROTO_HCI);
    if (sock < 0) {
        perror("socket(AF_BLUETOOTH, HCI)");
        return -1;
    }

    memset(&addr, 0, sizeof(addr));
    addr.hci_family = AF_BLUETOOTH;
    addr.hci_dev = HCI_DEV_NONE;
    addr.hci_channel = HCI_CHANNEL_CONTROL;

    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind(HCI_CHANNEL_CONTROL)");
        close(sock);
        return -1;
    }

    return sock;
}

static int mgmt_send_cmd(int sock, uint16_t opcode, uint16_t index,
                         const void *payload, uint16_t payload_len)
{
    uint8_t buf[1024];
    struct mgmt_hdr *hdr;

    if (sizeof(struct mgmt_hdr) + payload_len > sizeof(buf))
        return -1;

    hdr = (struct mgmt_hdr *)buf;
    hdr->opcode = bt_cpu_to_le16(opcode);
    hdr->index = bt_cpu_to_le16(index);
    hdr->len = bt_cpu_to_le16(payload_len);

    if (payload_len && payload)
        memcpy(buf + sizeof(*hdr), payload, payload_len);

    if (write(sock, buf, sizeof(*hdr) + payload_len) < 0) {
        perror("write(mgmt)");
        return -1;
    }

    return 0;
}

static int mgmt_wait_cmd_result(int sock, uint16_t want_opcode,
                                uint16_t want_index,
                                uint8_t *out_status,
                                uint8_t *out_data,
                                size_t *out_data_len,
                                int timeout_ms)
{
    struct pollfd pfd;
    uint8_t buf[2048];

    pfd.fd = sock;
    pfd.events = POLLIN;

    while (1) {
        int pr = poll(&pfd, 1, timeout_ms);
        if (pr < 0) {
            perror("poll");
            return -1;
        }
        if (pr == 0) {
            fprintf(stderr, "timeout waiting mgmt response\n");
            return -1;
        }

        if (pfd.revents & POLLIN) {
            ssize_t n = read(sock, buf, sizeof(buf));
            struct mgmt_hdr *hdr;
            uint16_t evt;
            uint16_t idx;
            uint16_t len;

            if (n < (ssize_t)sizeof(struct mgmt_hdr))
                continue;

            hdr = (struct mgmt_hdr *)buf;
            evt = bt_le16_to_cpu(hdr->opcode);
            idx = bt_le16_to_cpu(hdr->index);
            len = bt_le16_to_cpu(hdr->len);

            if (idx != want_index && want_index != MGMT_INDEX_NONE)
                continue;

            if (evt == MGMT_EV_CMD_COMPLETE) {
                struct mgmt_ev_cmd_complete *cc;
                uint16_t cmd_opcode;
                size_t data_len;

                if (len < sizeof(*cc))
                    continue;

                cc = (struct mgmt_ev_cmd_complete *)(buf + sizeof(*hdr));
                cmd_opcode = bt_le16_to_cpu(cc->opcode);
                if (cmd_opcode != want_opcode)
                    continue;

                if (out_status)
                    *out_status = cc->status;

                data_len = len - sizeof(*cc);
                if (out_data && out_data_len && *out_data_len >= data_len) {
                    memcpy(out_data, cc->data, data_len);
                    *out_data_len = data_len;
                } else if (out_data_len) {
                    *out_data_len = data_len;
                }

                return 0;
            }

            if (evt == MGMT_EV_CMD_STATUS) {
                struct mgmt_ev_cmd_status *cs;
                uint16_t cmd_opcode;

                if (len < sizeof(*cs))
                    continue;

                cs = (struct mgmt_ev_cmd_status *)(buf + sizeof(*hdr));
                cmd_opcode = bt_le16_to_cpu(cs->opcode);
                if (cmd_opcode != want_opcode)
                    continue;

                if (out_status)
                    *out_status = cs->status;
                if (out_data_len)
                    *out_data_len = 0;
                return 0;
            }
        }
    }
}

static int eir_extract_name(const uint8_t *eir, size_t eir_len,
                            char *name, size_t name_sz)
{
    size_t i = 0;

    if (!name || name_sz == 0)
        return -1;

    name[0] = '\0';

    while (i + 1 < eir_len) {
        uint8_t field_len = eir[i];
        uint8_t field_type;

        if (field_len == 0)
            break;

        if (i + 1 + field_len > eir_len)
            break;

        field_type = eir[i + 1];

        if (field_type == 0x09 || field_type == 0x08) {
            size_t copy_len = field_len - 1;
            if (copy_len >= name_sz)
                copy_len = name_sz - 1;

            memcpy(name, &eir[i + 2], copy_len);
            name[copy_len] = '\0';
            return 0;
        }

        i += (size_t)field_len + 1;
    }

    snprintf(name, name_sz, "unknown");
    return -1;
}

const char *bt_status_str(bt_status_t status)
{
    switch (status) {
    case BT_OK:
        return "SUCCESS";
    case BT_ERR_TIMEOUT:
        return "TIMEOUT";
    case BT_ERR_NOT_FOUND:
        return "NOT_FOUND";
    case BT_ERR_PROTOCOL:
        return "PROTOCOL_ERROR";
    case BT_ERR_REMOTE:
        return "REMOTE_FAIL";
    default:
        return "FAIL";
    }
}

bt_result_t bt_adapter_check(int adapter_index)
{
    bt_result_t result;
    int sock;
    uint8_t status = 0xFF;
    uint8_t data[256];
    size_t data_len = sizeof(data);
    struct mgmt_rp_read_index_list *rp;
    uint16_t count;
    int i;
    int found = 0;

    memset(&result, 0, sizeof(result));
    result.status = BT_ERR;
    result.mgmt_status = -1;

    sock = mgmt_open();
    if (sock < 0)
        return result;

    if (mgmt_send_cmd(sock, MGMT_OP_READ_INDEX_LIST, MGMT_INDEX_NONE, NULL, 0) < 0) {
        close(sock);
        return result;
    }

    if (mgmt_wait_cmd_result(sock, MGMT_OP_READ_INDEX_LIST, MGMT_INDEX_NONE,
                             &status, data, &data_len, 3000) < 0) {
        close(sock);
        result.status = BT_ERR_TIMEOUT;
        return result;
    }

    result.mgmt_status = status;

    if (status != 0x00) {
        close(sock);
        result.status = BT_ERR_REMOTE;
        return result;
    }

    if (data_len < sizeof(*rp)) {
        close(sock);
        result.status = BT_ERR_PROTOCOL;
        return result;
    }

    rp = (struct mgmt_rp_read_index_list *)data;
    count = bt_le16_to_cpu(rp->num_controllers);

    printf("Controllers found: %u\n", count);
    for (i = 0; i < count; ++i) {
        uint16_t idx = bt_le16_to_cpu(rp->index[i]);
        printf("  hci%u\n", idx);
        if ((int)idx == adapter_index)
            found = 1;
    }

    close(sock);

    if (found)
        result.status = BT_OK;
    else
        result.status = BT_ERR_NOT_FOUND;

    return result;
}

bt_result_t bt_scan_classic(int adapter_index, int timeout_seconds)
{
    bt_result_t result;
    int sock;
    uint8_t status = 0xFF;
    uint8_t data[32];
    size_t data_len = sizeof(data);
    struct mgmt_cp_start_discovery cp;
    struct mgmt_cp_stop_discovery stop_cp;
    uint8_t buf[2048];
    long end_ms;
    struct pollfd pfd;
    int started = 0;
    int found_count = 0;

    memset(&result, 0, sizeof(result));
    result.status = BT_ERR;
    result.mgmt_status = -1;

    sock = mgmt_open();
    if (sock < 0)
        return result;

    cp.type = MGMT_DISCOV_TYPE_BREDR;

    if (mgmt_send_cmd(sock, MGMT_OP_START_DISCOVERY, (uint16_t)adapter_index,
                      &cp, sizeof(cp)) < 0) {
        close(sock);
        return result;
    }

    if (mgmt_wait_cmd_result(sock, MGMT_OP_START_DISCOVERY, (uint16_t)adapter_index,
                             &status, data, &data_len, 3000) < 0) {
        close(sock);
        result.status = BT_ERR_TIMEOUT;
        return result;
    }

    result.mgmt_status = status;

    if (status != 0x00) {
        close(sock);
        result.status = BT_ERR_REMOTE;
        return result;
    }

    started = 1;
    end_ms = (long)timeout_seconds * 1000L;

    pfd.fd = sock;
    pfd.events = POLLIN;

    while (end_ms > 0) {
        int step = end_ms > 500 ? 500 : (int)end_ms;
        int pr = poll(&pfd, 1, step);
        end_ms -= step;

        if (pr < 0) {
            perror("poll(scan)");
            result.status = BT_ERR;
            break;
        }

        if (pr == 0)
            continue;

        if (pfd.revents & POLLIN) {
            ssize_t n = read(sock, buf, sizeof(buf));
            struct mgmt_hdr *hdr;
            uint16_t evt;
            uint16_t idx;
            uint16_t len;

            if (n < (ssize_t)sizeof(*hdr))
                continue;

            hdr = (struct mgmt_hdr *)buf;
            evt = bt_le16_to_cpu(hdr->opcode);
            idx = bt_le16_to_cpu(hdr->index);
            len = bt_le16_to_cpu(hdr->len);

            if ((int)idx != adapter_index)
                continue;

            if (evt == MGMT_EV_DEVICE_FOUND) {
                struct mgmt_ev_device_found *df;
                char mac[18];
                char name[249];
                uint16_t eir_len;

                if (len < sizeof(*df))
                    continue;

                df = (struct mgmt_ev_device_found *)(buf + sizeof(*hdr));
                eir_len = bt_le16_to_cpu(df->eir_len);

                if ((size_t)len < sizeof(*df) + eir_len)
                    continue;

                ba2str(&df->addr, mac);
                eir_extract_name(df->eir, eir_len, name, sizeof(name));

                printf("%s  RSSI=%d  NAME=%s\n", mac, (int)df->rssi, name);
                found_count++;
            } else if (evt == MGMT_EV_DISCOVERING) {
                struct mgmt_ev_discovering *dv;
                if (len >= sizeof(*dv)) {
                    dv = (struct mgmt_ev_discovering *)(buf + sizeof(*hdr));
                    if (dv->discovering == 0x00)
                        break;
                }
            }
        }
    }

    if (started) {
        stop_cp.type = MGMT_DISCOV_TYPE_BREDR;
        mgmt_send_cmd(sock, MGMT_OP_STOP_DISCOVERY, (uint16_t)adapter_index,
                      &stop_cp, sizeof(stop_cp));
    }

    close(sock);

    result.found_count = found_count;

    if (found_count > 0)
        result.status = BT_OK;
    else
        result.status = BT_ERR_NOT_FOUND;

    return result;
}

bt_result_t bt_pair_classic_justworks(int adapter_index, const char *mac)
{
    bt_result_t result;
    int sock;
    struct mgmt_cp_pair_device cp;
    uint8_t status = 0xFF;
    uint8_t data[64];
    size_t data_len = sizeof(data);

    memset(&result, 0, sizeof(result));
    result.status = BT_ERR;
    result.mgmt_status = -1;

    if (str2ba(mac, &cp.addr) < 0) {
        result.status = BT_ERR_PROTOCOL;
        return result;
    }

    cp.addr_type = MGMT_ADDR_BREDR;
    cp.io_cap = MGMT_IO_CAP_NO_INPUT_NO_OUTPUT;

    sock = mgmt_open();
    if (sock < 0)
        return result;

    if (mgmt_send_cmd(sock, MGMT_OP_PAIR_DEVICE, (uint16_t)adapter_index,
                      &cp, sizeof(cp)) < 0) {
        close(sock);
        return result;
    }

    if (mgmt_wait_cmd_result(sock, MGMT_OP_PAIR_DEVICE, (uint16_t)adapter_index,
                             &status, data, &data_len, 15000) < 0) {
        close(sock);
        result.status = BT_ERR_TIMEOUT;
        return result;
    }

    close(sock);

    result.mgmt_status = status;

    if (status == 0x00)
        result.status = BT_OK;
    else
        result.status = BT_ERR_REMOTE;

    return result;
}

bt_result_t bt_connect_classic_sdp(const char *mac)
{
    bt_result_t result;
    int sock;
    struct sockaddr_l2 remote;

    memset(&result, 0, sizeof(result));
    result.status = BT_ERR;
    result.mgmt_status = -1;

    memset(&remote, 0, sizeof(remote));
    remote.l2_family = AF_BLUETOOTH;
    remote.l2_psm = bt_htobs(0x0001);
    remote.l2_bdaddr_type = MGMT_ADDR_BREDR;

    if (str2ba(mac, &remote.l2_bdaddr) < 0) {
        result.status = BT_ERR_PROTOCOL;
        return result;
    }

    sock = socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP);
    if (sock < 0) {
        perror("socket(L2CAP)");
        return result;
    }

    if (connect(sock, (struct sockaddr *)&remote, sizeof(remote)) < 0) {
        perror("connect(L2CAP SDP)");
        close(sock);
        result.status = BT_ERR_REMOTE;
        return result;
    }

    close(sock);
    result.status = BT_OK;
    return result;
}

bt_result_t bt_list_connected(int adapter_index)
{
    bt_result_t result;
    int sock;
    uint8_t status = 0xFF;
    uint8_t data[1024];
    size_t data_len = sizeof(data);
    struct mgmt_rp_get_connections *rp;
    uint16_t count;
    uint16_t i;

    memset(&result, 0, sizeof(result));
    result.status = BT_ERR;
    result.mgmt_status = -1;

    sock = mgmt_open();
    if (sock < 0)
        return result;

    if (mgmt_send_cmd(sock, MGMT_OP_GET_CONNECTIONS, (uint16_t)adapter_index, NULL, 0) < 0) {
        close(sock);
        return result;
    }

    if (mgmt_wait_cmd_result(sock, MGMT_OP_GET_CONNECTIONS, (uint16_t)adapter_index,
                             &status, data, &data_len, 3000) < 0) {
        close(sock);
        result.status = BT_ERR_TIMEOUT;
        return result;
    }

    result.mgmt_status = status;

    if (status != 0x00) {
        close(sock);
        result.status = BT_ERR_REMOTE;
        return result;
    }

    if (data_len < sizeof(*rp)) {
        close(sock);
        result.status = BT_ERR_PROTOCOL;
        return result;
    }

    rp = (struct mgmt_rp_get_connections *)data;
    count = bt_le16_to_cpu(rp->conn_count);
    result.connected_count = count;

    printf("Connected devices: %u\n", count);

    for (i = 0; i < count; ++i) {
        struct mgmt_addr_info *ai;
        char mac[18];

        if (sizeof(*rp) + (i + 1) * sizeof(*ai) > data_len)
            break;

        ai = (struct mgmt_addr_info *)(rp->entries + i * sizeof(*ai));
        ba2str(&ai->addr, mac);
        printf("  %s  type=%u\n", mac, ai->addr_type);
    }

    close(sock);
    result.status = BT_OK;
    return result;
}
