
#ifndef BT_AUDIO_PACKET_H
#define BT_AUDIO_PACKET_H

#include <stdint.h>

#define AUDIO_FRAME_SAMPLES 80
#define AUDIO_FRAME_BYTES 160

typedef struct {
    uint16_t seq;
    uint32_t ts;
    uint8_t payload[AUDIO_FRAME_BYTES];
} bt_audio_packet_t;

#endif
