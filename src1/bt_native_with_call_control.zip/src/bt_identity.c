#include <ctype.h>
#include <stdio.h>
#include <string.h>

#include "bt_identity.h"

static char g_identifier[128];

static void bt_trim_line(char *text)
{
    size_t len;

    if (text == NULL) {
        return;
    }

    len = strlen(text);
    while (len > 0 && (text[len - 1] == '\r' || text[len - 1] == '\n' || isspace((unsigned char)text[len - 1]))) {
        text[len - 1] = '\0';
        --len;
    }
}

static int bt_identifier_is_valid(const char *identifier)
{
    size_t i;
    size_t len;

    if (identifier == NULL) {
        return 0;
    }

    len = strlen(identifier);
    if (len == 0 || len >= sizeof(g_identifier)) {
        return 0;
    }

    for (i = 0; i < len; ++i) {
        unsigned char c = (unsigned char)identifier[i];
        if (!(isalnum(c) || c == '-' || c == '_' || c == '.')) {
            return 0;
        }
    }

    return 1;
}

static void bt_build_default_identifier(const char *mac_text)
{
    size_t i;
    size_t out_len = 0;

    memset(g_identifier, 0, sizeof(g_identifier));
    memcpy(g_identifier, "BTAPP-", 6);
    out_len = 6;

    if (mac_text == NULL) {
        memcpy(g_identifier + out_len, "UNKNOWN", 7);
        return;
    }

    for (i = 0; mac_text[i] != '\0' && out_len + 1 < sizeof(g_identifier); ++i) {
        if (mac_text[i] == ':') {
            continue;
        }
        g_identifier[out_len++] = mac_text[i];
    }
    g_identifier[out_len] = '\0';
}

int bt_identity_load_or_create_from_mac(const char *file_path, const char *mac_text)
{
    FILE *fp;
    char line[128];

    bt_build_default_identifier(mac_text);

    if (file_path == NULL) {
        return 0;
    }

    fp = fopen(file_path, "r");
    if (fp == NULL) {
        return bt_identity_set_and_save(file_path, g_identifier);
    }

    if (fgets(line, sizeof(line), fp) != NULL) {
        bt_trim_line(line);
        if (bt_identifier_is_valid(line)) {
            memset(g_identifier, 0, sizeof(g_identifier));
            memcpy(g_identifier, line, strlen(line));
        }
    }

    fclose(fp);
    return 0;
}

int bt_identity_set_and_save(const char *file_path, const char *identifier)
{
    FILE *fp;
    size_t len;

    if (!bt_identifier_is_valid(identifier)) {
        return -1;
    }

    len = strlen(identifier);
    memset(g_identifier, 0, sizeof(g_identifier));
    memcpy(g_identifier, identifier, len);

    if (file_path == NULL) {
        return 0;
    }

    fp = fopen(file_path, "w");
    if (fp == NULL) {
        return -1;
    }

    fwrite(g_identifier, 1, strlen(g_identifier), fp);
    fwrite("\n", 1, 1, fp);
    fclose(fp);
    return 0;
}

const char *bt_identity_get(void)
{
    return g_identifier[0] != '\0' ? g_identifier : "BTAPP-UNSET";
}

void bt_identity_compose_message(const char *text, char *out, size_t out_size)
{
    const char *identifier;
    int written;

    if (out == NULL || out_size == 0) {
        return;
    }

    identifier = bt_identity_get();
    if (text == NULL) {
        text = "";
    }

    written = snprintf(out, out_size, "%s %s", identifier, text);
    if (written < 0 || (size_t)written >= out_size) {
        out[out_size - 1] = '\0';
    }
}
