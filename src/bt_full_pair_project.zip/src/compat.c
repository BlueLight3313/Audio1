
#include <stdio.h>
#include "../compat/bluetooth/bluetooth.h"

int str2ba(const char *str, bdaddr_t *ba)
{
    unsigned int b[6];
    sscanf(str,"%02x:%02x:%02x:%02x:%02x:%02x",
        &b[5],&b[4],&b[3],&b[2],&b[1],&b[0]);

    for(int i=0;i<6;i++) ba->b[i]=b[i];
    return 0;
}
