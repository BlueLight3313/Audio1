#ifndef BT_NATIVE_H
#define BT_NATIVE_H

typedef enum {
    BT_OK = 0,
    BT_ERR = -1,
    BT_ERR_TIMEOUT = -2,
    BT_ERR_NOT_FOUND = -3,
    BT_ERR_PROTOCOL = -4,
    BT_ERR_REMOTE = -5
} bt_status_t;

typedef struct {
    bt_status_t status;
    int mgmt_status;
    int found_count;
    int connected_count;
} bt_result_t;

bt_result_t bt_adapter_check(int adapter_index);
bt_result_t bt_scan_classic(int adapter_index, int timeout_seconds);
bt_result_t bt_pair_classic_justworks(int adapter_index, const char *mac);
bt_result_t bt_connect_classic_sdp(const char *mac);
bt_result_t bt_list_connected(int adapter_index);
const char *bt_status_str(bt_status_t status);

#endif
