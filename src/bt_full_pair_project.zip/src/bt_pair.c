
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <poll.h>
#include <sys/socket.h>
#include "../compat/bluetooth/bluetooth.h"
#include "../compat/bluetooth/hci.h"
#include "../include/bt_pair.h"

#define MGMT_OP_PAIR_DEVICE 0x0019
#define MGMT_EV_CMD_COMPLETE 0x0001
#define MGMT_EV_CMD_STATUS 0x0002
#define MGMT_EV_USER_CONFIRM_REQUEST 0x000C

#define MGMT_IO_CAP_NO_INPUT_NO_OUTPUT 0x03
#define MGMT_ADDR_BREDR 0x00

struct mgmt_hdr {
    unsigned short opcode;
    unsigned short index;
    unsigned short len;
} __attribute__((packed));

struct mgmt_pair_cp {
    bdaddr_t addr;
    unsigned char addr_type;
    unsigned char io_cap;
} __attribute__((packed));

struct sockaddr_hci {
    unsigned short hci_family;
    unsigned short hci_dev;
    unsigned short hci_channel;
};

static int mgmt_socket(int index)
{
    int s;
    struct sockaddr_hci addr;

    s = socket(AF_BLUETOOTH, SOCK_RAW, BTPROTO_HCI);

    memset(&addr, 0, sizeof(addr));
    addr.hci_family = AF_BLUETOOTH;
    addr.hci_dev = index;
    addr.hci_channel = HCI_CHANNEL_CONTROL;

    bind(s, (struct sockaddr *)&addr, sizeof(addr));
    return s;
}

bt_pair_result_t bt_pair_device(int adapter, const char *mac)
{
    bt_pair_result_t result;
    int sock;
    struct mgmt_hdr hdr;
    struct mgmt_pair_cp cp;
    unsigned char buf[1024];
    struct pollfd pfd;

    result.status = BT_PAIR_FAILED;
    result.mgmt_status = -1;

    sock = mgmt_socket(adapter);

    str2ba(mac, &cp.addr);
    cp.addr_type = MGMT_ADDR_BREDR;
    cp.io_cap = MGMT_IO_CAP_NO_INPUT_NO_OUTPUT;

    hdr.opcode = MGMT_OP_PAIR_DEVICE;
    hdr.index = adapter;
    hdr.len = sizeof(cp);

    write(sock, &hdr, sizeof(hdr));
    write(sock, &cp, sizeof(cp));

    pfd.fd = sock;
    pfd.events = POLLIN;

    while (1) {
        if (poll(&pfd, 1, 15000) <= 0) {
            result.status = BT_PAIR_TIMEOUT;
            break;
        }

        int n = read(sock, buf, sizeof(buf));
        if (n <= 0) continue;

        struct mgmt_hdr *h = (struct mgmt_hdr*)buf;

        if (h->opcode == MGMT_EV_CMD_COMPLETE) {
            unsigned char status = buf[sizeof(*h)+2];
            result.mgmt_status = status;

            if (status == 0x00)
                result.status = BT_PAIR_SUCCESS;
            else if (status == 0x12)
                result.status = BT_PAIR_CANCELLED;
            else
                result.status = BT_PAIR_FAILED;

            break;
        }

        if (h->opcode == MGMT_EV_CMD_STATUS) {
            result.mgmt_status = buf[sizeof(*h)+2];
            result.status = BT_PAIR_FAILED;
            break;
        }
    }

    close(sock);
    return result;
}
