#ifndef BT_SCAN_H
#define BT_SCAN_H

#include "bt_common.h"

bt_scan_result_t bt_scan_bredr(int adapter_index, int timeout_seconds);

#endif
