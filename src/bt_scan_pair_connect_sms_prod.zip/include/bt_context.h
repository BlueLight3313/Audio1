#ifndef BT_CONTEXT_H
#define BT_CONTEXT_H

#include "bt_common.h"

#define BT_MAX_DEVICES 128

typedef struct {
    int used;
    int index;
    char mac[18];
    char name[BT_MAX_NAME_LEN + 1];
    int paired;
    int connected;
} bt_device_t;

typedef struct {
    bt_device_t devices[BT_MAX_DEVICES];
    int count;
    char host_id[64];
} bt_context_t;

void bt_context_init(bt_context_t *ctx);
bt_context_t *bt_context_get_global(void);
bt_device_t *bt_context_find_by_mac(bt_context_t *ctx, const char *mac);
bt_device_t *bt_context_get_or_add(bt_context_t *ctx, const char *mac, const char *name);
void bt_context_update_scan_result(bt_context_t *ctx, const bt_scan_result_t *scan);
void bt_context_mark_paired(bt_context_t *ctx, const char *mac, int paired);
void bt_context_mark_connected(bt_context_t *ctx, const char *mac, int connected);
void bt_context_print(const bt_context_t *ctx);
const char *bt_context_get_host_id(const bt_context_t *ctx);
void bt_context_set_host_id(bt_context_t *ctx, const char *host_id);
int bt_context_save(const bt_context_t *ctx);

#endif
