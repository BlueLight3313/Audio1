# bt_pairing_production

Native C BR/EDR pairing engine using the Linux Bluetooth Management (mgmt) socket, without depending on BlueZ user-space development headers.

## What it implements

- `Pair Device` command
- `PIN Code Request` event handling with `PIN Code Reply` / negative reply
- `User Confirmation Request` event handling with positive / negative reply
- `User Passkey Request` event handling with passkey / negative reply
- `Authentication Failed` event handling
- `New Link Key` tracking for BR/EDR bonding validation
- `Cancel Pair Device` on local cancellation
- deterministic final report for success, failed, cancelled, timeout, rejected, protocol error, and I/O error

## Build

```bash
make
```

## Run

```bash
sudo ./bt_pairing_production pair AA:BB:CC:DD:EE:FF --pin 0000
sudo ./bt_pairing_production pair AA:BB:CC:DD:EE:FF --confirm yes --io-cap displayyesno
sudo ./bt_pairing_production pair AA:BB:CC:DD:EE:FF --passkey 123456 --io-cap keyboardonly
```

If you omit `--pin`, `--passkey`, or `--confirm`, the CLI can prompt interactively unless `--non-interactive` is set.

## Notes

- Root or `CAP_NET_ADMIN` is required for the mgmt socket.
- This project targets BR/EDR pairing flows.
- The kernel/stack owns key generation and storage. This tool watches for `New Link Key` and can require that event before reporting success.
