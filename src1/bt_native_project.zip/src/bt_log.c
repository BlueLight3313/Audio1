
#include <stdio.h>
#include "bt_log.h"

void bt_log(const char *level, const char *msg) {
    printf("[%s] %s\n", level, msg);
}
