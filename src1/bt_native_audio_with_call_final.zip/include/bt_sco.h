#ifndef BT_SCO_H
#define BT_SCO_H

#include "bt_types.h"

int bt_sco_open(const bt_bdaddr_t *bdaddr);
void bt_sco_close(void);

#endif
