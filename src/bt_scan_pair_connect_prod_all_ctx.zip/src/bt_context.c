#include <stdio.h>
#include <string.h>

#include "../include/bt_context.h"

static bt_context_t g_bt_context;

void bt_context_init(bt_context_t *ctx)
{
    if (!ctx)
        return;
    memset(ctx, 0, sizeof(*ctx));
}

bt_context_t *bt_context_get_global(void)
{
    static int initialized = 0;
    if (!initialized) {
        bt_context_init(&g_bt_context);
        initialized = 1;
    }
    return &g_bt_context;
}

bt_device_t *bt_context_find_by_mac(bt_context_t *ctx, const char *mac)
{
    int i;

    if (!ctx || !mac)
        return NULL;

    for (i = 0; i < ctx->count; ++i) {
        if (ctx->devices[i].used && strcmp(ctx->devices[i].mac, mac) == 0)
            return &ctx->devices[i];
    }

    return NULL;
}

bt_device_t *bt_context_get_or_add(bt_context_t *ctx, const char *mac, const char *name)
{
    bt_device_t *dev;
    int slot;

    if (!ctx || !mac || !mac[0])
        return NULL;

    dev = bt_context_find_by_mac(ctx, mac);
    if (dev) {
        if (name && name[0]) {
            snprintf(dev->name, sizeof(dev->name), "%s", name);
        }
        return dev;
    }

    if (ctx->count >= BT_MAX_DEVICES)
        return NULL;

    slot = ctx->count;
    memset(&ctx->devices[slot], 0, sizeof(ctx->devices[slot]));
    ctx->devices[slot].used = 1;
    ctx->devices[slot].index = slot;
    snprintf(ctx->devices[slot].mac, sizeof(ctx->devices[slot].mac), "%s", mac);
    if (name && name[0])
        snprintf(ctx->devices[slot].name, sizeof(ctx->devices[slot].name), "%s", name);
    else
        snprintf(ctx->devices[slot].name, sizeof(ctx->devices[slot].name), "%s", "unknown");
    ctx->devices[slot].paired = 0;
    ctx->devices[slot].connected = 0;
    ctx->count++;
    return &ctx->devices[slot];
}

void bt_context_update_scan_result(bt_context_t *ctx, const bt_scan_result_t *scan)
{
    int i;

    if (!ctx || !scan)
        return;

    for (i = 0; i < scan->count; ++i) {
        const char *name = scan->entries[i].name[0] ? scan->entries[i].name : "unknown";
        bt_context_get_or_add(ctx, scan->entries[i].mac, name);
    }
}

void bt_context_mark_paired(bt_context_t *ctx, const char *mac, int paired)
{
    bt_device_t *dev;
    if (!ctx || !mac)
        return;
    dev = bt_context_get_or_add(ctx, mac, NULL);
    if (!dev)
        return;
    dev->paired = paired ? 1 : 0;
    if (!dev->paired)
        dev->connected = 0;
}

void bt_context_mark_connected(bt_context_t *ctx, const char *mac, int connected)
{
    bt_device_t *dev;
    if (!ctx || !mac)
        return;
    dev = bt_context_get_or_add(ctx, mac, NULL);
    if (!dev)
        return;
    dev->connected = connected ? 1 : 0;
}

void bt_context_print(const bt_context_t *ctx)
{
    int i;

    if (!ctx) {
        printf("Device registry: unavailable\n");
        return;
    }

    printf("Device registry: count=%d\n", ctx->count);
    for (i = 0; i < ctx->count; ++i) {
        const bt_device_t *dev = &ctx->devices[i];
        if (!dev->used)
            continue;

        printf("[%d] mac=%s name=%s paired=%d connected=%d\n",
               dev->index,
               dev->mac,
               dev->name[0] ? dev->name : "unknown",
               dev->paired,
               dev->connected);
    }
}
