#define _XOPEN_SOURCE 600

#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <stdint.h>
#include <string.h>
#include "bt_audio.h"
#include "bt_audio_packet.h"
#include "bt_transport.h"
#include "bt_audio_dsp.h"
#include "bt_jitter.h"

static int dsp_in=-1, dsp_out=-1;
static pthread_t th_cap, th_play;
static int run=0;
static uint16_t seq=0;

static void* capture_thread(void*arg){ (void)arg;
    int16_t buf[AUDIO_FRAME_SAMPLES];
    bt_audio_packet_t pkt;

    while(run){
        read(dsp_in, buf, AUDIO_FRAME_BYTES);
        dsp_process(buf, AUDIO_FRAME_SAMPLES);

        pkt.seq = seq++;
        pkt.ts = pkt.seq;
        memcpy(pkt.payload, buf, AUDIO_FRAME_BYTES);

        bt_transport_send_packet(&pkt);
    }
    return 0;
}

static void* playback_thread(void*arg){ (void)arg;
    bt_audio_packet_t pkt;
    int16_t out[AUDIO_FRAME_SAMPLES];

    while(run){
        if(bt_transport_recv_packet(&pkt)==0){
            jb_push(&pkt);
        }

        if(jb_pop(&pkt)==0){
            memcpy(out, pkt.payload, AUDIO_FRAME_BYTES);
        }else{
            // packet loss → simple repeat silence
            memset(out,0,AUDIO_FRAME_BYTES);
        }

        write(dsp_out, out, AUDIO_FRAME_BYTES);
        usleep(10000); // 10ms pacing
    }
    return 0;
}

int bt_audio_start(){
    dsp_in=open("/dev/dsp",O_RDONLY);
    dsp_out=open("/dev/dsp",O_WRONLY);

    jb_init();

    run=1;
    pthread_create(&th_cap,0,capture_thread,0);
    pthread_create(&th_play,0,playback_thread,0);
    return 0;
}

void bt_audio_stop(){
    run=0;
    pthread_join(th_cap,0);
    pthread_join(th_play,0);
    close(dsp_in);
    close(dsp_out);
}
