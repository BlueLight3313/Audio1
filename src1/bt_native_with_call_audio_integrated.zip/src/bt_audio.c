#include <errno.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>

#include "bt_audio.h"
#include "bt_log.h"

static pthread_t g_bt_audio_thread;
static int g_bt_audio_running = 0;

static void *bt_audio_thread_main(void *arg)
{
    (void)arg;

    bt_log_info("Audio loop started");

    while (g_bt_audio_running) {
        /*
         * Placeholder for future integration:
         *   1. capture PCM audio from local microphone
         *   2. send captured frames to SCO transport
         *   3. receive frames from SCO transport
         *   4. play received audio on local speaker
         */
        usleep(20000);
    }

    bt_log_info("Audio loop stopped");
    return NULL;
}

int bt_audio_start(void)
{
    int rc;

    if (g_bt_audio_running) {
        return 0;
    }

    g_bt_audio_running = 1;

    rc = pthread_create(&g_bt_audio_thread, NULL, bt_audio_thread_main, NULL);
    if (rc != 0) {
        g_bt_audio_running = 0;
        errno = rc;
        return -1;
    }

    return 0;
}

void bt_audio_stop(void)
{
    if (!g_bt_audio_running) {
        return;
    }

    g_bt_audio_running = 0;
    pthread_join(g_bt_audio_thread, NULL);
}
