#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <poll.h>

#include "../include/bt_scan.h"
#include "../include/bt_mgmt.h"

#define MGMT_DEV_FOUND_FLAG_CONFIRM_NAME     (1U << 0)
#define MGMT_DEV_FOUND_FLAG_LEGACY_PAIRING   (1U << 1)
#define MGMT_DEV_FOUND_FLAG_NOT_CONNECTABLE  (1U << 2)
#define MGMT_DEV_FOUND_FLAG_NAME_REQ_FAILED  (1U << 4)
#define MGMT_DEV_FOUND_FLAG_SCAN_RESPONSE    (1U << 5)

static int bt_find_scan_index(bt_scan_result_t *result, const char *mac, uint8_t addr_type)
{
    int i;
    for (i = 0; i < result->count; ++i) {
        if (strcmp(result->entries[i].mac, mac) == 0 &&
            result->entries[i].addr_type == addr_type)
            return i;
    }
    return -1;
}

bt_scan_result_t bt_scan_bredr(int adapter_index, int timeout_seconds)
{
    bt_scan_result_t result;
    int sock;
    struct mgmt_cp_start_discovery cp;
    struct mgmt_cp_stop_discovery stop_cp;
    uint8_t status = 0xff;
    uint8_t data[32];
    size_t data_len = sizeof(data);
    struct pollfd pfd;
    uint8_t buf[2048];
    long end_ms;
    int started = 0;

    memset(&result, 0, sizeof(result));
    result.status = BT_STATUS_FAIL;
    result.mgmt_status = 0xff;

    sock = bt_open_mgmt_socket();
    if (sock < 0) {
        snprintf(result.entries[0].name, sizeof(result.entries[0].name), "failed to open mgmt socket");
        return result;
    }

    cp.type = MGMT_DISCOV_TYPE_BREDR;

    if (bt_send_mgmt_cmd(sock, MGMT_OP_START_DISCOVERY, (uint16_t)adapter_index,
                         &cp, sizeof(cp)) < 0) {
        close(sock);
        return result;
    }

    if (bt_wait_mgmt_cmd_result(sock, MGMT_OP_START_DISCOVERY, (uint16_t)adapter_index,
                                &status, data, &data_len, 3000) < 0) {
        close(sock);
        result.status = BT_STATUS_TIMEOUT;
        return result;
    }

    result.mgmt_status = status;
    if (status != MGMT_STATUS_SUCCESS) {
        close(sock);
        result.status = BT_STATUS_REMOTE;
        return result;
    }

    started = 1;
    end_ms = (long)timeout_seconds * 1000L;

    pfd.fd = sock;
    pfd.events = POLLIN;

    while (end_ms > 0) {
        int step = end_ms > 500 ? 500 : (int)end_ms;
        int pr = poll(&pfd, 1, step);
        end_ms -= step;

        if (pr < 0) {
            result.status = BT_STATUS_FAIL;
            break;
        }

        if (pr == 0)
            continue;

        if (pfd.revents & POLLIN) {
            ssize_t n = read(sock, buf, sizeof(buf));
            struct mgmt_hdr *hdr;
            uint16_t evt, idx, len;

            if (n < (ssize_t)sizeof(*hdr))
                continue;

            hdr = (struct mgmt_hdr *)buf;
            evt = bt_le16_to_cpu(hdr->opcode);
            idx = bt_le16_to_cpu(hdr->index);
            len = bt_le16_to_cpu(hdr->len);

            if ((int)idx != adapter_index)
                continue;

            if (evt == MGMT_EV_DEVICE_FOUND) {
                struct mgmt_ev_device_found *df;
                uint16_t eir_len;
                char mac[18];
                char name[BT_MAX_NAME_LEN + 1];
                int entry_index;

                if (len < sizeof(*df))
                    continue;

                df = (struct mgmt_ev_device_found *)(buf + sizeof(*hdr));
                eir_len = bt_le16_to_cpu(df->eir_len);
                if ((size_t)len < sizeof(*df) + eir_len)
                    continue;

                bt_ba2str(&df->addr, mac);
                bt_eir_extract_name(df->eir, eir_len, name, sizeof(name));

                entry_index = bt_find_scan_index(&result, mac, df->addr_type);
                if (entry_index < 0) {
                    if (result.count >= BT_MAX_SCAN_RESULTS)
                        continue;

                    entry_index = result.count++;
                    memset(&result.entries[entry_index], 0, sizeof(result.entries[entry_index]));
                    snprintf(result.entries[entry_index].mac,
                             sizeof(result.entries[entry_index].mac), "%s", mac);
                    result.entries[entry_index].addr_type = df->addr_type;
                }

                snprintf(result.entries[entry_index].name,
                         sizeof(result.entries[entry_index].name), "%s", name);
                result.entries[entry_index].rssi = (int)df->rssi;
                result.entries[entry_index].flags = bt_le32_to_cpu(df->flags);

                if (result.entries[entry_index].flags & MGMT_DEV_FOUND_FLAG_CONFIRM_NAME) {
                    struct mgmt_cp_confirm_name cn;
                    memset(&cn, 0, sizeof(cn));
                    bt_bacpy(&cn.addr, &df->addr);
                    cn.addr_type = df->addr_type;
                    cn.name_known = (strcmp(name, "unknown") != 0) ? 1 : 0;
                    bt_send_mgmt_cmd(sock, MGMT_OP_CONFIRM_NAME, (uint16_t)adapter_index,
                                     &cn, sizeof(cn));
                }
            } else if (evt == MGMT_EV_DISCOVERING) {
                struct mgmt_ev_discovering *dv;
                if (len >= sizeof(*dv)) {
                    dv = (struct mgmt_ev_discovering *)(buf + sizeof(*hdr));
                    if (dv->discovering == 0x00)
                        break;
                }
            }
        }
    }

    if (started) {
        stop_cp.type = MGMT_DISCOV_TYPE_BREDR;
        bt_send_mgmt_cmd(sock, MGMT_OP_STOP_DISCOVERY, (uint16_t)adapter_index,
                         &stop_cp, sizeof(stop_cp));
    }

    close(sock);

    result.status = (result.count > 0) ? BT_STATUS_OK : BT_STATUS_NOT_FOUND;
    return result;
}
