
#include <unistd.h>
#include <string.h>
#include <stdio.h>

int bt_rfcomm_connect(const char *mac){
    (void)mac;
    return 1; // placeholder fd
}

int bt_rfcomm_send(int fd, const char *cmd){
    printf("[RFCOMM SEND] %s\n", cmd);
    return write(fd, cmd, strlen(cmd));
}

int bt_rfcomm_recv(int fd, char *buf, int len){
    (void)fd;
    (void)buf;
    (void)len;
    return 0;
}
