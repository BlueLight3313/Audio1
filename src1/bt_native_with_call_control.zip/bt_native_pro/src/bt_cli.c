#include "bt_adapter.h"
#include "bt_cli.h"
#include "bt_log.h"
#include "bt_util.h"

static volatile sig_atomic_t g_stop_requested = 0;

static void bt_cli_signal_handler(int sig)
{
    (void)sig;
    g_stop_requested = 1;
}

static void bt_cli_print_help(void)
{
    printf("Commands:\n");
    printf("  help                 Show this help\n");
    printf("  status               Print adapter status\n");
    printf("  power on             Power on adapter\n");
    printf("  power off            Power off adapter\n");
    printf("  discoverable on      Enable inquiry+page scan\n");
    printf("  discoverable off     Disable scan\n");
    printf("  name set <text>      Set local adapter name\n");
    printf("  quit                 Exit program\n");
}

static void bt_cli_print_status(uint16_t dev_id)
{
    struct bt_adapter_status status;
    char addr[32];
    char flags[256];
    int rc;

    rc = bt_adapter_get_status(dev_id, &status);
    if (rc < 0) {
        bt_log_error("status failed: %s", strerror(-rc));
        return;
    }

    bt_format_bdaddr(&status.bdaddr, addr, sizeof(addr));
    bt_format_flags(status.flags, flags, sizeof(flags));

    printf("Adapter      : %s (id=%u)\n", status.name, status.dev_id);
    printf("BD_ADDR      : %s\n", addr);
    printf("Flags        : %s\n", flags);
    printf("Scan Enable  : %s (0x%02X)\n", bt_scan_enable_to_string(status.scan_enable), status.scan_enable);
    printf("Local Name   : %s\n", status.local_name[0] ? status.local_name : "<unavailable>");
}

int bt_cli_run(uint16_t dev_id)
{
    char line[512];

    signal(SIGINT, bt_cli_signal_handler);
    signal(SIGTERM, bt_cli_signal_handler);

    bt_cli_print_help();

    while (!g_stop_requested) {
        printf("bt[%u]> ", dev_id);
        fflush(stdout);

        if (fgets(line, sizeof(line), stdin) == NULL) {
            if (feof(stdin)) {
                break;
            }
            clearerr(stdin);
            continue;
        }

        line[strcspn(line, "\r\n")] = '\0';

        if (line[0] == '\0') {
            continue;
        }

        if (strcmp(line, "help") == 0) {
            bt_cli_print_help();
            continue;
        }

        if (strcmp(line, "status") == 0) {
            bt_cli_print_status(dev_id);
            continue;
        }

        if (strcmp(line, "power on") == 0) {
            int rc = bt_adapter_power_set(dev_id, true);
            if (rc < 0) {
                bt_log_error("power on failed: %s", strerror(-rc));
            } else {
                bt_log_info("adapter powered on");
            }
            continue;
        }

        if (strcmp(line, "power off") == 0) {
            int rc = bt_adapter_power_set(dev_id, false);
            if (rc < 0) {
                bt_log_error("power off failed: %s", strerror(-rc));
            } else {
                bt_log_info("adapter powered off");
            }
            continue;
        }

        if (strcmp(line, "discoverable on") == 0) {
            int rc = bt_adapter_set_discoverable(dev_id, true);
            if (rc < 0) {
                bt_log_error("discoverable on failed: %s", strerror(-rc));
            } else {
                bt_log_info("discoverable enabled");
            }
            continue;
        }

        if (strcmp(line, "discoverable off") == 0) {
            int rc = bt_adapter_set_discoverable(dev_id, false);
            if (rc < 0) {
                bt_log_error("discoverable off failed: %s", strerror(-rc));
            } else {
                bt_log_info("discoverable disabled");
            }
            continue;
        }

        if (strncmp(line, "name set ", 9) == 0) {
            const char *name = line + 9;
            int rc = bt_adapter_set_local_name(dev_id, name);
            if (rc < 0) {
                bt_log_error("set local name failed: %s", strerror(-rc));
            } else {
                bt_log_info("local name updated");
            }
            continue;
        }

        if (strcmp(line, "quit") == 0 || strcmp(line, "exit") == 0) {
            break;
        }

        bt_log_warn("unknown command: %s", line);
    }

    return 0;
}
