
#include <stdio.h>
#include <string.h>

void bt_scan_run();
void bt_dev_print_all();
void bt_pair_suggested(int);

int main(){
    char cmd[128];

    while(1){
        printf("bt> ");
        fgets(cmd,128,stdin);

        if(strncmp(cmd,"scan",4)==0){
            bt_scan_run();
        }
        else if(strncmp(cmd,"devices",7)==0){
            bt_dev_print_all();
        }
        else if(strncmp(cmd,"pair suggested",14)==0){
            int idx=atoi(cmd+15);
            bt_pair_suggested(idx);
        }
        else if(strncmp(cmd,"quit",4)==0){
            break;
        }
    }
    return 0;
}
