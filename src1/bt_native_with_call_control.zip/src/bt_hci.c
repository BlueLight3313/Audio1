
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/time.h>

#include "bt_defs.h"
#include "bt_types.h"
#include "bt_hci.h"

uint16_t bt_hci_cpu_to_le16(uint16_t v)
{
    union { uint16_t v; uint8_t b[2]; } u;
    u.v = 1;
    if (u.b[0] == 1) {
        return v;
    }
    return (uint16_t)((v >> 8) | (v << 8));
}

uint16_t bt_hci_le16_to_cpu(uint16_t v)
{
    return bt_hci_cpu_to_le16(v);
}

void bt_hci_filter_set_bit(unsigned int bit, uint32_t *word)
{
    word[bit >> 5] |= (1U << (bit & 31));
}

int bt_hci_open_raw(void)
{
    return socket(AF_BLUETOOTH, SOCK_RAW, BTPROTO_HCI);
}

int bt_hci_bind_raw(int sock, int dev_id)
{
    struct sockaddr_hci addr;
    memset(&addr, 0, sizeof(addr));
    addr.hci_family = AF_BLUETOOTH;
    addr.hci_dev = (unsigned short)dev_id;
    addr.hci_channel = HCI_CHANNEL_RAW;
    return bind(sock, (struct sockaddr *)&addr, sizeof(addr));
}

int bt_hci_open_bound_raw(int dev_id)
{
    int sock = bt_hci_open_raw();
    if (sock < 0) {
        return -1;
    }
    if (bt_hci_bind_raw(sock, dev_id) < 0) {
        close(sock);
        return -1;
    }
    return sock;
}

int bt_hci_send_cmd_only(int hci_sock, uint16_t opcode, const void *cmd_params, uint8_t cmd_params_len)
{
    uint8_t txbuf[1 + sizeof(struct hci_command_hdr) + 255];
    size_t txlen;

    txbuf[0] = BT_HCI_COMMAND_PKT;
    ((struct hci_command_hdr *)(txbuf + 1))->opcode = bt_hci_cpu_to_le16(opcode);
    ((struct hci_command_hdr *)(txbuf + 1))->plen = cmd_params_len;
    if (cmd_params_len > 0 && cmd_params != NULL) {
        memcpy(txbuf + 1 + sizeof(struct hci_command_hdr), cmd_params, cmd_params_len);
    }
    txlen = 1 + sizeof(struct hci_command_hdr) + cmd_params_len;
    return (write(hci_sock, txbuf, txlen) == (ssize_t)txlen) ? 0 : -1;
}

int bt_hci_send_req(
    int hci_sock,
    uint16_t opcode,
    const void *cmd_params,
    uint8_t cmd_params_len,
    void *rsp_buf,
    size_t rsp_buf_size,
    int timeout_ms
)
{
    uint8_t rxbuf[BT_MAX_HCI_EVENT_SIZE];
    struct hci_filter filter;
    struct hci_filter old_filter;
    struct timeval tv;
    socklen_t optlen;
    ssize_t n;
    struct hci_event_hdr *eh;
    uint8_t *payload;


    memset(&filter, 0, sizeof(filter));
    bt_hci_filter_set_bit(BT_HCI_EVENT_PKT, &filter.type_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_CMD_COMPLETE, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_CMD_STATUS, filter.event_mask);
    filter.opcode = opcode;

    optlen = sizeof(old_filter);
    if (getsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, &optlen) < 0) {
        return -1;
    }

    if (setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &filter, sizeof(filter)) < 0) {
        return -1;
    }

    tv.tv_sec = timeout_ms / 1000;
    tv.tv_usec = (timeout_ms % 1000) * 1000;
    if (setsockopt(hci_sock, BT_SOL_SOCKET, BT_SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
        setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
        return -1;
    }

    if (bt_hci_send_cmd_only(hci_sock, opcode, cmd_params, cmd_params_len) < 0) {
        setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
        return -1;
    }

    for (;;) {
        n = read(hci_sock, rxbuf, sizeof(rxbuf));
        if (n < 0) {
            setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
            return -1;
        }

        if (n < 1 + (ssize_t)sizeof(struct hci_event_hdr)) {
            continue;
        }

        if (rxbuf[0] != BT_HCI_EVENT_PKT) {
            continue;
        }

        eh = (struct hci_event_hdr *)(rxbuf + 1);
        payload = rxbuf + 1 + sizeof(struct hci_event_hdr);

        if (eh->evt == BT_HCI_EV_CMD_STATUS) {
            struct bt_hci_ev_cmd_status *cs;
            if (n < 1 + (ssize_t)sizeof(struct hci_event_hdr) + (ssize_t)sizeof(*cs)) {
                continue;
            }
            cs = (struct bt_hci_ev_cmd_status *)payload;
            if (cs->opcode != bt_hci_cpu_to_le16(opcode)) {
                continue;
            }
            if (rsp_buf != NULL && rsp_buf_size > 0) {
                size_t copy_len = sizeof(*cs) < rsp_buf_size ? sizeof(*cs) : rsp_buf_size;
                memcpy(rsp_buf, cs, copy_len);
            }
            if (cs->status != 0x00) {
                errno = EIO;
                setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
                return -1;
            }
            continue;
        }

        if (eh->evt == BT_HCI_EV_CMD_COMPLETE) {
            struct bt_hci_ev_cmd_complete *cc;
            uint8_t *ret_params;
            size_t ret_len;

            if (n < 1 + (ssize_t)sizeof(struct hci_event_hdr) + (ssize_t)sizeof(*cc)) {
                continue;
            }
            cc = (struct bt_hci_ev_cmd_complete *)payload;
            if (cc->opcode != bt_hci_cpu_to_le16(opcode)) {
                continue;
            }

            ret_params = payload + sizeof(*cc);
            ret_len = (size_t)eh->plen - sizeof(*cc);
            if (rsp_buf != NULL && rsp_buf_size > 0) {
                size_t copy_len = ret_len < rsp_buf_size ? ret_len : rsp_buf_size;
                memcpy(rsp_buf, ret_params, copy_len);
            }

            setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
            return 0;
        }
    }
}
