#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <poll.h>
#include <time.h>

#include "../include/bt_sms.h"
#include "../compat/bluetooth/rfcomm.h"
#include "../include/bt_log.h"

#define BT_SMS_MAX_TEXT 512
#define BT_SMS_DEFAULT_CHANNEL 1
#define BT_SMS_ACK_TIMEOUT_MS 5000

static unsigned long g_sms_message_seq = 1;

static void bt_sms_make_message_id(char *out, size_t out_sz)
{
    struct timespec ts;
    unsigned long seq;

    if (!out || out_sz == 0)
        return;

    memset(&ts, 0, sizeof(ts));
    clock_gettime(CLOCK_REALTIME, &ts);
    seq = g_sms_message_seq++;
    snprintf(out, out_sz, "%ld-%lu", (long)ts.tv_sec, seq);
}

const char *bt_sms_delivery_code_str(int code)
{
    switch (code) {
    case BT_SMS_RESULT_RECEIVED:
        return "received";
    case BT_SMS_RESULT_NOT_SENT:
        return "not sent";
    case BT_SMS_RESULT_CONFIRMING:
        return "confirming";
    case BT_SMS_RESULT_UNKNOWN:
        return "unknown";
    default:
        return "unrecognized";
    }
}

static int bt_sms_is_sendable(bt_context_t *ctx, const char *mac, const char *text, char *reason, size_t reason_sz)
{
    bt_device_t *dev;

    if (!ctx || !mac || !mac[0] || !text || !text[0]) {
        snprintf(reason, reason_sz, "%s", "invalid SMS arguments");
        return 0;
    }

    if (strlen(text) > BT_SMS_MAX_TEXT) {
        snprintf(reason, reason_sz, "text too long (max %d bytes)", BT_SMS_MAX_TEXT);
        return 0;
    }

    dev = bt_context_find_by_mac(ctx, mac);
    if (!dev) {
        snprintf(reason, reason_sz, "device not found in registry: %s", mac);
        return 0;
    }

    if (!dev->connected) {
        snprintf(reason, reason_sz, "device is not marked connected: %s", mac);
        return 0;
    }

    if (!bt_context_get_host_id(ctx)[0]) {
        snprintf(reason, reason_sz, "%s", "host identifier is empty");
        return 0;
    }

    snprintf(reason, reason_sz, "%s", "sendable");
    return 1;
}

static int bt_sms_parse_ack_line(const char *line, const char *message_id, int *out_code, char *detail, size_t detail_sz)
{
    char tag[32];
    char ack_id[32];
    int code;
    char tail[128];
    int matched;

    if (!line || !message_id || !out_code)
        return -1;

    tag[0] = '\0';
    ack_id[0] = '\0';
    code = 0;
    tail[0] = '\0';

    matched = sscanf(line, "%31[^|]|%31[^|]|%d|%127[^\n]", tag, ack_id, &code, tail);
    if (matched >= 3 && strcmp(tag, "SMS-RESULT") == 0 && strcmp(ack_id, message_id) == 0) {
        *out_code = code;
        if (detail && detail_sz > 0) {
            if (matched >= 4 && tail[0])
                snprintf(detail, detail_sz, "%s", tail);
            else
                snprintf(detail, detail_sz, "%s", bt_sms_delivery_code_str(code));
        }
        return 0;
    }

    if (sscanf(line, "%d", &code) == 1) {
        *out_code = code;
        if (detail && detail_sz > 0)
            snprintf(detail, detail_sz, "%s", bt_sms_delivery_code_str(code));
        return 0;
    }

    return -1;
}

static int bt_sms_wait_for_ack(int sock, const char *message_id, int timeout_ms, int *out_code, char *detail, size_t detail_sz)
{
    struct pollfd pfd;
    char buf[256];
    int used = 0;

    if (!message_id || !out_code)
        return -1;

    memset(buf, 0, sizeof(buf));
    pfd.fd = sock;
    pfd.events = POLLIN;
    pfd.revents = 0;

    while (timeout_ms > 0) {
        int pr = poll(&pfd, 1, timeout_ms);
        if (pr < 0)
            return -1;
        if (pr == 0)
            return -1;
        if (pfd.revents & (POLLERR | POLLHUP | POLLNVAL))
            return -1;
        if (pfd.revents & POLLIN) {
            ssize_t n = read(sock, buf + used, sizeof(buf) - 1 - (size_t)used);
            if (n <= 0)
                return -1;
            used += (int)n;
            buf[used] = '\0';

            while (1) {
                char *newline = strchr(buf, '\n');
                if (!newline)
                    break;
                *newline = '\0';
                if (bt_sms_parse_ack_line(buf, message_id, out_code, detail, detail_sz) == 0)
                    return 0;
                used -= (int)((newline + 1) - buf);
                memmove(buf, newline + 1, (size_t)used + 1);
            }
        }
        timeout_ms = 0;
    }

    return -1;
}

static int bt_sms_send_payload(const char *mac, uint8_t channel, const char *payload, size_t payload_len,
                               const char *message_id, int *out_delivery_code, int *out_ack_received,
                               char *ack_detail, size_t ack_detail_sz)
{
    int sock;
    struct sockaddr_rc remote;
    bdaddr_t addr;
    ssize_t written;

    if (bt_str2ba(mac, &addr) < 0)
        return -1;

    sock = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);
    if (sock < 0)
        return -1;

    memset(&remote, 0, sizeof(remote));
    remote.rc_family = AF_BLUETOOTH;
    remote.rc_channel = channel;
    bt_bacpy(&remote.rc_bdaddr, &addr);

    if (connect(sock, (struct sockaddr *)&remote, sizeof(remote)) < 0) {
        close(sock);
        return -1;
    }

    written = write(sock, payload, payload_len);
    if (written < 0 || (size_t)written != payload_len) {
        close(sock);
        return -1;
    }

    if (out_ack_received)
        *out_ack_received = 0;
    if (out_delivery_code)
        *out_delivery_code = BT_SMS_RESULT_UNKNOWN;
    if (ack_detail && ack_detail_sz > 0)
        snprintf(ack_detail, ack_detail_sz, "%s", "ack not received");

    if (message_id && out_delivery_code) {
        int code = BT_SMS_RESULT_UNKNOWN;
        char detail[128];
        detail[0] = '\0';
        if (bt_sms_wait_for_ack(sock, message_id, BT_SMS_ACK_TIMEOUT_MS, &code, detail, sizeof(detail)) == 0) {
            if (out_ack_received)
                *out_ack_received = 1;
            *out_delivery_code = code;
            if (ack_detail && ack_detail_sz > 0)
                snprintf(ack_detail, ack_detail_sz, "%s", detail[0] ? detail : bt_sms_delivery_code_str(code));
        }
    }

    close(sock);
    return 0;
}

void bt_sms_result_init(bt_sms_result_t *result)
{
    if (!result)
        return;

    memset(result, 0, sizeof(*result));
    result->status = BT_STATUS_FAIL;
    result->delivery_code = BT_SMS_RESULT_UNKNOWN;
    snprintf(result->detail, sizeof(result->detail), "%s", "SMS request was not sent");
}

bt_sms_result_t bt_sms_send_to_mac(bt_context_t *ctx, const char *mac,
                                   const char *text, uint8_t channel)
{
    bt_sms_result_t result;
    char payload[BT_SMS_MAX_TEXT + 192];
    const char *host_id;
    char reason[128];
    int delivery_code = BT_SMS_RESULT_UNKNOWN;
    int ack_received = 0;
    char ack_detail[128];

    bt_sms_result_init(&result);
    bt_logf("sms", BT_LOG_READY, "broadcast_channel=%u", channel);

    if (channel == 0)
        channel = BT_SMS_DEFAULT_CHANNEL;

    result.targets_attempted = 1;
    if (!bt_sms_is_sendable(ctx, mac, text, reason, sizeof(reason))) {
        result.status = BT_STATUS_REMOTE;
        result.sendable = 0;
        snprintf(result.detail, sizeof(result.detail), "sendable-check failed: %.96s", reason);
        bt_logf("sms", BT_LOG_ERROR, "sendable-check failed target=%s reason=%s", mac ? mac : "", reason);
        bt_log_result_status("sms", result.status, "target=%s message_id=%s detail=%s", mac, result.message_id, result.detail);
        return result;
    }

    result.sendable = 1;
    bt_logf("sms", BT_LOG_STARTED, "message is sendable target=%s", mac);
    host_id = bt_context_get_host_id(ctx);
    bt_sms_make_message_id(result.message_id, sizeof(result.message_id));
    snprintf(payload, sizeof(payload), "SMS|%s|%s|%s\n", host_id, result.message_id, text);

    bt_logf("sms", BT_LOG_DOING, "sending payload message_id=%s", result.message_id);
    if (bt_sms_send_payload(mac, channel, payload, strlen(payload), result.message_id,
                            &delivery_code, &ack_received, ack_detail, sizeof(ack_detail)) == 0) {
        result.targets_sent = 1;
        result.ack_received = ack_received;
        result.delivery_code = delivery_code;
        bt_context_mark_connected(ctx, mac, 1);

        if (!ack_received) {
            result.status = BT_STATUS_REMOTE;
            snprintf(result.detail, sizeof(result.detail),
                     "SMS payload sent to %s on RFCOMM channel %u, but no logical result ack was received",
                     mac, channel);
            bt_log_result_status("sms", result.status, "target=%s message_id=%s detail=%s", mac, result.message_id, result.detail);
            return result;
        }

        if (delivery_code == BT_SMS_RESULT_RECEIVED || delivery_code == BT_SMS_RESULT_CONFIRMING) {
            result.status = BT_STATUS_OK;
            snprintf(result.detail, sizeof(result.detail),
                     "SMS result %.17s: %s (%.72s)",
                     mac, bt_sms_delivery_code_str(delivery_code), ack_detail);
        } else {
            result.status = BT_STATUS_REMOTE;
            snprintf(result.detail, sizeof(result.detail),
                     "SMS result %.17s: %s (%.72s)",
                     mac, bt_sms_delivery_code_str(delivery_code), ack_detail);
        }
    } else {
        result.status = BT_STATUS_REMOTE;
        result.delivery_code = BT_SMS_RESULT_NOT_SENT;
        snprintf(result.detail, sizeof(result.detail),
                 "failed to send SMS request to %s on RFCOMM channel %u", mac, channel);
        bt_context_mark_connected(ctx, mac, 0);
    }

    bt_log_result_status("sms", result.status, "target=%s message_id=%s delivery=%d ack=%d detail=%s", mac, result.message_id, result.delivery_code, result.ack_received, result.detail);
    return result;
}

bt_sms_result_t bt_sms_send_all_connected(bt_context_t *ctx, const char *text,
                                          uint8_t channel)
{
    bt_sms_result_t result;
    int i;

    bt_sms_result_init(&result);
    bt_logf("sms", BT_LOG_READY, "broadcast_channel=%u", channel);

    if (!ctx || !text || !text[0]) {
        result.status = BT_STATUS_PROTOCOL;
        snprintf(result.detail, sizeof(result.detail), "%s", "invalid SMS arguments");
        return result;
    }

    if (channel == 0)
        channel = BT_SMS_DEFAULT_CHANNEL;

    result.status = BT_STATUS_OK;
    result.delivery_code = BT_SMS_RESULT_RECEIVED;
    snprintf(result.detail, sizeof(result.detail), "%s", "SMS requests processed");

    for (i = 0; i < ctx->count; ++i) {
        bt_device_t *dev = &ctx->devices[i];
        bt_sms_result_t one;

        if (!dev->used || !dev->connected)
            continue;

        one = bt_sms_send_to_mac(ctx, dev->mac, text, channel);
        result.targets_attempted += one.targets_attempted;
        result.targets_sent += one.targets_sent;

        if (one.ack_received)
            result.ack_received += 1;
        if (one.status != BT_STATUS_OK)
            result.status = BT_STATUS_REMOTE;
        if (one.delivery_code == BT_SMS_RESULT_NOT_SENT || one.delivery_code == BT_SMS_RESULT_UNKNOWN)
            result.delivery_code = one.delivery_code;
        else if (one.delivery_code == BT_SMS_RESULT_CONFIRMING && result.delivery_code == BT_SMS_RESULT_RECEIVED)
            result.delivery_code = BT_SMS_RESULT_CONFIRMING;
    }

    if (result.targets_attempted == 0) {
        result.status = BT_STATUS_NOT_FOUND;
        result.delivery_code = BT_SMS_RESULT_UNKNOWN;
        snprintf(result.detail, sizeof(result.detail), "%s", "no connected devices in registry");
    } else if (result.targets_sent == 0) {
        result.delivery_code = BT_SMS_RESULT_NOT_SENT;
        snprintf(result.detail, sizeof(result.detail), "%s", "SMS request failed for all connected devices");
    } else if (result.ack_received == 0) {
        result.delivery_code = BT_SMS_RESULT_UNKNOWN;
        snprintf(result.detail, sizeof(result.detail), "%s", "SMS payloads were written, but no logical result ack was received");
    } else if (result.targets_sent < result.targets_attempted) {
        snprintf(result.detail, sizeof(result.detail), "SMS request sent to %d of %d connected devices",
                 result.targets_sent, result.targets_attempted);
    } else {
        snprintf(result.detail, sizeof(result.detail), "SMS request sent to all %d connected devices",
                 result.targets_sent);
    }

    bt_log_result_status("sms", result.status, "broadcast attempted=%d sent=%d ack=%d delivery=%d detail=%s", result.targets_attempted, result.targets_sent, result.ack_received, result.delivery_code, result.detail);
    return result;
}
