
#include <stdio.h>
#include "bt_device.h"

void bt_pair_suggested(int idx){
    bt_dev_t* d=bt_dev_get(idx);
    if(!d){
        printf("Invalid index\n");
        return;
    }

    printf("Pairing %s using policy %s\n",
        d->mac_str,
        bt_policy_str(d->policy));

    /* integrate real pairing engine here */
}
