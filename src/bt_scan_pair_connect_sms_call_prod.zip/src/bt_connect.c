#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <sys/socket.h>

#include "../include/bt_connect.h"
#include "../include/bt_mgmt.h"
#include "../compat/bluetooth/l2cap.h"

static int bt_is_connected_now(int adapter_index, const bdaddr_t *target, uint8_t addr_type)
{
    int sock;
    uint8_t status = 0xff;
    uint8_t data[1024];
    size_t data_len = sizeof(data);
    int connected = 0;

    sock = bt_open_mgmt_socket();
    if (sock < 0)
        return 0;

    if (bt_send_mgmt_cmd(sock, MGMT_OP_GET_CONNECTIONS, (uint16_t)adapter_index,
                         NULL, 0) == 0 &&
        bt_wait_mgmt_cmd_result(sock, MGMT_OP_GET_CONNECTIONS, (uint16_t)adapter_index,
                                &status, data, &data_len, 3000) == 0 &&
        status == MGMT_STATUS_SUCCESS && data_len >= sizeof(struct mgmt_rp_get_connections)) {
        struct mgmt_rp_get_connections *rp;
        uint16_t count;
        uint16_t i;

        rp = (struct mgmt_rp_get_connections *)data;
        count = bt_le16_to_cpu(rp->conn_count);

        for (i = 0; i < count; ++i) {
            struct mgmt_addr_info *ai;
            size_t need = sizeof(*rp) + (size_t)(i + 1) * sizeof(struct mgmt_addr_info);
            if (need > data_len)
                break;

            ai = (struct mgmt_addr_info *)(rp->entries + i * sizeof(struct mgmt_addr_info));
            if (ai->addr_type == addr_type && bt_addr_equals(&ai->addr, target)) {
                connected = 1;
                break;
            }
        }
    }

    close(sock);
    return connected;
}

bt_connect_result_t bt_connect_bredr_generic(int adapter_index, const char *mac,
                                             int verify_timeout_ms,
                                             int hold_ms)
{
    bt_connect_result_t result;
    struct sockaddr_l2 remote;
    bdaddr_t target;
    int sock;
    int flags;
    int rc;
    struct pollfd pfd;
    int waited = 0;

    memset(&result, 0, sizeof(result));
    result.status = BT_STATUS_FAIL;
    result.mgmt_status = 0xff;
    snprintf(result.detail, sizeof(result.detail), "connect did not complete");

    if (bt_str2ba(mac, &target) < 0) {
        result.status = BT_STATUS_PROTOCOL;
        snprintf(result.detail, sizeof(result.detail), "invalid MAC address");
        return result;
    }

    if (bt_is_connected_now(adapter_index, &target, MGMT_ADDR_BREDR)) {
        result.status = BT_STATUS_ALREADY;
        result.already_connected = 1;
        result.mgmt_connected_verified = 1;
        snprintf(result.detail, sizeof(result.detail), "device is already connected");
        return result;
    }

    memset(&remote, 0, sizeof(remote));
    remote.l2_family = AF_BLUETOOTH;
    remote.l2_psm = bt_htobs(0x0001);
    remote.l2_bdaddr_type = MGMT_ADDR_BREDR;
    bt_bacpy(&remote.l2_bdaddr, &target);

    sock = socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP);
    if (sock < 0) {
        result.status = BT_STATUS_FAIL;
        snprintf(result.detail, sizeof(result.detail), "failed to create L2CAP socket");
        return result;
    }

    flags = fcntl(sock, F_GETFL, 0);
    if (flags >= 0)
        fcntl(sock, F_SETFL, flags | O_NONBLOCK);

    rc = connect(sock, (struct sockaddr *)&remote, sizeof(remote));
    if (rc == 0) {
        result.transport_socket_connected = 1;
    } else if (errno == EINPROGRESS) {
        pfd.fd = sock;
        pfd.events = POLLOUT;

        rc = poll(&pfd, 1, verify_timeout_ms);
        if (rc < 0) {
            close(sock);
            result.status = BT_STATUS_FAIL;
            snprintf(result.detail, sizeof(result.detail), "poll failed during connect");
            return result;
        }
        if (rc == 0) {
            close(sock);
            result.status = BT_STATUS_TIMEOUT;
            snprintf(result.detail, sizeof(result.detail), "connect timed out");
            return result;
        }

        if (pfd.revents & POLLOUT) {
            int so_error = 0;
            socklen_t so_len = sizeof(so_error);
            if (getsockopt(sock, SOL_SOCKET, SO_ERROR, &so_error, &so_len) < 0 || so_error != 0) {
                close(sock);
                result.status = BT_STATUS_REMOTE;
                snprintf(result.detail, sizeof(result.detail), "connect failed: %s",
                         so_error ? strerror(so_error) : "SO_ERROR");
                return result;
            }
            result.transport_socket_connected = 1;
        } else {
            close(sock);
            result.status = BT_STATUS_REMOTE;
            snprintf(result.detail, sizeof(result.detail), "connect failed before socket became writable");
            return result;
        }
    } else {
        close(sock);
        result.status = BT_STATUS_REMOTE;
        snprintf(result.detail, sizeof(result.detail), "connect failed: %s", strerror(errno));
        return result;
    }

    while (waited < verify_timeout_ms) {
        if (bt_is_connected_now(adapter_index, &target, MGMT_ADDR_BREDR)) {
            result.mgmt_connected_verified = 1;
            break;
        }
        usleep(100000);
        waited += 100;
    }

    if (hold_ms > 0)
        usleep((useconds_t)hold_ms * 1000U);

    close(sock);

    if (result.transport_socket_connected && result.mgmt_connected_verified) {
        result.status = BT_STATUS_OK;
        snprintf(result.detail, sizeof(result.detail), "baseband connection verified");
    } else if (result.transport_socket_connected) {
        result.status = BT_STATUS_OK;
        snprintf(result.detail, sizeof(result.detail),
                 "transport socket connected; mgmt verification was not observed within timeout");
    } else {
        result.status = BT_STATUS_REMOTE;
        snprintf(result.detail, sizeof(result.detail), "connect failed");
    }

    return result;
}
