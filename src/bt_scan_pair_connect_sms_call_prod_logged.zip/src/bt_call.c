#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <time.h>
#include <sys/socket.h>

#include "../include/bt_call.h"
#include "../compat/bluetooth/rfcomm.h"
#include "../compat/bluetooth/sco.h"
#include "../include/bt_log.h"

#define BT_CALL_CONTROL_BUF 512
#define BT_DEFAULT_RFCOMM_CHANNEL 1

static void bt_copy_string(char *dst, size_t dst_sz, const char *src)
{
    size_t src_len;

    if (!dst || dst_sz == 0)
        return;
    if (!src)
        src = "";

    src_len = strlen(src);
    if (src_len >= dst_sz)
        src_len = dst_sz - 1;

    memcpy(dst, src, src_len);
    dst[src_len] = 0;
}

void bt_call_options_init(bt_call_options_t *options)
{
    if (!options)
        return;

    memset(options, 0, sizeof(*options));
    options->rfcomm_channel = BT_DEFAULT_RFCOMM_CHANNEL;
    options->control_timeout_ms = 8000;
    options->sco_timeout_ms = 5000;
    options->hold_seconds = 10;
    options->require_audio_ready_ack = 1;
    options->require_sco_write_probe = 1;
}

void bt_call_result_init(bt_call_result_t *result)
{
    if (!result)
        return;
    memset(result, 0, sizeof(*result));
    result->status = BT_STATUS_FAIL;
    bt_copy_string(result->detail, sizeof(result->detail), "call did not start");
}

const char *bt_call_state_str(bt_call_state_t state)
{
    switch (state) {
    case BT_CALL_STATE_IDLE: return "IDLE";
    case BT_CALL_STATE_PRECHECKING: return "PRECHECKING";
    case BT_CALL_STATE_CTRL_CONNECTING: return "CTRL_CONNECTING";
    case BT_CALL_STATE_CTRL_READY: return "CTRL_READY";
    case BT_CALL_STATE_SETUP_SENT: return "SETUP_SENT";
    case BT_CALL_STATE_WAIT_ACCEPT: return "WAIT_ACCEPT";
    case BT_CALL_STATE_AUDIO_CONNECTING: return "AUDIO_CONNECTING";
    case BT_CALL_STATE_AUDIO_READY: return "AUDIO_READY";
    case BT_CALL_STATE_ACTIVE: return "ACTIVE";
    case BT_CALL_STATE_ENDING: return "ENDING";
    case BT_CALL_STATE_FAILED: return "FAILED";
    default: return "UNKNOWN";
    }
}

/*
 * The call engine keeps the control socket and the SCO socket in the same
 * process because these file descriptors are live kernel resources. They cannot
 * be safely reconstructed by a later CLI invocation the way paired/connected
 * flags can be reconstructed from the saved registry file.
 */
typedef struct {
    bt_context_t *ctx;
    bt_device_t *dev;
    int adapter_index;
    bt_call_options_t options;
    bt_call_result_t result;
    int control_fd;
    int sco_fd;
    char call_id[32];
} bt_call_session_t;

static void bt_call_fail(bt_call_session_t *session, bt_status_t status,
                         bt_call_state_t state, const char *detail)
{
    if (!session)
        return;

    session->result.status = status;
    bt_copy_string(session->result.detail, sizeof(session->result.detail), detail);
    bt_logf("call", status == BT_STATUS_OK ? BT_LOG_DONE : BT_LOG_ERROR, "call_state=%s detail=%s", bt_call_state_str(state), detail ? detail : "");
    if (session->dev) {
        session->dev->call_state = state;
        if (status != BT_STATUS_OK) {
            session->dev->audio_verified = 0;
        }
    }
}

static void bt_call_build_id(char *out, size_t out_sz)
{
    struct timespec ts;
    long value;

    if (!out || out_sz == 0)
        return;

    memset(&ts, 0, sizeof(ts));
    clock_gettime(CLOCK_REALTIME, &ts);
    value = (long)(ts.tv_sec % 1000000L) * 1000L + (ts.tv_nsec / 1000000L);
    snprintf(out, out_sz, "C%ld", value);
}

static int bt_call_set_nonblocking(int fd)
{
    int flags;
    flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0)
        return -1;
    if (fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0)
        return -1;
    return 0;
}

static int bt_call_wait_writable(int fd, int timeout_ms)
{
    struct pollfd pfd;
    int rc;

    memset(&pfd, 0, sizeof(pfd));
    pfd.fd = fd;
    pfd.events = POLLOUT;

    rc = poll(&pfd, 1, timeout_ms);
    if (rc <= 0)
        return rc;
    if (pfd.revents & (POLLERR | POLLHUP | POLLNVAL))
        return -1;
    return (pfd.revents & POLLOUT) ? 1 : -1;
}

static int bt_call_precheck(bt_call_session_t *session, const char *mac)
{
    bt_device_t *dev;
    int i;

    if (!session || !session->ctx || !mac || !mac[0])
        return BT_STATUS_PROTOCOL;

    dev = bt_context_find_by_mac(session->ctx, mac);
    if (!dev)
        return BT_STATUS_NOT_FOUND;

    if (!dev->paired)
        return BT_STATUS_NOT_PAIRED;

    if (!dev->connected)
        return BT_STATUS_REMOTE;

    for (i = 0; i < session->ctx->count; ++i) {
        bt_device_t *cur = &session->ctx->devices[i];
        if (!cur->used)
            continue;
        if (cur->call_state == BT_CALL_STATE_ACTIVE ||
            cur->call_state == BT_CALL_STATE_CTRL_READY ||
            cur->call_state == BT_CALL_STATE_AUDIO_READY) {
            if (strcmp(cur->mac, mac) != 0)
                return BT_STATUS_ALREADY;
        }
    }

    session->dev = dev;
    session->dev->call_selected = 1;
    session->dev->call_state = BT_CALL_STATE_PRECHECKING;
    session->result.precheck_ok = 1;
    bt_logf("call", BT_LOG_DONE, "precheck passed mac=%s paired=%d connected=%d", dev->mac, dev->paired, dev->connected);
    return BT_STATUS_OK;
}

static int bt_call_open_control(bt_call_session_t *session)
{
    struct sockaddr_rc remote;
    bdaddr_t target;
    int fd;
    int rc;

    if (!session || !session->dev)
        return -1;

    session->dev->call_state = BT_CALL_STATE_CTRL_CONNECTING;
    bt_logf("call", BT_LOG_STARTED, "opening RFCOMM control mac=%s channel=%u", session->dev->mac, session->options.rfcomm_channel);

    if (bt_str2ba(session->dev->mac, &target) < 0) {
        bt_call_fail(session, BT_STATUS_PROTOCOL, BT_CALL_STATE_FAILED,
                     "invalid MAC for control channel");
        return -1;
    }

    fd = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);
    if (fd < 0) {
        bt_call_fail(session, BT_STATUS_FAIL, BT_CALL_STATE_FAILED,
                     "failed to create RFCOMM control socket");
        return -1;
    }

    if (bt_call_set_nonblocking(fd) < 0) {
        close(fd);
        bt_call_fail(session, BT_STATUS_FAIL, BT_CALL_STATE_FAILED,
                     "failed to set RFCOMM control socket nonblocking");
        return -1;
    }

    memset(&remote, 0, sizeof(remote));
    remote.rc_family = AF_BLUETOOTH;
    remote.rc_channel = session->options.rfcomm_channel;
    bt_bacpy(&remote.rc_bdaddr, &target);

    rc = connect(fd, (struct sockaddr *)&remote, sizeof(remote));
    if (rc < 0 && errno != EINPROGRESS) {
        close(fd);
        bt_call_fail(session, BT_STATUS_REMOTE, BT_CALL_STATE_FAILED,
                     "RFCOMM control connect failed immediately");
        return -1;
    }

    rc = bt_call_wait_writable(fd, session->options.control_timeout_ms);
    if (rc <= 0) {
        close(fd);
        bt_call_fail(session,
                     rc == 0 ? BT_STATUS_TIMEOUT : BT_STATUS_REMOTE,
                     BT_CALL_STATE_FAILED,
                     rc == 0 ? "RFCOMM control connect timed out" : "RFCOMM control socket did not become writable");
        return -1;
    }

    {
        int so_error = 0;
        socklen_t so_len = sizeof(so_error);
        if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &so_error, &so_len) < 0 || so_error != 0) {
            close(fd);
            bt_call_fail(session, BT_STATUS_REMOTE, BT_CALL_STATE_FAILED,
                         "RFCOMM control socket reported SO_ERROR");
            return -1;
        }
    }

    session->control_fd = fd;
    bt_logf("call", BT_LOG_DONE, "RFCOMM control connected");
    session->dev->rfcomm_connected = 1;
    session->dev->call_state = BT_CALL_STATE_CTRL_READY;
    session->result.control_connected = 1;
    return 0;
}

static int bt_call_send_control_line(bt_call_session_t *session, const char *line)
{
    size_t len;
    ssize_t written;

    if (!session || session->control_fd < 0 || !line)
        return -1;

    len = strlen(line);
    written = write(session->control_fd, line, len);
    if (written < 0)
        return -1;
    return (written == (ssize_t)len) ? 0 : -1;
}

static int bt_call_wait_control_reply(bt_call_session_t *session,
                                      int timeout_ms,
                                      const char *expect_prefix,
                                      char *reply,
                                      size_t reply_sz)
{
    struct pollfd pfd;
    char buf[BT_CALL_CONTROL_BUF];
    int rc;
    ssize_t n;

    if (!session || session->control_fd < 0)
        return -1;

    memset(&pfd, 0, sizeof(pfd));
    pfd.fd = session->control_fd;
    pfd.events = POLLIN;

    rc = poll(&pfd, 1, timeout_ms);
    if (rc <= 0)
        return rc;

    if (pfd.revents & (POLLERR | POLLHUP | POLLNVAL))
        return -1;

    if (!(pfd.revents & POLLIN))
        return -1;

    n = read(session->control_fd, buf, sizeof(buf) - 1);
    if (n <= 0)
        return -1;

    buf[n] = '\0';
    if (reply && reply_sz > 0)
        bt_copy_string(reply, reply_sz, buf);

    if (!expect_prefix)
        return 1;

    return strncmp(buf, expect_prefix, strlen(expect_prefix)) == 0 ? 1 : -1;
}

static int bt_call_request_setup(bt_call_session_t *session)
{
    char line[256];
    char reply[256];
    int rc;

    if (!session || session->control_fd < 0)
        return -1;

    session->dev->call_state = BT_CALL_STATE_SETUP_SENT;
    snprintf(line, sizeof(line), "CALL-SETUP|%s|%s|VOICE\n",
             bt_context_get_host_id(session->ctx), session->call_id);

    if (bt_call_send_control_line(session, line) < 0) {
        bt_call_fail(session, BT_STATUS_REMOTE, BT_CALL_STATE_FAILED,
                     "failed to send CALL-SETUP over control channel");
        return -1;
    }

    session->dev->call_state = BT_CALL_STATE_WAIT_ACCEPT;
    rc = bt_call_wait_control_reply(session, session->options.control_timeout_ms,
                                    NULL, reply, sizeof(reply));
    if (rc == 0) {
        bt_call_fail(session, BT_STATUS_TIMEOUT, BT_CALL_STATE_FAILED,
                     "timed out waiting for CALL-ACCEPT/CALL-REJECT");
        return -1;
    }
    if (rc < 0) {
        bt_call_fail(session, BT_STATUS_REMOTE, BT_CALL_STATE_FAILED,
                     "invalid or unreadable control reply during call setup");
        return -1;
    }

    if (strncmp(reply, "CALL-ACCEPT|", 12) == 0) {
        session->result.setup_accepted = 1;
        return 0;
    }

    if (strncmp(reply, "CALL-REJECT|", 12) == 0) {
        bt_call_fail(session, BT_STATUS_REMOTE, BT_CALL_STATE_FAILED,
                     "peer rejected the call setup request");
        return -1;
    }

    bt_call_fail(session, BT_STATUS_PROTOCOL, BT_CALL_STATE_FAILED,
                 "unexpected control reply while waiting for call setup response");
    return -1;
}

static int bt_call_open_sco(bt_call_session_t *session)
{
    struct sockaddr_sco remote;
    bdaddr_t target;
    int fd;
    int rc;

    if (!session || !session->dev)
        return -1;

    if (bt_str2ba(session->dev->mac, &target) < 0) {
        bt_call_fail(session, BT_STATUS_PROTOCOL, BT_CALL_STATE_FAILED,
                     "invalid MAC for SCO socket");
        return -1;
    }

    session->dev->call_state = BT_CALL_STATE_AUDIO_CONNECTING;

    fd = socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_SCO);
    if (fd < 0) {
        bt_call_fail(session, BT_STATUS_FAIL, BT_CALL_STATE_FAILED,
                     "failed to create SCO audio socket");
        return -1;
    }

    if (bt_call_set_nonblocking(fd) < 0) {
        close(fd);
        bt_call_fail(session, BT_STATUS_FAIL, BT_CALL_STATE_FAILED,
                     "failed to set SCO socket nonblocking");
        return -1;
    }

    memset(&remote, 0, sizeof(remote));
    remote.sco_family = AF_BLUETOOTH;
    bt_bacpy(&remote.sco_bdaddr, &target);

    rc = connect(fd, (struct sockaddr *)&remote, sizeof(remote));
    if (rc < 0 && errno != EINPROGRESS) {
        close(fd);
        bt_call_fail(session, BT_STATUS_REMOTE, BT_CALL_STATE_FAILED,
                     "SCO audio connect failed immediately");
        return -1;
    }

    rc = bt_call_wait_writable(fd, session->options.sco_timeout_ms);
    if (rc <= 0) {
        close(fd);
        bt_call_fail(session,
                     rc == 0 ? BT_STATUS_TIMEOUT : BT_STATUS_REMOTE,
                     BT_CALL_STATE_FAILED,
                     rc == 0 ? "SCO audio connect timed out" : "SCO audio socket did not become writable");
        return -1;
    }

    {
        int so_error = 0;
        socklen_t so_len = sizeof(so_error);
        if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &so_error, &so_len) < 0 || so_error != 0) {
            close(fd);
            bt_call_fail(session, BT_STATUS_REMOTE, BT_CALL_STATE_FAILED,
                         "SCO audio socket reported SO_ERROR");
            return -1;
        }
    }

    session->sco_fd = fd;
    session->dev->sco_connected = 1;
    session->dev->call_state = BT_CALL_STATE_AUDIO_READY;
    session->result.sco_connected = 1;
    return 0;
}

static int bt_call_verify_audio(bt_call_session_t *session)
{
    int rc;
    char reply[256];

    if (!session || session->control_fd < 0 || session->sco_fd < 0)
        return -1;

    /*
     * Audio verification is split into two checks:
     * 1) a control-plane readiness confirmation from the peer
     * 2) a local write probe on the SCO socket
     *
     * The first check tells us that the peer application is logically ready.
     * The second check tells us that the local kernel socket path accepts audio
     * frames. Both are valuable because either side can be the one that is not
     * ready even when socket connect() already succeeded.
     */
    if (session->options.require_audio_ready_ack) {
        char line[128];
        snprintf(line, sizeof(line), "AUDIO-CHECK|%s\n", session->call_id);
        if (bt_call_send_control_line(session, line) < 0) {
            bt_call_fail(session, BT_STATUS_REMOTE, BT_CALL_STATE_FAILED,
                         "failed to send AUDIO-CHECK over control channel");
            return -1;
        }

        rc = bt_call_wait_control_reply(session, session->options.control_timeout_ms,
                                        NULL, reply, sizeof(reply));
        if (rc == 0) {
            bt_call_fail(session, BT_STATUS_TIMEOUT, BT_CALL_STATE_FAILED,
                         "timed out waiting for AUDIO-READY");
            return -1;
        }
        if (rc < 0 || strncmp(reply, "AUDIO-READY|", 12) != 0) {
            bt_call_fail(session, BT_STATUS_PROTOCOL, BT_CALL_STATE_FAILED,
                         "peer did not acknowledge audio readiness");
            return -1;
        }
    }

    if (session->options.require_sco_write_probe) {
        unsigned char silence[48];
        ssize_t written;
        memset(silence, 0, sizeof(silence));
        written = write(session->sco_fd, silence, sizeof(silence));
        if (written < 0 && errno != EAGAIN && errno != EWOULDBLOCK) {
            bt_call_fail(session, BT_STATUS_REMOTE, BT_CALL_STATE_FAILED,
                         "local SCO write probe failed");
            return -1;
        }
    }

    session->dev->audio_verified = 1;
    session->result.audio_verified = 1;
    return 0;
}

static void bt_call_send_end(bt_call_session_t *session, const char *reason)
{
    char line[256];

    if (!session || session->control_fd < 0)
        return;

    snprintf(line, sizeof(line), "CALL-END|%s|%s\n",
             session->call_id,
             reason ? reason : "normal");
    (void)bt_call_send_control_line(session, line);
}

static int bt_call_monitor(bt_call_session_t *session)
{
    int elapsed_ms = 0;

    if (!session)
        return -1;

    while (elapsed_ms < session->options.hold_seconds * 1000) {
        struct pollfd pfds[2];
        int nfds = 0;
        int rc;

        memset(pfds, 0, sizeof(pfds));

        if (session->control_fd >= 0) {
            pfds[nfds].fd = session->control_fd;
            pfds[nfds].events = POLLIN;
            ++nfds;
        }

        if (session->sco_fd >= 0) {
            pfds[nfds].fd = session->sco_fd;
            pfds[nfds].events = POLLIN;
            ++nfds;
        }

        rc = poll(pfds, nfds, 500);
        if (rc < 0) {
            bt_call_fail(session, BT_STATUS_FAIL, BT_CALL_STATE_FAILED,
                         "poll failed while monitoring active call");
            return -1;
        }

        if (rc > 0) {
            int idx = 0;
            if (session->control_fd >= 0) {
                if (pfds[idx].revents & (POLLERR | POLLHUP | POLLNVAL)) {
                    bt_call_fail(session, BT_STATUS_REMOTE, BT_CALL_STATE_FAILED,
                                 "control channel dropped during active call");
                    return -1;
                }
                if (pfds[idx].revents & POLLIN) {
                    char reply[256];
                    int rr = bt_call_wait_control_reply(session, 1, NULL, reply, sizeof(reply));
                    if (rr > 0 && strncmp(reply, "CALL-END|", 9) == 0) {
                        bt_call_fail(session, BT_STATUS_REMOTE, BT_CALL_STATE_ENDING,
                                     "peer ended the call");
                        return -1;
                    }
                }
                ++idx;
            }
            if (session->sco_fd >= 0) {
                if (pfds[idx].revents & (POLLERR | POLLHUP | POLLNVAL)) {
                    bt_call_fail(session, BT_STATUS_REMOTE, BT_CALL_STATE_FAILED,
                                 "SCO audio link dropped during active call");
                    return -1;
                }
            }
        }

        elapsed_ms += 500;
    }

    return 0;
}

static void bt_call_cleanup(bt_call_session_t *session, int ended_cleanly)
{
    if (!session)
        return;

    if (session->dev)
        session->dev->call_state = BT_CALL_STATE_ENDING;

    bt_call_send_end(session, ended_cleanly ? "normal" : "failure");

    if (session->sco_fd >= 0) {
        close(session->sco_fd);
        session->sco_fd = -1;
    }
    if (session->control_fd >= 0) {
        close(session->control_fd);
        session->control_fd = -1;
    }

    if (session->dev) {
        session->dev->rfcomm_connected = 0;
        session->dev->sco_connected = 0;
        session->dev->audio_verified = 0;
        session->dev->call_selected = 0;
        session->dev->call_state = BT_CALL_STATE_IDLE;
    }

    session->result.ended_cleanly = ended_cleanly ? 1 : 0;
}

bt_call_result_t bt_call_start(bt_context_t *ctx, int adapter_index,
                               const char *mac,
                               const bt_call_options_t *options)
{
    bt_call_session_t session;

    memset(&session, 0, sizeof(session));
    session.ctx = ctx;
    session.adapter_index = adapter_index;
    session.control_fd = -1;
    session.sco_fd = -1;
    bt_call_result_init(&session.result);
    bt_call_build_id(session.call_id, sizeof(session.call_id));
    bt_copy_string(session.result.call_id, sizeof(session.result.call_id), session.call_id);

    if (options)
        session.options = *options;
    else
        bt_call_options_init(&session.options);

    if (bt_call_precheck(&session, mac) != BT_STATUS_OK) {
        bt_call_fail(&session, BT_STATUS_FAIL, BT_CALL_STATE_FAILED,
                     "precheck failed: device must exist, be paired, and be connected");
        bt_call_cleanup(&session, 0);
        return session.result;
    }

    if (bt_call_open_control(&session) < 0) {
        bt_call_cleanup(&session, 0);
        return session.result;
    }

    if (bt_call_request_setup(&session) < 0) {
        bt_call_cleanup(&session, 0);
        return session.result;
    }

    if (bt_call_open_sco(&session) < 0) {
        bt_call_cleanup(&session, 0);
        return session.result;
    }

    if (bt_call_verify_audio(&session) < 0) {
        bt_call_cleanup(&session, 0);
        return session.result;
    }

    session.dev->call_state = BT_CALL_STATE_ACTIVE;
    session.result.call_active = 1;
    bt_copy_string(session.result.detail, sizeof(session.result.detail),
                   "call is active and being monitored");

    if (bt_call_monitor(&session) < 0) {
        bt_call_cleanup(&session, 0);
        return session.result;
    }

    session.result.status = BT_STATUS_OK;
    bt_copy_string(session.result.detail, sizeof(session.result.detail),
                   "call completed and cleaned up normally");
    bt_call_cleanup(&session, 1);
    return session.result;
}
