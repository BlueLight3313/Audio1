#ifndef BT_UTIL_H
#define BT_UTIL_H

#include "bt_platform.h"
#include "bt_types.h"

uint16_t bt_cpu_to_le16(uint16_t value);
uint16_t bt_le16_to_cpu(uint16_t value);
void bt_format_bdaddr(const struct bt_bdaddr *addr, char *out, size_t out_size);
const char *bt_scan_enable_to_string(uint8_t value);
void bt_format_flags(uint32_t flags, char *out, size_t out_size);

#endif
