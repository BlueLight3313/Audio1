#ifndef BT_COMPAT_L2CAP_H
#define BT_COMPAT_L2CAP_H

#include <stdint.h>
#include <sys/socket.h>
#include "bluetooth.h"

struct sockaddr_l2 {
    sa_family_t l2_family;
    uint16_t    l2_psm;
    bdaddr_t    l2_bdaddr;
    uint16_t    l2_cid;
    uint8_t     l2_bdaddr_type;
};

static inline uint16_t bt_htobs(uint16_t v)
{
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    return v;
#else
    return (uint16_t)((v << 8) | (v >> 8));
#endif
}

#endif
