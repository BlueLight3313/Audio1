#include "bt_defs.h"
#include "bt_hci.h"
#include "bt_log.h"
#include "bt_util.h"

static int bt_wait_readable(int fd, int timeout_ms)
{
    fd_set readfds;
    struct timeval tv;
    int rc;

    FD_ZERO(&readfds);
    FD_SET(fd, &readfds);

    tv.tv_sec = timeout_ms / 1000;
    tv.tv_usec = (timeout_ms % 1000) * 1000;

    rc = select(fd + 1, &readfds, NULL, NULL, &tv);
    if (rc < 0) {
        return -errno;
    }
    if (rc == 0) {
        return -ETIMEDOUT;
    }
    return 0;
}

int bt_hci_open_control_socket(void)
{
    return socket(AF_BLUETOOTH, SOCK_RAW | SOCK_CLOEXEC, BTPROTO_HCI);
}

int bt_hci_open_raw_socket(uint16_t dev_id)
{
    int sock;
    struct sockaddr_hci addr;

    sock = socket(AF_BLUETOOTH, SOCK_RAW | SOCK_CLOEXEC, BTPROTO_HCI);
    if (sock < 0) {
        return -errno;
    }

    memset(&addr, 0, sizeof(addr));
    addr.hci_family = AF_BLUETOOTH;
    addr.hci_dev = dev_id;
    addr.hci_channel = HCI_CHANNEL_RAW;

    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        int saved_errno = errno;
        close(sock);
        return -saved_errno;
    }

    return sock;
}

int bt_hci_set_event_filter(int sock, uint16_t opcode)
{
    struct hci_filter filter;

    memset(&filter, 0, sizeof(filter));
    filter.type_mask = 1UL << HCI_EVENT_PKT;
    filter.event_mask[0] = (1UL << EVT_CMD_COMPLETE) | (1UL << EVT_CMD_STATUS);
    filter.opcode = bt_cpu_to_le16(opcode);

    if (setsockopt(sock, SOL_HCI, HCI_FILTER, &filter, sizeof(filter)) < 0) {
        return -errno;
    }

    return 0;
}

int bt_hci_send_cmd_sync(
    int sock,
    uint16_t opcode,
    const void *params,
    uint8_t plen,
    void *response,
    size_t response_capacity,
    size_t *response_size,
    int timeout_ms,
    uint8_t *status_out)
{
    uint8_t tx[1 + sizeof(struct hci_command_hdr) + 255];
    ssize_t written;
    int rc;
    struct hci_command_hdr *cmd_hdr;


    if (status_out != NULL) {
        *status_out = 0xff;
    }
    if (response_size != NULL) {
        *response_size = 0;
    }

    tx[0] = HCI_COMMAND_PKT;
    cmd_hdr = (struct hci_command_hdr *)(tx + 1);
    cmd_hdr->opcode = bt_cpu_to_le16(opcode);
    cmd_hdr->plen = plen;

    if (plen > 0 && params != NULL) {
        memcpy(tx + 1 + sizeof(*cmd_hdr), params, plen);
    }

    written = write(sock, tx, 1 + sizeof(*cmd_hdr) + plen);
    if (written < 0) {
        return -errno;
    }

    for (;;) {
        uint8_t rx[BT_MAX_HCI_FRAME + 1];
        ssize_t nread;
        uint8_t pkt_type;
        struct hci_event_hdr *evt_hdr;
        const uint8_t *evt_payload;

        rc = bt_wait_readable(sock, timeout_ms);
        if (rc < 0) {
            return rc;
        }

        nread = read(sock, rx, sizeof(rx));
        if (nread < 0) {
            if (errno == EINTR) {
                continue;
            }
            return -errno;
        }
        if (nread < 1 + (ssize_t)sizeof(struct hci_event_hdr)) {
            continue;
        }

        pkt_type = rx[0];
        if (pkt_type != HCI_EVENT_PKT) {
            continue;
        }

        evt_hdr = (struct hci_event_hdr *)(rx + 1);
        evt_payload = rx + 1 + sizeof(*evt_hdr);

        if (evt_hdr->evt == EVT_CMD_STATUS) {
            const struct bt_hci_cmd_status *st;
            if (evt_hdr->plen < sizeof(*st)) {
                continue;
            }
            st = (const struct bt_hci_cmd_status *)evt_payload;
            if (bt_le16_to_cpu(st->opcode) != opcode) {
                continue;
            }
            if (status_out != NULL) {
                *status_out = st->status;
            }
            return st->status == 0x00 ? 0 : -EIO;
        }

        if (evt_hdr->evt == EVT_CMD_COMPLETE) {
            const struct bt_hci_cmd_complete *cc;
            const uint8_t *ret_params;
            size_t ret_len;

            if (evt_hdr->plen < sizeof(*cc)) {
                continue;
            }

            cc = (const struct bt_hci_cmd_complete *)evt_payload;
            if (bt_le16_to_cpu(cc->opcode) != opcode) {
                continue;
            }

            ret_params = cc->params;
            ret_len = evt_hdr->plen - sizeof(*cc);

            if (ret_len > 0 && status_out != NULL) {
                *status_out = ret_params[0];
            }

            if (response != NULL && response_capacity > 0 && ret_len > 0) {
                size_t to_copy = ret_len < response_capacity ? ret_len : response_capacity;
                memcpy(response, ret_params, to_copy);
                if (response_size != NULL) {
                    *response_size = to_copy;
                }
            }

            if (ret_len > 0 && ret_params[0] != 0x00) {
                return -EIO;
            }
            return 0;
        }
    }
}
