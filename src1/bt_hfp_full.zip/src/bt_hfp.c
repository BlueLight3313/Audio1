
#include <stdio.h>
#include <string.h>
#include "bt_hfp.h"
#include "bt_rfcomm.h"

static int g_fd = -1;

int bt_hfp_init(int rfcomm_fd){
    g_fd = rfcomm_fd;

    bt_rfcomm_send(g_fd, "AT+BRSF=20\r");
    bt_rfcomm_send(g_fd, "AT+CIND=?\r");
    bt_rfcomm_send(g_fd, "AT+CMER=3,0,0,1\r");

    return 0;
}

void bt_hfp_handle(){
    char buf[256];
    int n = bt_rfcomm_recv(g_fd, buf, sizeof(buf));
    if(n > 0){
        buf[n] = 0;
        printf("[HFP RECV] %s\n", buf);
    }
}

void bt_hfp_dial(const char *number){
    char cmd[128];
    sprintf(cmd, "ATD%s;\r", number);
    bt_rfcomm_send(g_fd, cmd);
}

void bt_hfp_answer(){
    bt_rfcomm_send(g_fd, "ATA\r");
}

void bt_hfp_hangup(){
    bt_rfcomm_send(g_fd, "AT+CHUP\r");
}
