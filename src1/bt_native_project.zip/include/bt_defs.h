
#ifndef BT_DEFS_H
#define BT_DEFS_H

#define AF_BLUETOOTH 31
#define BTPROTO_HCI 1
#define HCI_CHANNEL_RAW 0

#define SCAN_DISABLED 0x00
#define SCAN_INQUIRY  0x01
#define SCAN_PAGE     0x02
#define SCAN_BOTH     0x03

#define HCI_OPCODE(ogf, ocf) ((ocf & 0x03ff) | (ogf << 10))

#endif
