
#include <sys/socket.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include "bt_defs.h"

struct sockaddr_sco {
    unsigned short sco_family;
    unsigned char sco_bdaddr[6];
};

int bt_sco_connect(unsigned char *mac){
    int s = socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_SCO);

    struct sockaddr_sco addr;
    memset(&addr,0,sizeof(addr));
    addr.sco_family = AF_BLUETOOTH;
    memcpy(addr.sco_bdaddr, mac, 6);

    if(connect(s,(struct sockaddr*)&addr,sizeof(addr))<0){
        perror("SCO connect");
        return -1;
    }
    return s;
}
