
#ifndef BT_DEFS_H
#define BT_DEFS_H

#define AF_BLUETOOTH 31
#define BTPROTO_RFCOMM 3
#define BTPROTO_SCO 2
#define BTPROTO_L2CAP 0

#endif
