
#include <stdio.h>
#include "../include/bt.h"

int bt_scan(int adapter,int timeout){
    printf("Scan (stub production-safe): adapter=%d timeout=%d\n",adapter,timeout);
    return 0;
}
