
#include <stdio.h>
#include <string.h>
#include "bt_device.h"

void bt_fake_scan();

int main()
{
    char cmd[64];

    while(1){
        printf("bt> ");
        fgets(cmd,64,stdin);

        if(strncmp(cmd,"scan",4)==0){
            bt_fake_scan();
        }
        else if(strncmp(cmd,"devices",7)==0){
            bt_dev_print_all();
        }
        else if(strncmp(cmd,"quit",4)==0){
            break;
        }
    }
    return 0;
}
