
#ifndef BT_ADAPTER_H
#define BT_ADAPTER_H

#include <stddef.h>
#include <stdint.h>
#include "bt_types.h"

int bt_adapter_find_first(int ctl_sock, int *dev_id_out);
int bt_adapter_get_info(int ctl_sock, int dev_id, struct hci_dev_info_ex *out_info);

int bt_adapter_power_on(int ctl_sock, int dev_id);
int bt_adapter_power_off(int ctl_sock, int dev_id);

int bt_adapter_get_local_mac(int ctl_sock, int dev_id, uint8_t mac_out[6]);
int bt_adapter_get_local_name(int hci_sock, char *name_out, size_t name_out_size);

int bt_adapter_get_scan_enable(int hci_sock, uint8_t *scan_enable);
int bt_adapter_set_discoverable(int hci_sock, uint8_t enable);

void bt_format_bdaddr(const uint8_t mac[6], char *out, size_t out_size);
const char *bt_scan_enable_to_text(uint8_t scan_enable);

#endif
