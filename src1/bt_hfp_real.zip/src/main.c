
#include <stdio.h>

int bt_rfcomm_connect(const char*);
int bt_sco_connect(const char*);
int bt_audio_start(int);

int main(){
    const char *mac="00:11:22:33:44:55";

    int rf=bt_rfcomm_connect(mac);
    printf("RFCOMM connected\n");

    int sco=bt_sco_connect(mac);
    printf("SCO connected\n");

    bt_audio_start(sco);

    getchar();
    return 0;
}
