
#include <sys/socket.h>
#include <unistd.h>
#include <stdio.h>

#define AF_BLUETOOTH 31
#define BTPROTO_SCO 2

struct sockaddr_sco {
    unsigned short sco_family;
    unsigned char sco_bdaddr[6];
};

static void str2ba(const char *str, unsigned char *ba){
    int b[6];
    sscanf(str,"%x:%x:%x:%x:%x:%x",&b[5],&b[4],&b[3],&b[2],&b[1],&b[0]);
    for(int i=0;i<6;i++) ba[i]=b[i];
}

int bt_sco_connect(const char *mac){
    int s=socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_SCO);

    struct sockaddr_sco addr={0};
    addr.sco_family=AF_BLUETOOTH;
    str2ba(mac, addr.sco_bdaddr);

    if(connect(s,(struct sockaddr*)&addr,sizeof(addr))<0){
        perror("SCO connect");
        return -1;
    }
    return s;
}
