#ifndef BT_MGMT_H
#define BT_MGMT_H

#include <stdint.h>
#include "../compat/bluetooth/bluetooth.h"

#define MGMT_INDEX_NONE 0xFFFF

/* Commands */
#define MGMT_OP_READ_INDEX_LIST            0x0003
#define MGMT_OP_DISCONNECT                 0x0014
#define MGMT_OP_GET_CONNECTIONS            0x0015
#define MGMT_OP_PIN_CODE_REPLY            0x0016
#define MGMT_OP_PIN_CODE_NEG_REPLY        0x0017
#define MGMT_OP_PAIR_DEVICE               0x0019
#define MGMT_OP_CANCEL_PAIR_DEVICE        0x001A
#define MGMT_OP_USER_CONFIRM_REPLY        0x001C
#define MGMT_OP_USER_CONFIRM_NEG_REPLY    0x001D
#define MGMT_OP_USER_PASSKEY_REPLY        0x001E
#define MGMT_OP_USER_PASSKEY_NEG_REPLY    0x001F
#define MGMT_OP_START_DISCOVERY           0x0023
#define MGMT_OP_STOP_DISCOVERY            0x0024
#define MGMT_OP_CONFIRM_NAME              0x0025

/* Events */
#define MGMT_EV_CMD_COMPLETE              0x0001
#define MGMT_EV_CMD_STATUS                0x0002
#define MGMT_EV_DEVICE_CONNECTED          0x000B
#define MGMT_EV_DEVICE_DISCONNECTED       0x000C
#define MGMT_EV_CONNECT_FAILED            0x000D
#define MGMT_EV_PIN_CODE_REQUEST          0x000E
#define MGMT_EV_USER_CONFIRM_REQUEST      0x000F
#define MGMT_EV_USER_PASSKEY_REQUEST      0x0010
#define MGMT_EV_AUTH_FAILED               0x0011
#define MGMT_EV_DEVICE_FOUND              0x0012
#define MGMT_EV_DISCOVERING               0x0013
#define MGMT_EV_NEW_LINK_KEY              0x0009

/* Address types */
#define MGMT_ADDR_BREDR  0x00
#define MGMT_ADDR_LE_PUBLIC 0x01
#define MGMT_ADDR_LE_RANDOM 0x02

/* Discovery type bitmask */
#define MGMT_DISCOV_TYPE_BREDR 0x01

/* IO capability values */
#define MGMT_IO_CAP_DISPLAY_ONLY      0x00
#define MGMT_IO_CAP_DISPLAY_YES_NO    0x01
#define MGMT_IO_CAP_KEYBOARD_ONLY     0x02
#define MGMT_IO_CAP_NO_INPUT_NO_OUTPUT 0x03
#define MGMT_IO_CAP_KEYBOARD_DISPLAY  0x04

/* Status codes */
#define MGMT_STATUS_SUCCESS             0x00
#define MGMT_STATUS_UNKNOWN_COMMAND     0x01
#define MGMT_STATUS_NOT_CONNECTED       0x02
#define MGMT_STATUS_FAILED              0x03
#define MGMT_STATUS_CONNECT_FAILED      0x04
#define MGMT_STATUS_AUTH_FAILED         0x05
#define MGMT_STATUS_NOT_PAIRED          0x06
#define MGMT_STATUS_NO_RESOURCES        0x07
#define MGMT_STATUS_TIMEOUT             0x08
#define MGMT_STATUS_ALREADY_CONNECTED   0x09
#define MGMT_STATUS_BUSY                0x0A
#define MGMT_STATUS_REJECTED            0x0B
#define MGMT_STATUS_NOT_SUPPORTED       0x0C
#define MGMT_STATUS_INVALID_PARAMS      0x0D
#define MGMT_STATUS_DISCONNECTED        0x0E
#define MGMT_STATUS_NOT_POWERED         0x0F
#define MGMT_STATUS_CANCELLED           0x10
#define MGMT_STATUS_INVALID_INDEX       0x11
#define MGMT_STATUS_RFKILLED            0x12
#define MGMT_STATUS_ALREADY_PAIRED      0x13
#define MGMT_STATUS_PERMISSION_DENIED   0x14

struct mgmt_hdr {
    uint16_t opcode;
    uint16_t index;
    uint16_t len;
} __attribute__((packed));

struct mgmt_ev_cmd_complete {
    uint16_t opcode;
    uint8_t status;
    uint8_t data[0];
} __attribute__((packed));

struct mgmt_ev_cmd_status {
    uint16_t opcode;
    uint8_t status;
} __attribute__((packed));

struct mgmt_rp_read_index_list {
    uint16_t num_controllers;
    uint16_t index[0];
} __attribute__((packed));

struct mgmt_cp_start_discovery {
    uint8_t type;
} __attribute__((packed));

struct mgmt_cp_stop_discovery {
    uint8_t type;
} __attribute__((packed));

struct mgmt_cp_confirm_name {
    bdaddr_t addr;
    uint8_t addr_type;
    uint8_t name_known;
} __attribute__((packed));

struct mgmt_ev_device_found {
    bdaddr_t addr;
    uint8_t addr_type;
    int8_t rssi;
    uint32_t flags;
    uint16_t eir_len;
    uint8_t eir[0];
} __attribute__((packed));

struct mgmt_ev_discovering {
    uint8_t type;
    uint8_t discovering;
} __attribute__((packed));

struct mgmt_cp_pair_device {
    bdaddr_t addr;
    uint8_t addr_type;
    uint8_t io_cap;
} __attribute__((packed));

struct mgmt_addr_info {
    bdaddr_t addr;
    uint8_t addr_type;
} __attribute__((packed));

struct mgmt_rp_get_connections {
    uint16_t conn_count;
    uint8_t entries[0];
} __attribute__((packed));

struct mgmt_ev_pin_code_request {
    bdaddr_t addr;
    uint8_t addr_type;
    uint8_t secure;
} __attribute__((packed));

struct mgmt_cp_pin_code_reply {
    bdaddr_t addr;
    uint8_t addr_type;
    uint8_t pin_len;
    uint8_t pin_code[16];
} __attribute__((packed));

struct mgmt_cp_pin_code_neg_reply {
    bdaddr_t addr;
    uint8_t addr_type;
} __attribute__((packed));

struct mgmt_ev_user_confirm_request {
    bdaddr_t addr;
    uint8_t addr_type;
    uint32_t value;
    uint8_t confirm_hint;
} __attribute__((packed));

struct mgmt_cp_user_confirm_reply {
    bdaddr_t addr;
    uint8_t addr_type;
} __attribute__((packed));

struct mgmt_cp_user_confirm_neg_reply {
    bdaddr_t addr;
    uint8_t addr_type;
} __attribute__((packed));

struct mgmt_ev_user_passkey_request {
    bdaddr_t addr;
    uint8_t addr_type;
} __attribute__((packed));

struct mgmt_cp_user_passkey_reply {
    bdaddr_t addr;
    uint8_t addr_type;
    uint32_t passkey;
} __attribute__((packed));

struct mgmt_cp_user_passkey_neg_reply {
    bdaddr_t addr;
    uint8_t addr_type;
} __attribute__((packed));

struct mgmt_ev_auth_failed {
    bdaddr_t addr;
    uint8_t addr_type;
    uint8_t status;
} __attribute__((packed));

struct mgmt_ev_new_link_key {
    uint8_t store_hint;
    bdaddr_t addr;
    uint8_t type;
    uint8_t val[16];
    uint8_t pin_len;
} __attribute__((packed));

struct mgmt_ev_device_connected {
    bdaddr_t addr;
    uint8_t addr_type;
    uint32_t flags;
    uint16_t eir_len;
    uint8_t eir[0];
} __attribute__((packed));

struct mgmt_ev_connect_failed {
    bdaddr_t addr;
    uint8_t addr_type;
    uint8_t status;
} __attribute__((packed));

#endif
