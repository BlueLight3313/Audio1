
#include <sys/socket.h>
#include <unistd.h>
#include <stdio.h>

#define AF_BLUETOOTH 31
#define BTPROTO_RFCOMM 3

struct sockaddr_rc {
    unsigned short rc_family;
    unsigned char rc_bdaddr[6];
    unsigned char rc_channel;
};

int bt_rfcomm_server_start(uint8_t *channel_out){
    int s=socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);

    struct sockaddr_rc addr={0};
    addr.rc_family=AF_BLUETOOTH;
    addr.rc_channel=3; // example dynamic

    bind(s,(struct sockaddr*)&addr,sizeof(addr));
    listen(s,1);

    *channel_out=addr.rc_channel;
    printf("RFCOMM server on channel %d\n", addr.rc_channel);
    return s;
}

int bt_rfcomm_accept(int server_fd){
    return accept(server_fd,NULL,NULL);
}
