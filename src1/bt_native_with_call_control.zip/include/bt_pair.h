
#ifndef BT_PAIR_H
#define BT_PAIR_H

#include <stddef.h>
#include <stdint.h>
#include "bt_types.h"
#include "bt_device.h"

typedef enum {
    BT_PAIR_PROFILE_AUDIO_ONLY = 1,
    BT_PAIR_PROFILE_SMART_HEADSET = 2,
    BT_PAIR_PROFILE_SMARTPHONE = 3
} bt_pair_profile_t;

struct bt_bond_record {
    bt_bdaddr_t bdaddr;
    char address_text[18];
    char name[249];
    uint8_t link_key[16];
    uint8_t link_key_type;
    uint8_t has_name;
    uint8_t has_link_key;
};

void bt_bond_cache_clear(void);
size_t bt_bond_cache_count(void);
const struct bt_bond_record *bt_bond_cache_get_const(size_t index);
const struct bt_bond_record *bt_bond_cache_find(const bt_bdaddr_t *bdaddr);
void bt_bond_cache_print(void);

int bt_pair_enable_secure_simple_pairing(int hci_sock, uint8_t enable);
int bt_pair_device(
    int hci_sock,
    const struct bt_device_record *device,
    bt_pair_profile_t profile,
    const char *pin_code
);

#endif
