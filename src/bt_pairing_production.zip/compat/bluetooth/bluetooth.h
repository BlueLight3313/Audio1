#ifndef BT_COMPAT_BLUETOOTH_H
#define BT_COMPAT_BLUETOOTH_H

#include <stdint.h>
#include <sys/socket.h>

#ifndef AF_BLUETOOTH
#define AF_BLUETOOTH 31
#endif
#ifndef PF_BLUETOOTH
#define PF_BLUETOOTH AF_BLUETOOTH
#endif
#ifndef BTPROTO_HCI
#define BTPROTO_HCI 1
#endif

typedef struct {
    uint8_t b[6];
} __attribute__((packed)) bdaddr_t;

int str2ba(const char *str, bdaddr_t *ba);
void ba2str(const bdaddr_t *ba, char *str);
int bacmp(const bdaddr_t *a, const bdaddr_t *b);
void bacpy(bdaddr_t *dst, const bdaddr_t *src);

#endif
