
#include <unistd.h>
#include <stdio.h>
#include <string.h>

void bt_hfp_ag_run(int fd){
    char buf[256];

    write(fd,"+BRSF:20\r\nOK\r\n",16);

    while(1){
        int n=read(fd,buf,sizeof(buf)-1);
        if(n<=0) break;
        buf[n]=0;

        printf("HFP RX: %s\n", buf);

        if(strstr(buf,"ATA")){
            write(fd,"OK\r\n",4);
        }else if(strstr(buf,"AT+CHUP")){
            write(fd,"OK\r\n",4);
        }else if(strstr(buf,"ATD")){
            write(fd,"OK\r\n",4);
        }
    }
}
