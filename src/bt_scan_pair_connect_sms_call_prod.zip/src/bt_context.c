#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "../include/bt_context.h"

#define BT_CONTEXT_STATE_FILE "bt_runtime_state.txt"

static bt_context_t g_bt_context;

static void bt_context_trim_newline(char *s)
{
    size_t n;

    if (!s)
        return;

    n = strlen(s);
    while (n > 0 && (s[n - 1] == '\n' || s[n - 1] == '\r')) {
        s[n - 1] = '\0';
        --n;
    }
}

static void bt_context_copy_string(char *dst, size_t dst_sz, const char *src)
{
    if (!dst || dst_sz == 0)
        return;

    if (!src)
        src = "";

    snprintf(dst, dst_sz, "%s", src);
}

static int bt_context_load(bt_context_t *ctx)
{
    FILE *fp;
    char line[512];

    if (!ctx)
        return -1;

    fp = fopen(BT_CONTEXT_STATE_FILE, "r");
    if (!fp)
        return -1;

    while (fgets(line, sizeof(line), fp)) {
        char *kind;
        bt_context_trim_newline(line);
        kind = strtok(line, "|");
        if (!kind)
            continue;

        if (strcmp(kind, "HOST") == 0) {
            char *host_id = strtok(NULL, "");
            bt_context_copy_string(ctx->host_id, sizeof(ctx->host_id), host_id ? host_id : "HOST-DEVICE");
            continue;
        }

        if (strcmp(kind, "DEV") == 0) {
            char *index_s = strtok(NULL, "|");
            char *mac = strtok(NULL, "|");
            char *name = strtok(NULL, "|");
            char *paired_s = strtok(NULL, "|");
            char *connected_s = strtok(NULL, "|");
            bt_device_t *dev;
            int idx;

            if (!index_s || !mac || !name || !paired_s || !connected_s)
                continue;

            dev = bt_context_get_or_add(ctx, mac, name);
            if (!dev)
                continue;

            idx = atoi(index_s);
            if (idx >= 0)
                dev->index = idx;
            dev->paired = atoi(paired_s) ? 1 : 0;
            dev->connected = atoi(connected_s) ? 1 : 0;
        }
    }

    fclose(fp);
    return 0;
}

void bt_context_init(bt_context_t *ctx)
{
    const char *env_host_id;

    if (!ctx)
        return;

    memset(ctx, 0, sizeof(*ctx));
    env_host_id = getenv("BT_HOST_ID");
    if (env_host_id && env_host_id[0])
        bt_context_copy_string(ctx->host_id, sizeof(ctx->host_id), env_host_id);
    else
        bt_context_copy_string(ctx->host_id, sizeof(ctx->host_id), "HOST-DEVICE");
}

bt_context_t *bt_context_get_global(void)
{
    static int initialized = 0;
    if (!initialized) {
        bt_context_init(&g_bt_context);
        bt_context_load(&g_bt_context);
        initialized = 1;
    }
    return &g_bt_context;
}

bt_device_t *bt_context_find_by_mac(bt_context_t *ctx, const char *mac)
{
    int i;

    if (!ctx || !mac)
        return NULL;

    for (i = 0; i < ctx->count; ++i) {
        if (ctx->devices[i].used && strcmp(ctx->devices[i].mac, mac) == 0)
            return &ctx->devices[i];
    }

    return NULL;
}

bt_device_t *bt_context_get_or_add(bt_context_t *ctx, const char *mac, const char *name)
{
    bt_device_t *dev;
    int slot;

    if (!ctx || !mac || !mac[0])
        return NULL;

    dev = bt_context_find_by_mac(ctx, mac);
    if (dev) {
        if (name && name[0])
            bt_context_copy_string(dev->name, sizeof(dev->name), name);
        return dev;
    }

    if (ctx->count >= BT_MAX_DEVICES)
        return NULL;

    slot = ctx->count;
    memset(&ctx->devices[slot], 0, sizeof(ctx->devices[slot]));
    ctx->devices[slot].used = 1;
    ctx->devices[slot].index = slot;
    bt_context_copy_string(ctx->devices[slot].mac, sizeof(ctx->devices[slot].mac), mac);
    if (name && name[0])
        bt_context_copy_string(ctx->devices[slot].name, sizeof(ctx->devices[slot].name), name);
    else
        bt_context_copy_string(ctx->devices[slot].name, sizeof(ctx->devices[slot].name), "unknown");
    ctx->devices[slot].paired = 0;
    ctx->devices[slot].connected = 0;
    ctx->count++;
    return &ctx->devices[slot];
}

void bt_context_update_scan_result(bt_context_t *ctx, const bt_scan_result_t *scan)
{
    int i;

    if (!ctx || !scan)
        return;

    for (i = 0; i < scan->count; ++i) {
        const char *name = scan->entries[i].name[0] ? scan->entries[i].name : "unknown";
        bt_context_get_or_add(ctx, scan->entries[i].mac, name);
    }

    bt_context_save(ctx);
}

void bt_context_mark_paired(bt_context_t *ctx, const char *mac, int paired)
{
    bt_device_t *dev;
    if (!ctx || !mac)
        return;
    dev = bt_context_get_or_add(ctx, mac, NULL);
    if (!dev)
        return;
    dev->paired = paired ? 1 : 0;
    if (!dev->paired)
        dev->connected = 0;
    bt_context_save(ctx);
}

void bt_context_mark_connected(bt_context_t *ctx, const char *mac, int connected)
{
    bt_device_t *dev;
    if (!ctx || !mac)
        return;
    dev = bt_context_get_or_add(ctx, mac, NULL);
    if (!dev)
        return;
    dev->connected = connected ? 1 : 0;
    bt_context_save(ctx);
}

const char *bt_context_get_host_id(const bt_context_t *ctx)
{
    if (!ctx || !ctx->host_id[0])
        return "HOST-DEVICE";
    return ctx->host_id;
}

void bt_context_set_host_id(bt_context_t *ctx, const char *host_id)
{
    if (!ctx)
        return;

    if (host_id && host_id[0])
        bt_context_copy_string(ctx->host_id, sizeof(ctx->host_id), host_id);
    else
        bt_context_copy_string(ctx->host_id, sizeof(ctx->host_id), "HOST-DEVICE");

    bt_context_save(ctx);
}

int bt_context_save(const bt_context_t *ctx)
{
    FILE *fp;
    int i;

    if (!ctx)
        return -1;

    fp = fopen(BT_CONTEXT_STATE_FILE, "w");
    if (!fp)
        return -1;

    fprintf(fp, "HOST|%s\n", ctx->host_id[0] ? ctx->host_id : "HOST-DEVICE");
    for (i = 0; i < ctx->count; ++i) {
        const bt_device_t *dev = &ctx->devices[i];
        if (!dev->used)
            continue;
        fprintf(fp, "DEV|%d|%s|%s|%d|%d\n",
                dev->index,
                dev->mac,
                dev->name[0] ? dev->name : "unknown",
                dev->paired,
                dev->connected);
    }

    fclose(fp);
    return 0;
}

void bt_context_print(const bt_context_t *ctx)
{
    int i;

    if (!ctx) {
        printf("Device registry: unavailable\n");
        return;
    }

    printf("Host identifier: %s\n", bt_context_get_host_id(ctx));
    printf("Device registry: count=%d\n", ctx->count);
    for (i = 0; i < ctx->count; ++i) {
        const bt_device_t *dev = &ctx->devices[i];
        if (!dev->used)
            continue;

        printf("[%d] mac=%s name=%s paired=%d connected=%d\n",
               dev->index,
               dev->mac,
               dev->name[0] ? dev->name : "unknown",
               dev->paired,
               dev->connected);
    }
}
