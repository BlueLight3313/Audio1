
#include <sys/socket.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include "bt_defs.h"

struct sockaddr_rc {
    unsigned short rc_family;
    unsigned char rc_bdaddr[6];
    unsigned char rc_channel;
};

int bt_rfcomm_server_start(unsigned char *channel_out){
    int s = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);

    struct sockaddr_rc addr;
    memset(&addr,0,sizeof(addr));
    addr.rc_family = AF_BLUETOOTH;
    addr.rc_channel = 3;

    bind(s,(struct sockaddr*)&addr,sizeof(addr));
    listen(s,1);

    *channel_out = addr.rc_channel;
    return s;
}

int bt_rfcomm_accept(int s, unsigned char *out_mac){
    struct sockaddr_rc rem;
    socklen_t len = sizeof(rem);

    int c = accept(s,(struct sockaddr*)&rem,&len);

    for(int i=0;i<6;i++) out_mac[i]=rem.rc_bdaddr[i];

    return c;
}
