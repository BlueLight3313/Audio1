#ifndef BT_HCI_H
#define BT_HCI_H

#include "bt_platform.h"
#include "bt_types.h"

int bt_hci_open_control_socket(void);
int bt_hci_open_raw_socket(uint16_t dev_id);
int bt_hci_set_event_filter(int sock, uint16_t opcode);
int bt_hci_send_cmd_sync(
    int sock,
    uint16_t opcode,
    const void *params,
    uint8_t plen,
    void *response,
    size_t response_capacity,
    size_t *response_size,
    int timeout_ms,
    uint8_t *status_out);

#endif
