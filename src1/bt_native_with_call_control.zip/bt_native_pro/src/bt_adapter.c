#include "bt_adapter.h"
#include "bt_defs.h"
#include "bt_hci.h"
#include "bt_log.h"
#include "bt_util.h"

static int bt_adapter_wait_flags(uint16_t dev_id, uint32_t required_mask, uint32_t forbidden_mask, int timeout_ms)
{
    int elapsed = 0;
    const int step_ms = 100;

    while (elapsed <= timeout_ms) {
        struct bt_adapter_status status;
        if (bt_adapter_get_status(dev_id, &status) == 0) {
            if ((status.flags & required_mask) == required_mask && (status.flags & forbidden_mask) == 0) {
                return 0;
            }
        }
        usleep(step_ms * 1000);
        elapsed += step_ms;
    }

    return -ETIMEDOUT;
}

int bt_adapter_list(struct bt_adapter_summary *items, size_t capacity, size_t *count_out)
{
    int sock;
    size_t alloc_count;
    size_t alloc_size;
    struct hci_dev_list_req *list;
    size_t i;

    if (count_out != NULL) {
        *count_out = 0;
    }

    alloc_count = BT_MAX_ADAPTERS;
    alloc_size = sizeof(*list) + alloc_count * sizeof(struct hci_dev_req);
    list = (struct hci_dev_list_req *)calloc(1, alloc_size);
    if (list == NULL) {
        return -ENOMEM;
    }
    list->dev_num = (uint16_t)alloc_count;

    sock = bt_hci_open_control_socket();
    if (sock < 0) {
        free(list);
        return sock;
    }

    if (ioctl(sock, HCIGETDEVLIST, list) < 0) {
        int saved_errno = errno;
        close(sock);
        free(list);
        return -saved_errno;
    }

    if (items != NULL && capacity > 0) {
        size_t to_copy = list->dev_num < capacity ? list->dev_num : capacity;
        for (i = 0; i < to_copy; ++i) {
            struct hci_dev_info info;
            memset(&info, 0, sizeof(info));
            info.dev_id = list->dev_req[i].dev_id;
            if (ioctl(sock, HCIGETDEVINFO, &info) == 0) {
                items[i].dev_id = info.dev_id;
                memcpy(items[i].name, info.name, sizeof(items[i].name));
            } else {
                items[i].dev_id = list->dev_req[i].dev_id;
                memcpy(items[i].name, "unknown", 8);
            }
        }
    }

    if (count_out != NULL) {
        *count_out = list->dev_num;
    }

    close(sock);
    free(list);
    return 0;
}

int bt_adapter_get_info(int ctl_sock, uint16_t dev_id, struct hci_dev_info *info)
{
    if (info == NULL) {
        return -EINVAL;
    }

    memset(info, 0, sizeof(*info));
    info->dev_id = dev_id;

    if (ioctl(ctl_sock, HCIGETDEVINFO, info) < 0) {
        return -errno;
    }

    return 0;
}

int bt_adapter_power_set(uint16_t dev_id, bool power_on)
{
    int sock;
    int rc;

    sock = bt_hci_open_control_socket();
    if (sock < 0) {
        return sock;
    }

    if (ioctl(sock, power_on ? HCIDEVUP : HCIDEVDOWN, dev_id) < 0) {
        if ((power_on && errno != EALREADY) || (!power_on && errno != EALREADY)) {
            rc = -errno;
            close(sock);
            return rc;
        }
    }

    close(sock);

    if (power_on) {
        return bt_adapter_wait_flags(dev_id, 1u << HCI_UP, 0, 3000);
    }
    return bt_adapter_wait_flags(dev_id, 0, 1u << HCI_UP, 3000);
}

int bt_adapter_get_status(uint16_t dev_id, struct bt_adapter_status *status)
{
    int ctl_sock;
    int raw_sock;
    struct hci_dev_info info;
    struct bt_hci_rp_read_scan_enable scan_rsp;
    struct bt_hci_rp_read_local_name name_rsp;
    struct bt_hci_rp_read_bd_addr bdaddr_rsp;
    size_t rsp_size;
    int rc;

    if (status == NULL) {
        return -EINVAL;
    }

    memset(status, 0, sizeof(*status));
    status->dev_id = dev_id;
    status->scan_enable = SCAN_DISABLED;

    ctl_sock = bt_hci_open_control_socket();
    if (ctl_sock < 0) {
        return ctl_sock;
    }

    rc = bt_adapter_get_info(ctl_sock, dev_id, &info);
    close(ctl_sock);
    if (rc < 0) {
        return rc;
    }

    memcpy(status->name, info.name, sizeof(status->name));
    memcpy(&status->bdaddr, &info.bdaddr, sizeof(status->bdaddr));
    status->flags = info.flags;

    if ((info.flags & (1u << HCI_UP)) == 0) {
        return 0;
    }

    raw_sock = bt_hci_open_raw_socket(dev_id);
    if (raw_sock < 0) {
        return raw_sock;
    }

    rc = bt_hci_set_event_filter(raw_sock, HCI_OP_READ_SCAN_ENABLE);
    if (rc == 0) {
        memset(&scan_rsp, 0, sizeof(scan_rsp));
        rsp_size = 0;
        rc = bt_hci_send_cmd_sync(raw_sock, HCI_OP_READ_SCAN_ENABLE, NULL, 0,
                                  &scan_rsp, sizeof(scan_rsp), &rsp_size, 1000, NULL);
        if (rc == 0 && rsp_size >= sizeof(scan_rsp)) {
            status->scan_enable = scan_rsp.scan_enable;
        }
    }

    rc = bt_hci_set_event_filter(raw_sock, HCI_OP_READ_LOCAL_NAME);
    if (rc == 0) {
        memset(&name_rsp, 0, sizeof(name_rsp));
        rsp_size = 0;
        rc = bt_hci_send_cmd_sync(raw_sock, HCI_OP_READ_LOCAL_NAME, NULL, 0,
                                  &name_rsp, sizeof(name_rsp), &rsp_size, 1000, NULL);
        if (rc == 0 && rsp_size >= 2) {
            size_t copy_len = rsp_size - 1;
            if (copy_len > HCI_MAX_NAME_LENGTH) {
                copy_len = HCI_MAX_NAME_LENGTH;
            }
            memcpy(status->local_name, name_rsp.name, copy_len);
            status->local_name[copy_len] = '\0';
        }
    }

    rc = bt_hci_set_event_filter(raw_sock, HCI_OP_READ_BD_ADDR);
    if (rc == 0) {
        memset(&bdaddr_rsp, 0, sizeof(bdaddr_rsp));
        rsp_size = 0;
        rc = bt_hci_send_cmd_sync(raw_sock, HCI_OP_READ_BD_ADDR, NULL, 0,
                                  &bdaddr_rsp, sizeof(bdaddr_rsp), &rsp_size, 1000, NULL);
        if (rc == 0 && rsp_size >= sizeof(bdaddr_rsp)) {
            memcpy(&status->bdaddr, &bdaddr_rsp.bdaddr, sizeof(status->bdaddr));
        }
    }

    close(raw_sock);
    return 0;
}

int bt_adapter_set_discoverable(uint16_t dev_id, bool enable)
{
    int sock;
    uint8_t mode;
    struct bt_hci_rp_read_scan_enable verify;
    size_t rsp_size;
    int rc;

    sock = bt_hci_open_raw_socket(dev_id);
    if (sock < 0) {
        return sock;
    }

    mode = enable ? SCAN_BOTH : SCAN_DISABLED;

    rc = bt_hci_set_event_filter(sock, HCI_OP_WRITE_SCAN_ENABLE);
    if (rc < 0) {
        close(sock);
        return rc;
    }

    rc = bt_hci_send_cmd_sync(sock, HCI_OP_WRITE_SCAN_ENABLE, &mode, 1,
                              NULL, 0, NULL, 1000, NULL);
    if (rc < 0) {
        close(sock);
        return rc;
    }

    rc = bt_hci_set_event_filter(sock, HCI_OP_READ_SCAN_ENABLE);
    if (rc < 0) {
        close(sock);
        return rc;
    }

    memset(&verify, 0, sizeof(verify));
    rsp_size = 0;
    rc = bt_hci_send_cmd_sync(sock, HCI_OP_READ_SCAN_ENABLE, NULL, 0,
                              &verify, sizeof(verify), &rsp_size, 1000, NULL);
    close(sock);
    if (rc < 0) {
        return rc;
    }
    if (rsp_size < sizeof(verify)) {
        return -EIO;
    }
    if (verify.scan_enable != mode) {
        return -EIO;
    }

    return 0;
}

int bt_adapter_set_local_name(uint16_t dev_id, const char *name)
{
    int sock;
    struct bt_hci_cp_write_local_name cp;
    int rc;

    if (name == NULL) {
        return -EINVAL;
    }

    memset(&cp, 0, sizeof(cp));
    strncpy((char *)cp.name, name, sizeof(cp.name) - 1);

    sock = bt_hci_open_raw_socket(dev_id);
    if (sock < 0) {
        return sock;
    }

    rc = bt_hci_set_event_filter(sock, HCI_OP_WRITE_LOCAL_NAME);
    if (rc < 0) {
        close(sock);
        return rc;
    }

    rc = bt_hci_send_cmd_sync(sock, HCI_OP_WRITE_LOCAL_NAME, &cp, sizeof(cp),
                              NULL, 0, NULL, 1000, NULL);
    close(sock);
    return rc;
}
