
#ifndef BT_HCI_H
#define BT_HCI_H

#include <stddef.h>
#include <stdint.h>

int bt_hci_open_raw(void);
int bt_hci_bind_raw(int sock, int dev_id);
int bt_hci_open_bound_raw(int dev_id);

int bt_hci_send_req(
    int hci_sock,
    uint16_t opcode,
    const void *cmd_params,
    uint8_t cmd_params_len,
    void *rsp_buf,
    size_t rsp_buf_size,
    int timeout_ms
);

#endif
