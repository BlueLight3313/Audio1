#ifndef BT_CONNECT_H
#define BT_CONNECT_H

#include "bt_device.h"

int bt_connect_device(int hci_sock, const struct bt_device_record *device);

#endif
