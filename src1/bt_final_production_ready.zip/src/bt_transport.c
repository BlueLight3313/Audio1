
#include <sys/socket.h>
#include <unistd.h>
#include <string.h>
#include "bt_sock.h"

static int sock = -1;

int bt_transport_connect(unsigned char mac[6])
{
    struct sockaddr_l2 addr;

    sock = socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP);

    memset(&addr,0,sizeof(addr));
    addr.l2_family = AF_BLUETOOTH;
    addr.l2_psm = 0x1001;

    memcpy(addr.l2_bdaddr, mac, 6);

    if(connect(sock,(struct sockaddr*)&addr,sizeof(addr))<0){
        return -1;
    }
    return 0;
}

int bt_transport_send(void *buf,int len)
{
    return send(sock,buf,len,0);
}

int bt_transport_recv(void *buf,int len)
{
    return recv(sock,buf,len,0);
}
