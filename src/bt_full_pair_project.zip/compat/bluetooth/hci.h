
#ifndef BT_HCI_H
#define BT_HCI_H
#define HCI_CHANNEL_CONTROL 3
#endif
