#ifndef BT_CALL_H
#define BT_CALL_H

#include "bt_common.h"
#include "bt_context.h"

/*
 * bt_call_options_t controls the call pipeline checks.
 *
 * rfcomm_channel:
 *   The application-level call-control service channel on the peer side.
 *   We keep it configurable because different peer builds may advertise the
 *   service on a different RFCOMM channel even though channel 1 is a common
 *   default during development.
 *
 * control_timeout_ms:
 *   Timeout used when waiting for control-plane steps such as CALL-ACCEPT and
 *   AUDIO-READY. This value exists because connect() success alone only proves
 *   that a socket exists; it does not prove that the peer application accepted
 *   the call request or prepared its audio path.
 *
 * sco_timeout_ms:
 *   Timeout for the SCO connect step. SCO is the transport intended for voice
 *   frames, and a separate timeout is useful because control and audio setup do
 *   not always complete at the same speed.
 *
 * hold_seconds:
 *   How long the sample program keeps the call active once all checks pass.
 *   This is useful for test/validation runs and for future automation because
 *   it gives the monitoring loop time to detect a dropped control channel or a
 *   dropped SCO link.
 *
 * require_audio_ready_ack:
 *   When enabled, the caller requires a peer-side AUDIO-READY reply before the
 *   call is treated as audio-ready. This is important because the peer may have
 *   accepted the call logically but still not have opened or prepared its local
 *   audio path.
 *
 * require_sco_write_probe:
 *   When enabled, the caller performs a small silent write probe on the SCO
 *   socket after connect(). The reason is that a writable socket is a stronger
 *   post-check than connect() alone when validating the local audio transport.
 */
typedef struct {
    uint8_t rfcomm_channel;
    int control_timeout_ms;
    int sco_timeout_ms;
    int hold_seconds;
    int require_audio_ready_ack;
    int require_sco_write_probe;
} bt_call_options_t;

typedef struct {
    bt_status_t status;
    char call_id[32];
    char detail[160];
    int precheck_ok;
    int control_connected;
    int setup_accepted;
    int sco_connected;
    int audio_verified;
    int call_active;
    int ended_cleanly;
} bt_call_result_t;

void bt_call_options_init(bt_call_options_t *options);
const char *bt_call_state_str(bt_call_state_t state);
void bt_call_result_init(bt_call_result_t *result);
bt_call_result_t bt_call_start(bt_context_t *ctx, int adapter_index,
                               const char *mac,
                               const bt_call_options_t *options);

#endif
