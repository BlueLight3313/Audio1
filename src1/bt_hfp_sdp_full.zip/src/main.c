
#include <stdio.h>
#include <stdint.h>

int bt_rfcomm_server_start(uint8_t*);
int bt_rfcomm_accept(int);
int bt_sdp_register_ag(uint8_t);
void bt_hfp_ag_run(int);

int main(){
    uint8_t ch;
    int server = bt_rfcomm_server_start(&ch);

    bt_sdp_register_ag(ch);

    int client = bt_rfcomm_accept(server);
    printf("Client connected\n");

    bt_hfp_ag_run(client);

    return 0;
}
