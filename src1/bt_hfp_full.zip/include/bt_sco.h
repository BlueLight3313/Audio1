
#ifndef BT_SCO_H
#define BT_SCO_H

int bt_sco_connect(const char *mac);
int bt_sco_send(int fd, void *buf, int len);
int bt_sco_recv(int fd, void *buf, int len);

#endif
