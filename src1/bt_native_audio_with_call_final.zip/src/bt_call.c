
#include <stdio.h>
#include <string.h>
#include "bt_call.h"
#include "bt_call_proto.h"

static call_state_t state;
static char mac[32];

void bt_call_init(){ state=CALL_IDLE; }

void bt_call_dial(const char* m,const char* id){
 if(state!=CALL_IDLE){printf("busy\n");return;}
 strcpy(mac,m); state=CALL_OUTGOING;
 printf("dial %s id=%s\n",m,id);
}

void bt_call_incoming(const char* m,const char* id){
 if(state!=CALL_IDLE)return;
 strcpy(mac,m); state=CALL_INCOMING;
 printf("incoming %s id=%s\n",m,id);
}

void bt_call_accept(){
 if(state==CALL_INCOMING||state==CALL_OUTGOING){
  state=CALL_ACTIVE; printf("accepted\n");
 }
}

void bt_call_reject(){
 if(state==CALL_INCOMING){ state=CALL_IDLE; printf("rejected\n"); }
}

void bt_call_hangup(){
 if(state!=CALL_IDLE){ state=CALL_IDLE; printf("hangup\n"); }
}

void bt_call_remote_event(int t,const char* p){
 if(t==BT_CALL_MSG_ACCEPT){ state=CALL_ACTIVE; printf("remote accept\n"); }
 if(t==BT_CALL_MSG_REJECT){ state=CALL_IDLE; printf("remote reject\n"); }
 if(t==BT_CALL_MSG_HANGUP){ state=CALL_IDLE; printf("remote hangup\n"); }
}

void bt_call_print(){ printf("state=%d\n",state); }
