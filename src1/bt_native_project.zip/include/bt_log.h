
#ifndef BT_LOG_H
#define BT_LOG_H

void bt_log(const char *level, const char *msg);

#endif
