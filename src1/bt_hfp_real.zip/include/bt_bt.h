
#ifndef BT_BT_H
#define BT_BT_H

#define AF_BLUETOOTH 31
#define BTPROTO_RFCOMM 3
#define BTPROTO_SCO 2

struct sockaddr_rc {
    unsigned short rc_family;
    unsigned char rc_bdaddr[6];
    unsigned char rc_channel;
};

struct sockaddr_sco {
    unsigned short sco_family;
    unsigned char sco_bdaddr[6];
};

#endif
