
#include <stdio.h>
#include <string.h>

#include "bt_call.h"

#define BT_CALL_MSG_ACCEPT 2
#define BT_CALL_MSG_REJECT 3
#define BT_CALL_MSG_HANGUP 4

static call_state_t g_call_state = CALL_IDLE;
static char g_remote_mac[32];
static char g_remote_identifier[64];

void bt_call_init(void)
{
    g_call_state = CALL_IDLE;
    memset(g_remote_mac, 0, sizeof(g_remote_mac));
    memset(g_remote_identifier, 0, sizeof(g_remote_identifier));
}

void bt_call_dial(const char *mac, const char *identifier)
{
    if (g_call_state != CALL_IDLE) {
        printf("busy\n");
        return;
    }

    memset(g_remote_mac, 0, sizeof(g_remote_mac));
    memset(g_remote_identifier, 0, sizeof(g_remote_identifier));

    if (mac != NULL) {
        snprintf(g_remote_mac, sizeof(g_remote_mac), "%s", mac);
    }
    if (identifier != NULL) {
        snprintf(g_remote_identifier, sizeof(g_remote_identifier), "%s", identifier);
    }

    g_call_state = CALL_OUTGOING;
    printf("dial %s id=%s\n", g_remote_mac, g_remote_identifier);
}

void bt_call_incoming(const char *mac, const char *identifier)
{
    if (g_call_state != CALL_IDLE) {
        return;
    }

    memset(g_remote_mac, 0, sizeof(g_remote_mac));
    memset(g_remote_identifier, 0, sizeof(g_remote_identifier));

    if (mac != NULL) {
        snprintf(g_remote_mac, sizeof(g_remote_mac), "%s", mac);
    }
    if (identifier != NULL) {
        snprintf(g_remote_identifier, sizeof(g_remote_identifier), "%s", identifier);
    }

    g_call_state = CALL_INCOMING;
    printf("incoming %s id=%s\n", g_remote_mac, g_remote_identifier);
}

void bt_call_accept(void)
{
    if (g_call_state == CALL_INCOMING || g_call_state == CALL_OUTGOING) {
        g_call_state = CALL_ACTIVE;
        printf("accepted\n");
    }
}

void bt_call_reject(void)
{
    if (g_call_state == CALL_INCOMING) {
        g_call_state = CALL_IDLE;
        printf("rejected\n");
    }
}

void bt_call_hangup(void)
{
    if (g_call_state != CALL_IDLE) {
        g_call_state = CALL_IDLE;
        printf("hangup\n");
    }
}

void bt_call_remote_event(int type, const char *payload)
{
    (void)payload;

    if (type == BT_CALL_MSG_ACCEPT) {
        g_call_state = CALL_ACTIVE;
        printf("remote accept\n");
    } else if (type == BT_CALL_MSG_REJECT) {
        g_call_state = CALL_IDLE;
        printf("remote reject\n");
    } else if (type == BT_CALL_MSG_HANGUP) {
        g_call_state = CALL_IDLE;
        printf("remote hangup\n");
    }
}

void bt_call_print(void)
{
    printf("state=%d\n", (int)g_call_state);
    if (g_remote_mac[0] != '\0') {
        printf("remote_mac=%s\n", g_remote_mac);
    }
    if (g_remote_identifier[0] != '\0') {
        printf("remote_id=%s\n", g_remote_identifier);
    }
}
