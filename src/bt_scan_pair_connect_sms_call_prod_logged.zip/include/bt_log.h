#ifndef BT_LOG_H
#define BT_LOG_H

#include <stdarg.h>
#include "bt_common.h"

typedef enum {
    BT_LOG_READY = 0,
    BT_LOG_STARTED,
    BT_LOG_DOING,
    BT_LOG_DONE,
    BT_LOG_RESULT,
    BT_LOG_ERROR
} bt_log_state_t;

const char *bt_log_state_str(bt_log_state_t state);
void bt_logf(const char *scope, bt_log_state_t state, const char *fmt, ...);
void bt_log_result_status(const char *scope, bt_status_t status, const char *fmt, ...);

#endif
