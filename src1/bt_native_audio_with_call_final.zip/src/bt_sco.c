
#include <sys/socket.h>
#include <unistd.h>
#include <string.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/sco.h>
#include "bt_log.h"

static int sco_fd = -1;

int bt_sco_open(const bt_bdaddr_t *bdaddr)
{
    struct sockaddr_sco addr;

    sco_fd = socket(PF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_SCO);

    memset(&addr, 0, sizeof(addr));
    addr.sco_family = AF_BLUETOOTH;
    bacpy(&addr.sco_bdaddr, (bdaddr_t*)bdaddr->b);

    if(connect(sco_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0){
        bt_log_error("SCO connect failed");
        return -1;
    }

    bt_log_info("SCO connected");
    return 0;
}

void bt_sco_close()
{
    if(sco_fd >= 0){
        close(sco_fd);
        sco_fd = -1;
    }
}
