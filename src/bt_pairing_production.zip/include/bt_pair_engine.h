#ifndef BT_PAIR_ENGINE_H
#define BT_PAIR_ENGINE_H

#include <stdint.h>
#include "../compat/bluetooth/bluetooth.h"

typedef enum {
    BT_PAIR_RESULT_SUCCESS = 0,
    BT_PAIR_RESULT_FAILED = 1,
    BT_PAIR_RESULT_CANCELLED = 2,
    BT_PAIR_RESULT_TIMEOUT = 3,
    BT_PAIR_RESULT_REJECTED = 4,
    BT_PAIR_RESULT_PROTOCOL_ERROR = 5,
    BT_PAIR_RESULT_IO_ERROR = 6
} bt_pair_result_code_t;

typedef enum {
    BT_IO_CAP_DISPLAY_ONLY = 0,
    BT_IO_CAP_DISPLAY_YES_NO = 1,
    BT_IO_CAP_KEYBOARD_ONLY = 2,
    BT_IO_CAP_NO_INPUT_NO_OUTPUT = 3,
    BT_IO_CAP_KEYBOARD_DISPLAY = 4
} bt_io_capability_t;

typedef enum {
    BT_ADDR_BREDR = 0,
    BT_ADDR_LE_PUBLIC = 1,
    BT_ADDR_LE_RANDOM = 2
} bt_addr_type_t;

typedef struct {
    int adapter_index;
    bt_addr_type_t addr_type;
    bt_io_capability_t io_capability;
    int timeout_ms;
    int require_new_link_key;
    int interactive;
    char pin_code[17];
    int has_pin_code;
    uint32_t passkey;
    int has_passkey;
    int confirm_default_yes;
    int has_confirm_default;
} bt_pair_options_t;

typedef struct {
    bt_pair_result_code_t code;
    uint8_t mgmt_status;
    int auth_failed;
    int command_complete_seen;
    int command_status_seen;
    int pin_requested;
    int pin_replied;
    int confirm_requested;
    int confirm_replied;
    int passkey_requested;
    int passkey_replied;
    int link_key_seen;
    uint8_t link_key_type;
    uint8_t link_key_pin_length;
    uint8_t link_key_store_hint;
    int cancelled_by_local;
    int cancelled_by_remote_or_stack;
    char target_mac[18];
} bt_pair_report_t;

void bt_pair_options_init(bt_pair_options_t *opt);
const char *bt_pair_result_code_str(bt_pair_result_code_t code);
const char *bt_mgmt_status_str(uint8_t status);
int bt_pair_device_full(const char *mac, const bt_pair_options_t *options, bt_pair_report_t *report);

#endif
