
bt_native_with_scan_and_pair

Added:
- inquiry scan support
- in-memory device cache for nearby devices
- local MAC getter via HCIGETDEVINFO
- local name getter via HCI Read Local Name
- remote name resolution after inquiry
- pairing support for three policies:
  * pair auto <index>
  * pair confirm <index>
  * pair phone <index> [pin]
- in-memory bond cache with link keys

Build:
    make

Run:
    sudo systemctl stop bluetooth
    sudo ./bt_native

Commands:
    status
    discoverable on
    discoverable off
    power on
    power off
    scan
    devices
    paired
    pair auto <index>
    pair confirm <index>
    pair phone <index> [pin]
    help
    quit

Notes:
- This project currently targets classic BR/EDR inquiry + pairing flows.
- Pairing policy is host-driven, but the remote device still decides which legacy/SSP steps it uses.
- For smartphone mode, the code enforces your policy: pairing fails if the flow does not include both PIN/passkey handling and confirmation.
