
#define _XOPEN_SOURCE 600
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <stdint.h>
#include <string.h>

#define FRAME_BYTES 160

static int sco_fd;
static int dsp_in, dsp_out;
static pthread_t th;
static int run=0;

static void* loop(void*arg){
    (void)arg;
    int16_t buf[80];

    while(run){
        int n=read(dsp_in, buf, FRAME_BYTES);
        if(n>0) write(sco_fd, buf, FRAME_BYTES);

        n=read(sco_fd, buf, FRAME_BYTES);
        if(n>0) write(dsp_out, buf, FRAME_BYTES);

        usleep(10000);
    }
    return 0;
}

int bt_audio_start(int sco){
    sco_fd=sco;
    dsp_in=open("/dev/dsp",O_RDONLY);
    dsp_out=open("/dev/dsp",O_WRONLY);

    run=1;
    pthread_create(&th,0,loop,0);
    return 0;
}

void bt_audio_stop(){
    run=0;
    pthread_join(th,0);
}
