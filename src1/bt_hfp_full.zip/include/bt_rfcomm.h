
#ifndef BT_RFCOMM_H
#define BT_RFCOMM_H

int bt_rfcomm_connect(const char *mac);
int bt_rfcomm_send(int fd, const char *cmd);
int bt_rfcomm_recv(int fd, char *buf, int len);

#endif
