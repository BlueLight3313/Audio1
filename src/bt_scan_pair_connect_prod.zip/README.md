# bt_scan_pair_connect_prod

A native C Bluetooth BR/EDR project with **scan + pair + connect** that does not depend on BlueZ user-space development headers.

## What this project implements

- **Scan**
  - Uses the kernel BlueZ **mgmt** interface.
  - Starts BR/EDR discovery.
  - Collects `MAC + name + RSSI + flags`.
  - Responds to `Confirm Name` when the kernel asks for it.

- **Pair**
  - Uses the kernel BlueZ **mgmt** interface.
  - Sends `Pair Device`.
  - Handles:
    - `PIN Code Request`
    - `User Confirmation Request`
    - `User Passkey Request`
    - `Authentication Failed`
    - `New Link Key`
    - `Device Connected`
  - Only reports success when pairing completes successfully and, by default, a **New Link Key** event was seen.

- **Connect**
  - This project targets **generic BR/EDR baseband connection** in native C without BlueZ D-Bus.
  - BlueZ mgmt exposes discovery, pairing, disconnect, and connection-state events, but it does **not** expose a generic outgoing BR/EDR "connect this device now" command comparable to `Pair Device`.
  - For that reason, the generic connect step here establishes a BR/EDR transport connection by opening an **L2CAP socket to SDP PSM 0x0001**, then checks mgmt `Get Connections` to verify that the device appears connected.
  - If the transport socket connects but mgmt verification is not observed within the timeout, the project still reports the transport as connected and tells you that mgmt verification was not observed in time.

## Build

```bash
make
```

## Run

### Scan

```bash
sudo ./bt_prod scan
sudo ./bt_prod scan 0 8
```

### Pair

Examples:

- NoInputNoOutput / "Just Works"-like:
```bash
sudo ./bt_prod pair AA:BB:CC:DD:EE:FF 0 --io-cap 3 --confirm yes
```

- Confirmation-based device:
```bash
sudo ./bt_prod pair AA:BB:CC:DD:EE:FF 0 --io-cap 1 --confirm yes
```

- Legacy PIN:
```bash
sudo ./bt_prod pair AA:BB:CC:DD:EE:FF 0 --io-cap 2 --pin 1234
```

- Passkey:
```bash
sudo ./bt_prod pair AA:BB:CC:DD:EE:FF 0 --io-cap 2 --passkey 123456
```

### Connect

```bash
sudo ./bt_prod connect AA:BB:CC:DD:EE:FF 0
sudo ./bt_prod connect AA:BB:CC:DD:EE:FF 0 --verify-timeout-ms 3000 --hold-ms 5000
```

## Files

- `compat/bluetooth/*` - small local compatibility headers
- `include/*` - public project headers
- `src/bt_scan.c` - discovery
- `src/bt_pair.c` - full pairing engine
- `src/bt_connect.c` - generic BR/EDR connect + verification
- `src/bt_common.c` - common mgmt helpers
- `src/main.c` - CLI

## Notes

- Run as **root**.
- This project is scoped to **BR/EDR**.
- "Connect" here means **generic low-level BR/EDR connection establishment**. Profile-level auto-connect logic such as BlueZ `Device1.Connect()` is a D-Bus concern and is outside the scope of this no-BlueZ-headers native-C project.
