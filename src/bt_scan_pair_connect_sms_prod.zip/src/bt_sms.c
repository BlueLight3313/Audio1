#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>

#include "../include/bt_sms.h"
#include "../compat/bluetooth/rfcomm.h"

#define BT_SMS_MAX_TEXT 512
#define BT_SMS_DEFAULT_CHANNEL 1

static int bt_sms_send_payload(const char *mac, uint8_t channel, const char *payload, size_t payload_len)
{
    int sock;
    struct sockaddr_rc remote;
    bdaddr_t addr;
    ssize_t written;

    if (bt_str2ba(mac, &addr) < 0)
        return -1;

    sock = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);
    if (sock < 0)
        return -1;

    memset(&remote, 0, sizeof(remote));
    remote.rc_family = AF_BLUETOOTH;
    remote.rc_channel = channel;
    bt_bacpy(&remote.rc_bdaddr, &addr);

    if (connect(sock, (struct sockaddr *)&remote, sizeof(remote)) < 0) {
        close(sock);
        return -1;
    }

    written = write(sock, payload, payload_len);
    if (written < 0 || (size_t)written != payload_len) {
        close(sock);
        return -1;
    }

    close(sock);
    return 0;
}

void bt_sms_result_init(bt_sms_result_t *result)
{
    if (!result)
        return;

    memset(result, 0, sizeof(*result));
    result->status = BT_STATUS_FAIL;
    snprintf(result->detail, sizeof(result->detail), "%s", "SMS request was not sent");
}

bt_sms_result_t bt_sms_send_to_mac(bt_context_t *ctx, const char *mac,
                                   const char *text, uint8_t channel)
{
    bt_sms_result_t result;
    bt_device_t *dev;
    char payload[BT_SMS_MAX_TEXT + 128];
    const char *host_id;

    bt_sms_result_init(&result);

    if (!ctx || !mac || !text || !text[0]) {
        result.status = BT_STATUS_PROTOCOL;
        snprintf(result.detail, sizeof(result.detail), "%s", "invalid SMS arguments");
        return result;
    }

    if (channel == 0)
        channel = BT_SMS_DEFAULT_CHANNEL;

    dev = bt_context_find_by_mac(ctx, mac);
    if (!dev) {
        result.status = BT_STATUS_NOT_FOUND;
        snprintf(result.detail, sizeof(result.detail), "device not found in registry: %s", mac);
        return result;
    }

    host_id = bt_context_get_host_id(ctx);
    snprintf(payload, sizeof(payload), "SMS|%s|%s\n", host_id, text);

    result.targets_attempted = 1;
    if (bt_sms_send_payload(mac, channel, payload, strlen(payload)) == 0) {
        result.status = BT_STATUS_OK;
        result.targets_sent = 1;
        snprintf(result.detail, sizeof(result.detail), "SMS request sent to %s on RFCOMM channel %u", mac, channel);
        bt_context_mark_connected(ctx, mac, 1);
    } else {
        result.status = BT_STATUS_REMOTE;
        snprintf(result.detail, sizeof(result.detail), "failed to send SMS request to %s on RFCOMM channel %u", mac, channel);
        bt_context_mark_connected(ctx, mac, 0);
    }

    return result;
}

bt_sms_result_t bt_sms_send_all_connected(bt_context_t *ctx, const char *text,
                                          uint8_t channel)
{
    bt_sms_result_t result;
    int i;

    bt_sms_result_init(&result);

    if (!ctx || !text || !text[0]) {
        result.status = BT_STATUS_PROTOCOL;
        snprintf(result.detail, sizeof(result.detail), "%s", "invalid SMS arguments");
        return result;
    }

    if (channel == 0)
        channel = BT_SMS_DEFAULT_CHANNEL;

    result.status = BT_STATUS_OK;
    snprintf(result.detail, sizeof(result.detail), "%s", "SMS requests processed");

    for (i = 0; i < ctx->count; ++i) {
        bt_device_t *dev = &ctx->devices[i];
        bt_sms_result_t one;

        if (!dev->used || !dev->connected)
            continue;

        one = bt_sms_send_to_mac(ctx, dev->mac, text, channel);
        result.targets_attempted += one.targets_attempted;
        result.targets_sent += one.targets_sent;
        if (one.status != BT_STATUS_OK)
            result.status = BT_STATUS_REMOTE;
    }

    if (result.targets_attempted == 0) {
        result.status = BT_STATUS_NOT_FOUND;
        snprintf(result.detail, sizeof(result.detail), "%s", "no connected devices in registry");
    } else if (result.targets_sent == 0) {
        snprintf(result.detail, sizeof(result.detail), "%s", "SMS request failed for all connected devices");
    } else if (result.targets_sent < result.targets_attempted) {
        snprintf(result.detail, sizeof(result.detail), "SMS request sent to %d of %d connected devices",
                 result.targets_sent, result.targets_attempted);
    } else {
        snprintf(result.detail, sizeof(result.detail), "SMS request sent to all %d connected devices",
                 result.targets_sent);
    }

    return result;
}
