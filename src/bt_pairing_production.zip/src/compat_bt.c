#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "../compat/bluetooth/bluetooth.h"

void bacpy(bdaddr_t *dst, const bdaddr_t *src)
{
    memcpy(dst, src, sizeof(*dst));
}

int bacmp(const bdaddr_t *a, const bdaddr_t *b)
{
    return memcmp(a, b, sizeof(*a));
}

static int hex_value(char c)
{
    if (c >= '0' && c <= '9')
        return c - '0';

    c = (char)tolower((unsigned char)c);
    if (c >= 'a' && c <= 'f')
        return c - 'a' + 10;

    return -1;
}

int str2ba(const char *str, bdaddr_t *ba)
{
    int i;

    if (!str || !ba)
        return -1;

    if (strlen(str) != 17)
        return -1;

    for (i = 0; i < 6; ++i) {
        int src = (5 - i) * 3;
        int hi = hex_value(str[src]);
        int lo = hex_value(str[src + 1]);

        if (hi < 0 || lo < 0)
            return -1;

        ba->b[i] = (unsigned char)((hi << 4) | lo);

        if (i != 5 && str[src + 2] != ':')
            return -1;
    }

    return 0;
}

void ba2str(const bdaddr_t *ba, char *str)
{
    sprintf(str, "%02X:%02X:%02X:%02X:%02X:%02X",
            ba->b[5], ba->b[4], ba->b[3], ba->b[2], ba->b[1], ba->b[0]);
}
