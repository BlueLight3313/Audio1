
#ifndef BT_SOCK_H
#define BT_SOCK_H

#define AF_BLUETOOTH 31
#define BTPROTO_L2CAP 0

struct sockaddr_l2 {
    unsigned short l2_family;
    unsigned short l2_psm;
    unsigned char  l2_bdaddr[6];
} __attribute__((packed));

#endif
