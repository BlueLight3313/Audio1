
#include <stdio.h>
#include "bt_device.h"

void bt_fake_scan()
{
    uint8_t mac1[6]={1,2,3,4,5,6};
    uint8_t cod1[3]={0,0x04,0};

    uint8_t mac2[6]={6,5,4,3,2,1};
    uint8_t cod2[3]={0,0x02,0};

    bt_dev_add(mac1,cod1);
    bt_dev_add(mac2,cod2);

    printf("Scan done\n");
}
