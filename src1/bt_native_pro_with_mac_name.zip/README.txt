
bt_native_pro_with_mac_name

Added:
- local MAC getter via HCIGETDEVINFO
- local name getter via HCI Read Local Name
- formatted MAC printer
- status command prints MAC + Local Name + scan mode

Build:
    make

Run:
    sudo systemctl stop bluetooth
    sudo ./bt_native

Commands:
    status
    discoverable on
    discoverable off
    power on
    power off
    quit
