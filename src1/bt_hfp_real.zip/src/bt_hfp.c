
#include <stdio.h>
#include "bt_rfcomm.c"

int bt_hfp_start(const char*mac){
    int fd=bt_rfcomm_connect(mac);

    bt_rfcomm_send(fd,"AT+BRSF=20\r");
    bt_rfcomm_send(fd,"AT+CIND=?\r");
    bt_rfcomm_send(fd,"AT+CMER=3,0,0,1\r");

    return fd;
}

void bt_hfp_dial(int fd){
    bt_rfcomm_send(fd,"ATD123456;\r");
}
