
#ifndef BT_RFCOMM_SERVER_H
#define BT_RFCOMM_SERVER_H
int bt_rfcomm_server_start(uint8_t *channel_out);
int bt_rfcomm_accept(int server_fd);
#endif
