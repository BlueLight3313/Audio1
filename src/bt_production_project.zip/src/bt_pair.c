
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <poll.h>
#include <sys/socket.h>
#include "../include/bt.h"

#define AF_BLUETOOTH 31
#define BTPROTO_HCI 1
#define HCI_CHANNEL_CONTROL 3

#define MGMT_OP_PAIR_DEVICE 0x0019
#define MGMT_EV_CMD_COMPLETE 0x0001
#define MGMT_EV_CMD_STATUS 0x0002

typedef struct { unsigned char b[6]; } bdaddr_t;

struct sockaddr_hci {
    unsigned short hci_family;
    unsigned short hci_dev;
    unsigned short hci_channel;
};

struct mgmt_hdr {
    unsigned short opcode;
    unsigned short index;
    unsigned short len;
} __attribute__((packed));

struct mgmt_pair_cp {
    bdaddr_t addr;
    unsigned char addr_type;
    unsigned char io_cap;
} __attribute__((packed));

static int str2ba(const char *str, bdaddr_t *ba){
    unsigned int b[6];
    sscanf(str,"%02x:%02x:%02x:%02x:%02x:%02x",
        &b[5],&b[4],&b[3],&b[2],&b[1],&b[0]);
    for(int i=0;i<6;i++) ba->b[i]=b[i];
    return 0;
}

static int open_mgmt(int dev){
    int s=socket(AF_BLUETOOTH,SOCK_RAW,BTPROTO_HCI);
    struct sockaddr_hci addr={AF_BLUETOOTH,dev,HCI_CHANNEL_CONTROL};
    bind(s,(struct sockaddr*)&addr,sizeof(addr));
    return s;
}

bt_result_t bt_pair(int adapter,const char*mac){
    bt_result_t r={BT_FAIL,-1};
    int sock=open_mgmt(adapter);

    struct mgmt_hdr hdr;
    struct mgmt_pair_cp cp;

    str2ba(mac,&cp.addr);
    cp.addr_type=0;
    cp.io_cap=3;

    hdr.opcode=MGMT_OP_PAIR_DEVICE;
    hdr.index=adapter;
    hdr.len=sizeof(cp);

    write(sock,&hdr,sizeof(hdr));
    write(sock,&cp,sizeof(cp));

    struct pollfd pfd={sock,POLLIN,0};
    unsigned char buf[1024];

    while(1){
        int pr=poll(&pfd,1,15000);
        if(pr<=0){ r.status=BT_TIMEOUT; break; }

        int n=read(sock,buf,sizeof(buf));
        if(n<=0) continue;

        struct mgmt_hdr *h=(void*)buf;

        if(h->opcode==MGMT_EV_CMD_COMPLETE){
            unsigned char status=buf[sizeof(*h)+2];
            r.mgmt_status=status;

            if(status==0x00) r.status=BT_OK;
            else if(status==0x12) r.status=BT_CANCELLED;
            else r.status=BT_FAIL;
            break;
        }

        if(h->opcode==MGMT_EV_CMD_STATUS){
            r.status=BT_FAIL;
            break;
        }
    }

    close(sock);
    return r;
}
