
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/time.h>

#include "bt_defs.h"
#include "bt_types.h"
#include "bt_hci.h"
#include "bt_device.h"
#include "bt_scan.h"
#include "bt_log.h"

static size_t bt_local_strnlen(const char *s, size_t maxlen)
{
    size_t i = 0;
    while (i < maxlen && s[i] != '\0') {
        ++i;
    }
    return i;
}

static int bt_scan_parse_eir_name(const uint8_t *eir, size_t eir_len, char *name_out, size_t name_out_size)
{
    size_t pos = 0;

    if (name_out == NULL || name_out_size == 0) {
        return -1;
    }

    while (pos < eir_len) {
        uint8_t field_len = eir[pos];
        uint8_t type;
        size_t data_len;
        size_t copy_len;

        if (field_len == 0) {
            break;
        }

        if (pos + 1 + field_len > eir_len) {
            break;
        }

        type = eir[pos + 1];
        data_len = field_len - 1;

        if (type == 0x09 || type == 0x08) {
            copy_len = data_len;
            if (copy_len >= name_out_size) {
                copy_len = name_out_size - 1;
            }
            memcpy(name_out, eir + pos + 2, copy_len);
            name_out[copy_len] = '\0';
            return 0;
        }

        pos += 1 + field_len;
    }

    return -1;
}

static void bt_scan_store_inquiry_info(
    const bt_bdaddr_t *bdaddr,
    uint8_t page_scan_rep_mode,
    uint16_t clock_offset,
    int has_rssi,
    int8_t rssi
)
{
    if (bt_device_cache_add_or_update_basic(bdaddr, page_scan_rep_mode, clock_offset, has_rssi, rssi) == NULL) {
        bt_log_warn("Device cache is full; dropping a discovered device");
    }
}

static int bt_scan_collect(int hci_sock, unsigned int duration_units_1_28s)
{
    struct hci_filter old_filter;
    struct hci_filter filter;
    socklen_t optlen;
    struct timeval tv;
    struct bt_hci_cp_inquiry cp;
    uint8_t rxbuf[BT_MAX_HCI_EVENT_SIZE];
    int inquiry_done = 0;

    memset(&filter, 0, sizeof(filter));
    bt_hci_filter_set_bit(BT_HCI_EVENT_PKT, &filter.type_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_INQUIRY_COMPLETE, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_INQUIRY_RESULT, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_INQUIRY_RESULT_WITH_RSSI, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_EXTENDED_INQUIRY_RESULT, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_CMD_COMPLETE, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_CMD_STATUS, filter.event_mask);
    filter.opcode = BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_INQUIRY);

    optlen = sizeof(old_filter);
    if (getsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, &optlen) < 0) {
        return -1;
    }

    if (setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &filter, sizeof(filter)) < 0) {
        return -1;
    }

    tv.tv_sec = (int)(duration_units_1_28s * 1280U / 1000U) + 3;
    tv.tv_usec = 0;
    if (setsockopt(hci_sock, BT_SOL_SOCKET, BT_SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
        setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
        return -1;
    }

    cp.lap[0] = 0x33;
    cp.lap[1] = 0x8B;
    cp.lap[2] = 0x9E;
    cp.inquiry_length = (uint8_t)duration_units_1_28s;
    cp.num_responses = 0x00;

    if (bt_hci_send_cmd_only(hci_sock, BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_INQUIRY), &cp, sizeof(cp)) < 0) {
        setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
        return -1;
    }

    while (!inquiry_done) {
        ssize_t n = read(hci_sock, rxbuf, sizeof(rxbuf));
        struct hci_event_hdr *eh;
        uint8_t *payload;

        if (n < 0) {
            setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
            return -1;
        }

        if (n < 1 + (ssize_t)sizeof(struct hci_event_hdr)) {
            continue;
        }

        if (rxbuf[0] != BT_HCI_EVENT_PKT) {
            continue;
        }

        eh = (struct hci_event_hdr *)(rxbuf + 1);
        payload = rxbuf + 1 + sizeof(struct hci_event_hdr);

        if (eh->evt == BT_HCI_EV_CMD_STATUS) {
            struct bt_hci_ev_cmd_status *cs;
            if (eh->plen < sizeof(*cs)) {
                continue;
            }
            cs = (struct bt_hci_ev_cmd_status *)payload;
            if (bt_hci_le16_to_cpu(cs->opcode) == BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_INQUIRY) && cs->status != 0x00) {
                errno = EIO;
                setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
                return -1;
            }
            continue;
        }

        if (eh->evt == BT_HCI_EV_INQUIRY_COMPLETE) {
            struct bt_hci_ev_inquiry_complete *ic;
            if (eh->plen < sizeof(*ic)) {
                continue;
            }
            ic = (struct bt_hci_ev_inquiry_complete *)payload;
            if (ic->status != 0x00) {
                errno = EIO;
                setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
                return -1;
            }
            inquiry_done = 1;
            continue;
        }

        if (eh->evt == BT_HCI_EV_INQUIRY_RESULT) {
            uint8_t count;
            size_t i;
            struct bt_hci_ev_inquiry_info *items;

            if (eh->plen < 1) {
                continue;
            }
            count = payload[0];
            items = (struct bt_hci_ev_inquiry_info *)(payload + 1);

            for (i = 0; i < count; ++i) {
                bt_scan_store_inquiry_info(
                    &items[i].bdaddr,
                    items[i].page_scan_rep_mode,
                    bt_hci_le16_to_cpu(items[i].clock_offset),
                    0,
                    0
                );
            }
            continue;
        }

        if (eh->evt == BT_HCI_EV_INQUIRY_RESULT_WITH_RSSI) {
            uint8_t count;
            size_t i;
            struct bt_hci_ev_inquiry_result_rssi_info *items;

            if (eh->plen < 1) {
                continue;
            }
            count = payload[0];
            items = (struct bt_hci_ev_inquiry_result_rssi_info *)(payload + 1);

            for (i = 0; i < count; ++i) {
                bt_scan_store_inquiry_info(
                    &items[i].bdaddr,
                    items[i].page_scan_rep_mode,
                    bt_hci_le16_to_cpu(items[i].clock_offset),
                    1,
                    items[i].rssi
                );
            }
            continue;
        }

        if (eh->evt == BT_HCI_EV_EXTENDED_INQUIRY_RESULT) {
            struct bt_hci_ev_extended_inquiry_result *eir_item;
            struct bt_device_record *record;
            char name_buf[249];

            if (eh->plen < sizeof(*eir_item)) {
                continue;
            }

            eir_item = (struct bt_hci_ev_extended_inquiry_result *)payload;
            record = bt_device_cache_add_or_update_basic(
                &eir_item->bdaddr,
                eir_item->page_scan_rep_mode,
                bt_hci_le16_to_cpu(eir_item->clock_offset),
                1,
                eir_item->rssi
            );
            if (record != NULL) {
                if (bt_scan_parse_eir_name(eir_item->eir, sizeof(eir_item->eir), name_buf, sizeof(name_buf)) == 0) {
                    bt_device_cache_set_name(&eir_item->bdaddr, name_buf);
                }
            } else {
                bt_log_warn("Device cache is full; dropping an extended inquiry result");
            }
            continue;
        }
    }

    setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
    return 0;
}

static int bt_scan_resolve_one_name(int hci_sock, const struct bt_device_record *device)
{
    struct hci_filter old_filter;
    struct hci_filter filter;
    socklen_t optlen;
    struct timeval tv;
    struct bt_hci_cp_remote_name_req cp;
    uint8_t rxbuf[BT_MAX_HCI_EVENT_SIZE];

    memset(&filter, 0, sizeof(filter));
    bt_hci_filter_set_bit(BT_HCI_EVENT_PKT, &filter.type_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_REMOTE_NAME_REQ_COMPLETE, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_CMD_STATUS, filter.event_mask);
    filter.opcode = BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_REMOTE_NAME_REQ);

    optlen = sizeof(old_filter);
    if (getsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, &optlen) < 0) {
        return -1;
    }

    if (setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &filter, sizeof(filter)) < 0) {
        return -1;
    }

    tv.tv_sec = 5;
    tv.tv_usec = 0;
    if (setsockopt(hci_sock, BT_SOL_SOCKET, BT_SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
        setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
        return -1;
    }

    memset(&cp, 0, sizeof(cp));
    cp.bdaddr = device->bdaddr;
    cp.page_scan_rep_mode = device->page_scan_rep_mode;
    cp.reserved = 0x00;
    cp.clock_offset = bt_hci_cpu_to_le16(device->clock_offset);

    if (bt_hci_send_cmd_only(hci_sock, BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_REMOTE_NAME_REQ), &cp, sizeof(cp)) < 0) {
        setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
        return -1;
    }

    for (;;) {
        ssize_t n = read(hci_sock, rxbuf, sizeof(rxbuf));
        struct hci_event_hdr *eh;
        uint8_t *payload;

        if (n < 0) {
            setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
            return -1;
        }

        if (n < 1 + (ssize_t)sizeof(struct hci_event_hdr)) {
            continue;
        }

        if (rxbuf[0] != BT_HCI_EVENT_PKT) {
            continue;
        }

        eh = (struct hci_event_hdr *)(rxbuf + 1);
        payload = rxbuf + 1 + sizeof(struct hci_event_hdr);

        if (eh->evt == BT_HCI_EV_CMD_STATUS) {
            struct bt_hci_ev_cmd_status *cs;
            if (eh->plen < sizeof(*cs)) {
                continue;
            }
            cs = (struct bt_hci_ev_cmd_status *)payload;
            if (bt_hci_le16_to_cpu(cs->opcode) != BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_REMOTE_NAME_REQ)) {
                continue;
            }
            if (cs->status != 0x00) {
                errno = EIO;
                setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
                return -1;
            }
            continue;
        }

        if (eh->evt == BT_HCI_EV_REMOTE_NAME_REQ_COMPLETE) {
            struct bt_hci_ev_remote_name_req_complete *rn;
            size_t len;
            char name_buf[249];

            if (eh->plen < sizeof(*rn)) {
                continue;
            }

            rn = (struct bt_hci_ev_remote_name_req_complete *)payload;
            if (memcmp(rn->bdaddr.b, device->bdaddr.b, 6) != 0) {
                continue;
            }

            if (rn->status == 0x00) {
                len = bt_local_strnlen(rn->name, sizeof(rn->name));
                if (len >= sizeof(name_buf)) {
                    len = sizeof(name_buf) - 1;
                }
                memcpy(name_buf, rn->name, len);
                name_buf[len] = '\0';
                bt_device_cache_set_name(&device->bdaddr, name_buf);
            }

            setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
            return 0;
        }
    }
}

static void bt_scan_resolve_names(int hci_sock)
{
    size_t i;
    size_t count = bt_device_cache_count();

    for (i = 0; i < count; ++i) {
        const struct bt_device_record *device = bt_device_cache_get_const(i);
        if (device == NULL) {
            continue;
        }
        if (device->has_name) {
            continue;
        }
        if (bt_scan_resolve_one_name(hci_sock, device) < 0) {
            bt_log_warn("Remote name request failed for %s", device->address_text);
        }
        {
            struct timeval tv;
            tv.tv_sec = 0;
            tv.tv_usec = 150000;
            select(0, NULL, NULL, NULL, &tv);
        }
    }
}

int bt_scan_nearby_devices(int hci_sock, unsigned int duration_units_1_28s)
{
    if (duration_units_1_28s == 0) {
        duration_units_1_28s = 8;
    }
    if (duration_units_1_28s > 0x30U) {
        duration_units_1_28s = 0x30U;
    }

    bt_device_cache_clear();
    bt_log_info("Starting inquiry scan (%u x 1.28s)", duration_units_1_28s);

    if (bt_scan_collect(hci_sock, duration_units_1_28s) < 0) {
        return -1;
    }

    bt_log_info("Inquiry complete; %lu device(s) discovered", (unsigned long)bt_device_cache_count());
    bt_log_info("Resolving remote names...");
    bt_scan_resolve_names(hci_sock);
    bt_log_info("Scan data stored in device cache");

    return 0;
}
