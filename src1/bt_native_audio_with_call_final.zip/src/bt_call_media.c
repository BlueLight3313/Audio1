#include "bt_audio.h"
#include "bt_call_media.h"
#include "bt_sco.h"

int bt_call_media_start(const bt_bdaddr_t *bdaddr)
{
    if (bt_sco_open(bdaddr) < 0) {
        return -1;
    }

    if (bt_audio_start() < 0) {
        bt_sco_close();
        return -1;
    }

    return 0;
}

void bt_call_media_stop(void)
{
    bt_audio_stop();
    bt_sco_close();
}
