#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

#include "../compat/bluetooth/bluetooth.h"
#include "../compat/bluetooth/hci.h"
#include "../include/bt_pair_engine.h"

#define MGMT_OP_PAIR_DEVICE                     0x0019
#define MGMT_OP_CANCEL_PAIR_DEVICE              0x001A
#define MGMT_OP_USER_CONFIRM_REPLY              0x001C
#define MGMT_OP_USER_CONFIRM_NEG_REPLY          0x001D
#define MGMT_OP_USER_PASSKEY_REPLY              0x001E
#define MGMT_OP_USER_PASSKEY_NEG_REPLY          0x001F
#define MGMT_OP_PIN_CODE_REPLY                  0x0016
#define MGMT_OP_PIN_CODE_NEG_REPLY              0x0017

#define MGMT_EV_CMD_COMPLETE                    0x0001
#define MGMT_EV_CMD_STATUS                      0x0002
#define MGMT_EV_NEW_LINK_KEY                    0x0009
#define MGMT_EV_AUTH_FAILED                     0x0011
#define MGMT_EV_PIN_CODE_REQUEST                0x000E
#define MGMT_EV_USER_CONFIRM_REQUEST            0x000F
#define MGMT_EV_USER_PASSKEY_REQUEST            0x0010

#define MGMT_STATUS_SUCCESS                     0x00
#define MGMT_STATUS_AUTH_FAILED                 0x05
#define MGMT_STATUS_TIMEOUT                     0x08
#define MGMT_STATUS_REJECTED                    0x0B
#define MGMT_STATUS_CANCELLED                   0x10
#define MGMT_STATUS_ALREADY_PAIRED              0x13

struct mgmt_hdr {
    uint16_t opcode;
    uint16_t index;
    uint16_t len;
} __attribute__((packed));

struct mgmt_ev_cmd_complete {
    uint16_t opcode;
    uint8_t status;
    uint8_t data[0];
} __attribute__((packed));

struct mgmt_ev_cmd_status {
    uint16_t opcode;
    uint8_t status;
} __attribute__((packed));

struct mgmt_addr_info {
    bdaddr_t addr;
    uint8_t addr_type;
} __attribute__((packed));

struct mgmt_cp_pair_device {
    bdaddr_t addr;
    uint8_t addr_type;
    uint8_t io_capability;
} __attribute__((packed));

struct mgmt_cp_cancel_pair_device {
    bdaddr_t addr;
    uint8_t addr_type;
} __attribute__((packed));

struct mgmt_cp_user_confirm_reply {
    bdaddr_t addr;
    uint8_t addr_type;
} __attribute__((packed));

struct mgmt_cp_user_confirm_neg_reply {
    bdaddr_t addr;
    uint8_t addr_type;
} __attribute__((packed));

struct mgmt_cp_user_passkey_reply {
    bdaddr_t addr;
    uint8_t addr_type;
    uint32_t passkey;
} __attribute__((packed));

struct mgmt_cp_user_passkey_neg_reply {
    bdaddr_t addr;
    uint8_t addr_type;
} __attribute__((packed));

struct mgmt_cp_pin_code_reply {
    bdaddr_t addr;
    uint8_t addr_type;
    uint8_t pin_len;
    uint8_t pin_code[16];
} __attribute__((packed));

struct mgmt_cp_pin_code_neg_reply {
    bdaddr_t addr;
    uint8_t addr_type;
} __attribute__((packed));

struct mgmt_ev_pin_code_request {
    bdaddr_t addr;
    uint8_t addr_type;
    uint8_t secure;
} __attribute__((packed));

struct mgmt_ev_user_confirm_request {
    bdaddr_t addr;
    uint8_t addr_type;
    uint8_t confirm_hint;
    uint32_t value;
} __attribute__((packed));

struct mgmt_ev_user_passkey_request {
    bdaddr_t addr;
    uint8_t addr_type;
} __attribute__((packed));

struct mgmt_ev_auth_failed {
    bdaddr_t addr;
    uint8_t addr_type;
    uint8_t status;
} __attribute__((packed));

struct mgmt_ev_new_link_key {
    uint8_t store_hint;
    bdaddr_t addr;
    uint8_t addr_type;
    uint8_t key_type;
    uint8_t value[16];
    uint8_t pin_length;
} __attribute__((packed));

struct pair_context {
    int sock;
    bdaddr_t target_addr;
    bt_pair_options_t options;
    bt_pair_report_t *report;
    int pair_command_sent;
};

static uint16_t cpu_to_le16(uint16_t v)
{
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    return v;
#else
    return (uint16_t)((v << 8) | (v >> 8));
#endif
}

static uint16_t le16_to_cpu(uint16_t v)
{
    return cpu_to_le16(v);
}

static uint32_t cpu_to_le32(uint32_t v)
{
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    return v;
#else
    return ((v & 0x000000FFU) << 24) |
           ((v & 0x0000FF00U) << 8) |
           ((v & 0x00FF0000U) >> 8) |
           ((v & 0xFF000000U) >> 24);
#endif
}

static uint32_t le32_to_cpu(uint32_t v)
{
    return cpu_to_le32(v);
}

static long long monotonic_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL;
}

void bt_pair_options_init(bt_pair_options_t *opt)
{
    memset(opt, 0, sizeof(*opt));
    opt->adapter_index = 0;
    opt->addr_type = BT_ADDR_BREDR;
    opt->io_capability = BT_IO_CAP_NO_INPUT_NO_OUTPUT;
    opt->timeout_ms = 30000;
    opt->require_new_link_key = 1;
    opt->interactive = 1;
}

const char *bt_pair_result_code_str(bt_pair_result_code_t code)
{
    switch (code) {
    case BT_PAIR_RESULT_SUCCESS: return "SUCCESS";
    case BT_PAIR_RESULT_FAILED: return "FAILED";
    case BT_PAIR_RESULT_CANCELLED: return "CANCELLED";
    case BT_PAIR_RESULT_TIMEOUT: return "TIMEOUT";
    case BT_PAIR_RESULT_REJECTED: return "REJECTED";
    case BT_PAIR_RESULT_PROTOCOL_ERROR: return "PROTOCOL_ERROR";
    case BT_PAIR_RESULT_IO_ERROR: return "IO_ERROR";
    default: return "UNKNOWN";
    }
}

const char *bt_mgmt_status_str(uint8_t status)
{
    switch (status) {
    case 0x00: return "Success";
    case 0x01: return "Unknown Command";
    case 0x02: return "Not Connected";
    case 0x03: return "Failed";
    case 0x04: return "Connect Failed";
    case 0x05: return "Authentication Failed";
    case 0x06: return "Not Paired";
    case 0x07: return "No Resources";
    case 0x08: return "Timeout";
    case 0x09: return "Already Connected";
    case 0x0A: return "Busy";
    case 0x0B: return "Rejected";
    case 0x0C: return "Not Supported";
    case 0x0D: return "Invalid Parameters";
    case 0x0E: return "Disconnected";
    case 0x0F: return "Not Powered";
    case 0x10: return "Cancelled";
    case 0x11: return "Invalid Index";
    case 0x12: return "RFKilled";
    case 0x13: return "Already Paired";
    case 0x14: return "Permission Denied";
    default: return "Unknown Status";
    }
}

static int mgmt_open_socket(void)
{
    int fd;
    struct sockaddr_hci addr;

    fd = socket(PF_BLUETOOTH, SOCK_RAW | SOCK_CLOEXEC, BTPROTO_HCI);
    if (fd < 0)
        return -1;

    memset(&addr, 0, sizeof(addr));
    addr.hci_family = AF_BLUETOOTH;
    addr.hci_dev = HCI_DEV_NONE;
    addr.hci_channel = HCI_CHANNEL_CONTROL;

    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        close(fd);
        return -1;
    }

    return fd;
}

static int mgmt_send_cmd(int fd, uint16_t opcode, uint16_t index, const void *payload, uint16_t payload_len)
{
    uint8_t buf[512];
    struct mgmt_hdr *hdr = (struct mgmt_hdr *)buf;

    if (sizeof(*hdr) + payload_len > sizeof(buf))
        return -1;

    hdr->opcode = cpu_to_le16(opcode);
    hdr->index = cpu_to_le16(index);
    hdr->len = cpu_to_le16(payload_len);

    if (payload_len && payload)
        memcpy(buf + sizeof(*hdr), payload, payload_len);

    if (write(fd, buf, sizeof(*hdr) + payload_len) < 0)
        return -1;

    return 0;
}

static int same_target(const bdaddr_t *addr, uint8_t addr_type, const struct pair_context *ctx)
{
    return addr_type == (uint8_t)ctx->options.addr_type && bacmp(addr, &ctx->target_addr) == 0;
}

static int prompt_yes_no(const char *prompt, int default_yes)
{
    char line[32];

    fprintf(stdout, "%s [%s/%s]: ", prompt, default_yes ? "Y" : "y", default_yes ? "n" : "N");
    fflush(stdout);

    if (!fgets(line, sizeof(line), stdin))
        return default_yes;

    if (line[0] == '\n' || line[0] == '\0')
        return default_yes;

    if (line[0] == 'y' || line[0] == 'Y')
        return 1;

    return 0;
}

static int prompt_pin(char *out_pin, size_t out_sz)
{
    char line[64];

    fprintf(stdout, "Enter PIN code: ");
    fflush(stdout);

    if (!fgets(line, sizeof(line), stdin))
        return -1;

    line[strcspn(line, "\r\n")] = '\0';
    if (line[0] == '\0')
        return -1;

    if (strlen(line) > 16)
        return -1;

    strncpy(out_pin, line, out_sz - 1);
    out_pin[out_sz - 1] = '\0';
    return 0;
}

static int prompt_passkey(uint32_t *passkey)
{
    char line[64];
    char *end;
    unsigned long value;

    fprintf(stdout, "Enter passkey (0-999999): ");
    fflush(stdout);

    if (!fgets(line, sizeof(line), stdin))
        return -1;

    value = strtoul(line, &end, 10);
    if (end == line || value > 999999UL)
        return -1;

    *passkey = (uint32_t)value;
    return 0;
}

static int send_pin_reply(struct pair_context *ctx, const bdaddr_t *addr, uint8_t addr_type, const char *pin)
{
    struct mgmt_cp_pin_code_reply cp;
    size_t pin_len = strlen(pin);

    memset(&cp, 0, sizeof(cp));
    bacpy(&cp.addr, addr);
    cp.addr_type = addr_type;
    cp.pin_len = (uint8_t)pin_len;
    memcpy(cp.pin_code, pin, pin_len);

    return mgmt_send_cmd(ctx->sock, MGMT_OP_PIN_CODE_REPLY,
                         (uint16_t)ctx->options.adapter_index,
                         &cp, sizeof(cp));
}

static int send_pin_negative_reply(struct pair_context *ctx, const bdaddr_t *addr, uint8_t addr_type)
{
    struct mgmt_cp_pin_code_neg_reply cp;
    memset(&cp, 0, sizeof(cp));
    bacpy(&cp.addr, addr);
    cp.addr_type = addr_type;
    return mgmt_send_cmd(ctx->sock, MGMT_OP_PIN_CODE_NEG_REPLY,
                         (uint16_t)ctx->options.adapter_index,
                         &cp, sizeof(cp));
}

static int send_confirm_reply(struct pair_context *ctx, const bdaddr_t *addr, uint8_t addr_type)
{
    struct mgmt_cp_user_confirm_reply cp;
    memset(&cp, 0, sizeof(cp));
    bacpy(&cp.addr, addr);
    cp.addr_type = addr_type;
    return mgmt_send_cmd(ctx->sock, MGMT_OP_USER_CONFIRM_REPLY,
                         (uint16_t)ctx->options.adapter_index,
                         &cp, sizeof(cp));
}

static int send_confirm_negative_reply(struct pair_context *ctx, const bdaddr_t *addr, uint8_t addr_type)
{
    struct mgmt_cp_user_confirm_neg_reply cp;
    memset(&cp, 0, sizeof(cp));
    bacpy(&cp.addr, addr);
    cp.addr_type = addr_type;
    return mgmt_send_cmd(ctx->sock, MGMT_OP_USER_CONFIRM_NEG_REPLY,
                         (uint16_t)ctx->options.adapter_index,
                         &cp, sizeof(cp));
}

static int send_passkey_reply(struct pair_context *ctx, const bdaddr_t *addr, uint8_t addr_type, uint32_t passkey)
{
    struct mgmt_cp_user_passkey_reply cp;
    memset(&cp, 0, sizeof(cp));
    bacpy(&cp.addr, addr);
    cp.addr_type = addr_type;
    cp.passkey = cpu_to_le32(passkey);
    return mgmt_send_cmd(ctx->sock, MGMT_OP_USER_PASSKEY_REPLY,
                         (uint16_t)ctx->options.adapter_index,
                         &cp, sizeof(cp));
}

static int send_passkey_negative_reply(struct pair_context *ctx, const bdaddr_t *addr, uint8_t addr_type)
{
    struct mgmt_cp_user_passkey_neg_reply cp;
    memset(&cp, 0, sizeof(cp));
    bacpy(&cp.addr, addr);
    cp.addr_type = addr_type;
    return mgmt_send_cmd(ctx->sock, MGMT_OP_USER_PASSKEY_NEG_REPLY,
                         (uint16_t)ctx->options.adapter_index,
                         &cp, sizeof(cp));
}

static int send_cancel_pair(struct pair_context *ctx)
{
    struct mgmt_cp_cancel_pair_device cp;
    memset(&cp, 0, sizeof(cp));
    bacpy(&cp.addr, &ctx->target_addr);
    cp.addr_type = (uint8_t)ctx->options.addr_type;
    return mgmt_send_cmd(ctx->sock, MGMT_OP_CANCEL_PAIR_DEVICE,
                         (uint16_t)ctx->options.adapter_index,
                         &cp, sizeof(cp));
}

static void set_failure_from_status(bt_pair_report_t *report, uint8_t status)
{
    report->mgmt_status = status;

    if (status == MGMT_STATUS_CANCELLED) {
        report->code = BT_PAIR_RESULT_CANCELLED;
        report->cancelled_by_remote_or_stack = 1;
    } else if (status == MGMT_STATUS_REJECTED) {
        report->code = BT_PAIR_RESULT_REJECTED;
    } else if (status == MGMT_STATUS_TIMEOUT) {
        report->code = BT_PAIR_RESULT_TIMEOUT;
    } else {
        report->code = BT_PAIR_RESULT_FAILED;
    }
}

static int handle_pin_request(struct pair_context *ctx, const uint8_t *payload, uint16_t len)
{
    const struct mgmt_ev_pin_code_request *ev;
    char pin[17];

    if (len < sizeof(*ev))
        return -1;

    ev = (const struct mgmt_ev_pin_code_request *)payload;
    if (!same_target(&ev->addr, ev->addr_type, ctx))
        return 0;

    ctx->report->pin_requested = 1;

    if (ctx->options.has_pin_code) {
        strncpy(pin, ctx->options.pin_code, sizeof(pin) - 1);
        pin[sizeof(pin) - 1] = '\0';
        if (send_pin_reply(ctx, &ev->addr, ev->addr_type, pin) < 0)
            return -1;
        ctx->report->pin_replied = 1;
        return 0;
    }

    if (ctx->options.interactive) {
        if (prompt_pin(pin, sizeof(pin)) == 0) {
            if (send_pin_reply(ctx, &ev->addr, ev->addr_type, pin) < 0)
                return -1;
            ctx->report->pin_replied = 1;
            return 0;
        }
    }

    ctx->report->cancelled_by_local = 1;
    send_pin_negative_reply(ctx, &ev->addr, ev->addr_type);
    send_cancel_pair(ctx);
    ctx->report->code = BT_PAIR_RESULT_CANCELLED;
    return 1;
}

static int handle_confirm_request(struct pair_context *ctx, const uint8_t *payload, uint16_t len)
{
    const struct mgmt_ev_user_confirm_request *ev;
    int accept = 0;
    char mac[18];
    char prompt[128];

    if (len < sizeof(*ev))
        return -1;

    ev = (const struct mgmt_ev_user_confirm_request *)payload;
    if (!same_target(&ev->addr, ev->addr_type, ctx))
        return 0;

    ctx->report->confirm_requested = 1;

    if (ctx->options.has_confirm_default) {
        accept = ctx->options.confirm_default_yes;
    } else if (ctx->options.interactive) {
        ba2str(&ev->addr, mac);
        snprintf(prompt, sizeof(prompt),
                 "Confirm pairing with %s, value %u",
                 mac, (unsigned int)le32_to_cpu(ev->value));
        accept = prompt_yes_no(prompt, 0);
    }

    if (accept) {
        if (send_confirm_reply(ctx, &ev->addr, ev->addr_type) < 0)
            return -1;
        ctx->report->confirm_replied = 1;
        return 0;
    }

    ctx->report->cancelled_by_local = 1;
    send_confirm_negative_reply(ctx, &ev->addr, ev->addr_type);
    send_cancel_pair(ctx);
    ctx->report->code = BT_PAIR_RESULT_CANCELLED;
    return 1;
}

static int handle_passkey_request(struct pair_context *ctx, const uint8_t *payload, uint16_t len)
{
    const struct mgmt_ev_user_passkey_request *ev;
    uint32_t passkey;

    if (len < sizeof(*ev))
        return -1;

    ev = (const struct mgmt_ev_user_passkey_request *)payload;
    if (!same_target(&ev->addr, ev->addr_type, ctx))
        return 0;

    ctx->report->passkey_requested = 1;

    if (ctx->options.has_passkey) {
        passkey = ctx->options.passkey;
        if (send_passkey_reply(ctx, &ev->addr, ev->addr_type, passkey) < 0)
            return -1;
        ctx->report->passkey_replied = 1;
        return 0;
    }

    if (ctx->options.interactive) {
        if (prompt_passkey(&passkey) == 0) {
            if (send_passkey_reply(ctx, &ev->addr, ev->addr_type, passkey) < 0)
                return -1;
            ctx->report->passkey_replied = 1;
            return 0;
        }
    }

    ctx->report->cancelled_by_local = 1;
    send_passkey_negative_reply(ctx, &ev->addr, ev->addr_type);
    send_cancel_pair(ctx);
    ctx->report->code = BT_PAIR_RESULT_CANCELLED;
    return 1;
}

static void handle_auth_failed(struct pair_context *ctx, const uint8_t *payload, uint16_t len)
{
    const struct mgmt_ev_auth_failed *ev;

    if (len < sizeof(*ev))
        return;

    ev = (const struct mgmt_ev_auth_failed *)payload;
    if (!same_target(&ev->addr, ev->addr_type, ctx))
        return;

    ctx->report->auth_failed = 1;
    set_failure_from_status(ctx->report, ev->status);
}

static void handle_new_link_key(struct pair_context *ctx, const uint8_t *payload, uint16_t len)
{
    const struct mgmt_ev_new_link_key *ev;

    if (len < sizeof(*ev))
        return;

    ev = (const struct mgmt_ev_new_link_key *)payload;
    if (!same_target(&ev->addr, ev->addr_type, ctx))
        return;

    ctx->report->link_key_seen = 1;
    ctx->report->link_key_type = ev->key_type;
    ctx->report->link_key_pin_length = ev->pin_length;
    ctx->report->link_key_store_hint = ev->store_hint;
}

static int handle_cmd_complete(struct pair_context *ctx, const uint8_t *payload, uint16_t len)
{
    const struct mgmt_ev_cmd_complete *ev;
    uint16_t cmd_opcode;

    if (len < sizeof(*ev))
        return -1;

    ev = (const struct mgmt_ev_cmd_complete *)payload;
    cmd_opcode = le16_to_cpu(ev->opcode);

    if (cmd_opcode == MGMT_OP_PAIR_DEVICE) {
        ctx->report->command_complete_seen = 1;
        ctx->report->mgmt_status = ev->status;

        if (ev->status == MGMT_STATUS_SUCCESS)
            return 1;

        set_failure_from_status(ctx->report, ev->status);
        return 2;
    }

    if (cmd_opcode == MGMT_OP_PIN_CODE_REPLY ||
        cmd_opcode == MGMT_OP_USER_CONFIRM_REPLY ||
        cmd_opcode == MGMT_OP_USER_PASSKEY_REPLY ||
        cmd_opcode == MGMT_OP_PIN_CODE_NEG_REPLY ||
        cmd_opcode == MGMT_OP_USER_CONFIRM_NEG_REPLY ||
        cmd_opcode == MGMT_OP_USER_PASSKEY_NEG_REPLY ||
        cmd_opcode == MGMT_OP_CANCEL_PAIR_DEVICE) {
        if (ev->status != MGMT_STATUS_SUCCESS) {
            set_failure_from_status(ctx->report, ev->status);
            return 2;
        }
    }

    return 0;
}

static int handle_cmd_status(struct pair_context *ctx, const uint8_t *payload, uint16_t len)
{
    const struct mgmt_ev_cmd_status *ev;
    uint16_t cmd_opcode;

    if (len < sizeof(*ev))
        return -1;

    ev = (const struct mgmt_ev_cmd_status *)payload;
    cmd_opcode = le16_to_cpu(ev->opcode);

    if (cmd_opcode == MGMT_OP_PAIR_DEVICE ||
        cmd_opcode == MGMT_OP_PIN_CODE_REPLY ||
        cmd_opcode == MGMT_OP_PIN_CODE_NEG_REPLY ||
        cmd_opcode == MGMT_OP_USER_CONFIRM_REPLY ||
        cmd_opcode == MGMT_OP_USER_CONFIRM_NEG_REPLY ||
        cmd_opcode == MGMT_OP_USER_PASSKEY_REPLY ||
        cmd_opcode == MGMT_OP_USER_PASSKEY_NEG_REPLY ||
        cmd_opcode == MGMT_OP_CANCEL_PAIR_DEVICE) {
        ctx->report->command_status_seen = 1;
        set_failure_from_status(ctx->report, ev->status);
        return 2;
    }

    return 0;
}

int bt_pair_device_full(const char *mac, const bt_pair_options_t *options, bt_pair_report_t *report)
{
    struct pair_context ctx;
    struct pollfd pfd;
    long long deadline_ms;

    if (!mac || !options || !report)
        return -1;

    memset(report, 0, sizeof(*report));
    report->code = BT_PAIR_RESULT_FAILED;
    report->mgmt_status = 0xFF;
    strncpy(report->target_mac, mac, sizeof(report->target_mac) - 1);
    report->target_mac[sizeof(report->target_mac) - 1] = '\0';

    memset(&ctx, 0, sizeof(ctx));
    ctx.options = *options;
    ctx.report = report;

    if (str2ba(mac, &ctx.target_addr) < 0) {
        report->code = BT_PAIR_RESULT_PROTOCOL_ERROR;
        return -1;
    }

    ctx.sock = mgmt_open_socket();
    if (ctx.sock < 0) {
        report->code = BT_PAIR_RESULT_IO_ERROR;
        return -1;
    }

    {
        struct mgmt_cp_pair_device cp;
        memset(&cp, 0, sizeof(cp));
        bacpy(&cp.addr, &ctx.target_addr);
        cp.addr_type = (uint8_t)ctx.options.addr_type;
        cp.io_capability = (uint8_t)ctx.options.io_capability;

        if (mgmt_send_cmd(ctx.sock, MGMT_OP_PAIR_DEVICE,
                          (uint16_t)ctx.options.adapter_index,
                          &cp, sizeof(cp)) < 0) {
            close(ctx.sock);
            report->code = BT_PAIR_RESULT_IO_ERROR;
            return -1;
        }
        ctx.pair_command_sent = 1;
    }

    deadline_ms = monotonic_ms() + ctx.options.timeout_ms;
    pfd.fd = ctx.sock;
    pfd.events = POLLIN;

    for (;;) {
        uint8_t buf[512];
        struct mgmt_hdr *hdr;
        uint16_t opcode;
        uint16_t index;
        uint16_t len;
        int wait_ms;
        int pr;
        ssize_t n;
        int rc;

        wait_ms = (int)(deadline_ms - monotonic_ms());
        if (wait_ms <= 0) {
            report->code = BT_PAIR_RESULT_TIMEOUT;
            break;
        }

        pr = poll(&pfd, 1, wait_ms);
        if (pr < 0) {
            report->code = BT_PAIR_RESULT_IO_ERROR;
            break;
        }

        if (pr == 0) {
            report->code = BT_PAIR_RESULT_TIMEOUT;
            break;
        }

        if (!(pfd.revents & POLLIN)) {
            if (pfd.revents & (POLLERR | POLLHUP | POLLNVAL)) {
                report->code = BT_PAIR_RESULT_IO_ERROR;
                break;
            }
            continue;
        }

        n = read(ctx.sock, buf, sizeof(buf));
        if (n < (ssize_t)sizeof(*hdr))
            continue;

        hdr = (struct mgmt_hdr *)buf;
        opcode = le16_to_cpu(hdr->opcode);
        index = le16_to_cpu(hdr->index);
        len = le16_to_cpu(hdr->len);

        if (index != (uint16_t)ctx.options.adapter_index)
            continue;

        if ((size_t)n < sizeof(*hdr) + len)
            continue;

        switch (opcode) {
        case MGMT_EV_PIN_CODE_REQUEST:
            rc = handle_pin_request(&ctx, buf + sizeof(*hdr), len);
            if (rc < 0) {
                report->code = BT_PAIR_RESULT_IO_ERROR;
                goto done;
            }
            if (rc > 0)
                goto done;
            break;
        case MGMT_EV_USER_CONFIRM_REQUEST:
            rc = handle_confirm_request(&ctx, buf + sizeof(*hdr), len);
            if (rc < 0) {
                report->code = BT_PAIR_RESULT_IO_ERROR;
                goto done;
            }
            if (rc > 0)
                goto done;
            break;
        case MGMT_EV_USER_PASSKEY_REQUEST:
            rc = handle_passkey_request(&ctx, buf + sizeof(*hdr), len);
            if (rc < 0) {
                report->code = BT_PAIR_RESULT_IO_ERROR;
                goto done;
            }
            if (rc > 0)
                goto done;
            break;
        case MGMT_EV_AUTH_FAILED:
            handle_auth_failed(&ctx, buf + sizeof(*hdr), len);
            goto done;
        case MGMT_EV_NEW_LINK_KEY:
            handle_new_link_key(&ctx, buf + sizeof(*hdr), len);
            break;
        case MGMT_EV_CMD_COMPLETE:
            rc = handle_cmd_complete(&ctx, buf + sizeof(*hdr), len);
            if (rc < 0) {
                report->code = BT_PAIR_RESULT_PROTOCOL_ERROR;
                goto done;
            }
            if (rc == 1) {
                if (ctx.options.addr_type == BT_ADDR_BREDR &&
                    ctx.options.require_new_link_key &&
                    !report->link_key_seen) {
                    continue;
                }
                report->code = BT_PAIR_RESULT_SUCCESS;
                goto done;
            }
            if (rc == 2)
                goto done;
            break;
        case MGMT_EV_CMD_STATUS:
            rc = handle_cmd_status(&ctx, buf + sizeof(*hdr), len);
            if (rc < 0) {
                report->code = BT_PAIR_RESULT_PROTOCOL_ERROR;
                goto done;
            }
            if (rc == 2)
                goto done;
            break;
        default:
            break;
        }
    }

done:
    close(ctx.sock);
    return report->code == BT_PAIR_RESULT_SUCCESS ? 0 : -1;
}
