
#include <stdio.h>
int bt_sdp_register_ag(unsigned char ch){
    printf("SDP registered channel %d\n", ch);
    return 0;
}
