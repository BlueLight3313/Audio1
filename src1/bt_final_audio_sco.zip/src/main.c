
#include <stdio.h>

int bt_sco_connect(const char*);
int bt_audio_start(int);

int main(){
    const char *mac="00:11:22:33:44:55";

    int sco=bt_sco_connect(mac);
    if(sco<0) return -1;

    printf("SCO connected\n");

    bt_audio_start(sco);

    getchar();
    return 0;
}
