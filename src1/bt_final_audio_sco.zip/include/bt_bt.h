
#ifndef BT_BT_H
#define BT_BT_H
#define AF_BLUETOOTH 31
#define BTPROTO_SCO 2
struct sockaddr_sco {
    unsigned short sco_family;
    unsigned char sco_bdaddr[6];
};
#endif
