#include "bt_classify.h"

bt_remote_type_t bt_classify_cod(const uint8_t cod[3])
{
    uint8_t major;

    if (cod == 0) {
        return BT_REMOTE_UNKNOWN;
    }

    major = (uint8_t)((cod[1] >> 2) & 0x1F);

    switch (major) {
        case 0x01:
            return BT_REMOTE_COMPUTER;
        case 0x02:
            return BT_REMOTE_PHONE;
        case 0x04:
            return BT_REMOTE_AUDIO;
        default:
            return BT_REMOTE_UNKNOWN;
    }
}

bt_pair_policy_t bt_recommend_policy(bt_remote_type_t type)
{
    switch (type) {
        case BT_REMOTE_AUDIO:
            return BT_PAIR_AUTO;
        case BT_REMOTE_PHONE:
            return BT_PAIR_PIN_CONFIRM;
        case BT_REMOTE_COMPUTER:
            return BT_PAIR_CONFIRM;
        default:
            return BT_PAIR_CONFIRM;
    }
}

const char *bt_type_str(bt_remote_type_t type)
{
    switch (type) {
        case BT_REMOTE_AUDIO:
            return "audio";
        case BT_REMOTE_PHONE:
            return "phone";
        case BT_REMOTE_COMPUTER:
            return "computer";
        default:
            return "unknown";
    }
}

const char *bt_policy_str(bt_pair_policy_t policy)
{
    switch (policy) {
        case BT_PAIR_AUTO:
            return "auto";
        case BT_PAIR_CONFIRM:
            return "confirm";
        case BT_PAIR_PIN_CONFIRM:
            return "pin+confirm";
        default:
            return "unknown";
    }
}
