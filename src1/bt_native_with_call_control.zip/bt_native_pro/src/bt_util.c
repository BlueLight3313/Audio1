#include "bt_defs.h"
#include "bt_util.h"

uint16_t bt_cpu_to_le16(uint16_t value)
{
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    return value;
#else
    return (uint16_t)((value >> 8) | (value << 8));
#endif
}

uint16_t bt_le16_to_cpu(uint16_t value)
{
    return bt_cpu_to_le16(value);
}

void bt_format_bdaddr(const struct bt_bdaddr *addr, char *out, size_t out_size)
{
    snprintf(out, out_size,
             "%02X:%02X:%02X:%02X:%02X:%02X",
             addr->b[5], addr->b[4], addr->b[3], addr->b[2], addr->b[1], addr->b[0]);
}

const char *bt_scan_enable_to_string(uint8_t value)
{
    switch (value) {
        case SCAN_DISABLED: return "disabled";
        case SCAN_INQUIRY:  return "inquiry-only";
        case SCAN_PAGE:     return "page-only";
        case SCAN_BOTH:     return "inquiry+page";
        default:            return "unknown";
    }
}

void bt_format_flags(uint32_t flags, char *out, size_t out_size)
{
    struct flag_name {
        uint32_t bit;
        const char *name;
    } table[] = {
        { 1u << HCI_UP, "UP" },
        { 1u << HCI_RUNNING, "RUNNING" },
        { 1u << HCI_PSCAN, "PSCAN" },
        { 1u << HCI_ISCAN, "ISCAN" },
        { 1u << HCI_INQUIRY, "INQUIRY" },
        { 1u << HCI_RAW, "RAW" },
        { 1u << HCI_SSP_ENABLED, "SSP" },
        { 1u << HCI_LE_ENABLED, "LE" },
        { 1u << HCI_CONNECTABLE, "CONNECTABLE" },
        { 1u << HCI_DISCOVERABLE, "DISCOVERABLE" },
    };

    size_t i;
    bool first;
    int written;
    size_t used;

    if (out_size == 0) {
        return;
    }

    out[0] = '\0';
    used = 0;
    first = true;

    for (i = 0; i < sizeof(table) / sizeof(table[0]); ++i) {
        if ((flags & table[i].bit) == 0) {
            continue;
        }

        written = snprintf(out + used, out_size - used, "%s%s", first ? "" : "|", table[i].name);
        if (written < 0 || (size_t)written >= out_size - used) {
            break;
        }
        used += (size_t)written;
        first = false;
    }

    if (first) {
        snprintf(out, out_size, "none");
    }
}
