
#ifndef BT_ADAPTER_H
#define BT_ADAPTER_H

int bt_hci_open();
int bt_hci_bind(int sock, int dev_id);
int bt_adapter_check(int sock, int dev_id);
int bt_adapter_up(int sock, int dev_id);
int bt_adapter_down(int sock, int dev_id);
int bt_set_discoverable(int sock);

#endif
