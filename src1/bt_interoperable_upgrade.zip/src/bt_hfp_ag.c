
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int bt_sco_connect(unsigned char*);
int bt_audio_start(int);

static int call_active=0;

void bt_hfp_ag_run(int fd, unsigned char *mac){
    char buf[256];
    int sco=-1;

    while(1){
        int n = read(fd,buf,sizeof(buf)-1);
        if(n<=0) break;
        buf[n]=0;

        if(!strncmp(buf,"AT+BRSF",7)){
            write(fd,"+BRSF:20\r\nOK\r\n",18);
        }
        else if(!strncmp(buf,"AT+CIND=?",9)){
            write(fd,"+CIND:(\"call\",(0,1))\r\nOK\r\n",30);
        }
        else if(!strncmp(buf,"AT+CIND?",8)){
            write(fd,"+CIND:0\r\nOK\r\n",16);
        }
        else if(!strncmp(buf,"AT+CMER",7)){
            write(fd,"OK\r\n",4);
        }
        else if(!strncmp(buf,"ATA",3)){
            write(fd,"OK\r\n",4);
            call_active=1;
            if(sco<0){
                sco = bt_sco_connect(mac);
                bt_audio_start(sco);
            }
        }
        else if(!strncmp(buf,"AT+CHUP",7)){
            write(fd,"OK\r\n",4);
            call_active=0;
        }
        else{
            write(fd,"OK\r\n",4);
        }
    }
}
