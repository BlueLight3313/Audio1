#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

#include "bt_defs.h"
#include "bt_types.h"
#include "bt_hci.h"
#include "bt_adapter.h"
#include "bt_pair.h"
#include "bt_log.h"

static struct bt_bond_record g_bond_cache[BT_BOND_CACHE_CAPACITY];
static size_t g_bond_count = 0;

struct bt_pair_session {
    const struct bt_device_record *device;
    bt_pair_profile_t profile;
    const char *pin_code;
    uint16_t conn_handle;
    uint8_t have_conn_handle;
    uint8_t saw_pin_request;
    uint8_t saw_user_confirm_request;
    uint8_t saw_user_passkey_request;
    uint8_t saw_simple_pairing_complete;
    uint8_t saw_auth_complete;
    uint8_t paired;
    uint8_t failed;
    uint8_t failure_status;
    uint8_t link_key_received;
};

static int bt_bdaddr_equal_pair(const bt_bdaddr_t *a, const bt_bdaddr_t *b)
{
    return memcmp(a->b, b->b, 6) == 0;
}

static int bt_pair_prompt_yes_no(const char *prompt)
{
    char line[32];
    printf("%s [y/N]: ", prompt);
    fflush(stdout);
    if (fgets(line, sizeof(line), stdin) == NULL) {
        return 0;
    }
    return line[0] == 'y' || line[0] == 'Y';
}

static int bt_pair_prompt_passkey(char *out_pin, size_t out_pin_size)
{
    char line[64];
    size_t len;

    if (out_pin == NULL || out_pin_size < 2) {
        return -1;
    }

    printf("Enter pairing PIN/passkey: ");
    fflush(stdout);
    if (fgets(line, sizeof(line), stdin) == NULL) {
        return -1;
    }

    len = strcspn(line, "\r\n");
    line[len] = '\0';
    if (len == 0 || len >= out_pin_size) {
        return -1;
    }

    memcpy(out_pin, line, len + 1);
    return 0;
}

void bt_bond_cache_clear(void)
{
    memset(g_bond_cache, 0, sizeof(g_bond_cache));
    g_bond_count = 0;
}

size_t bt_bond_cache_count(void)
{
    return g_bond_count;
}

const struct bt_bond_record *bt_bond_cache_get_const(size_t index)
{
    if (index >= g_bond_count) {
        return NULL;
    }
    return &g_bond_cache[index];
}

const struct bt_bond_record *bt_bond_cache_find(const bt_bdaddr_t *bdaddr)
{
    size_t i;
    if (bdaddr == NULL) {
        return NULL;
    }
    for (i = 0; i < g_bond_count; ++i) {
        if (bt_bdaddr_equal_pair(&g_bond_cache[i].bdaddr, bdaddr)) {
            return &g_bond_cache[i];
        }
    }
    return NULL;
}

static struct bt_bond_record *bt_bond_cache_get_or_add(const struct bt_device_record *device)
{
    size_t i;

    if (device == NULL) {
        return NULL;
    }

    for (i = 0; i < g_bond_count; ++i) {
        if (bt_bdaddr_equal_pair(&g_bond_cache[i].bdaddr, &device->bdaddr)) {
            return &g_bond_cache[i];
        }
    }

    if (g_bond_count >= BT_BOND_CACHE_CAPACITY) {
        return NULL;
    }

    g_bond_cache[g_bond_count].bdaddr = device->bdaddr;
    memcpy(g_bond_cache[g_bond_count].address_text, device->address_text, sizeof(g_bond_cache[g_bond_count].address_text));
    if (device->has_name) {
        strncpy(g_bond_cache[g_bond_count].name, device->name, sizeof(g_bond_cache[g_bond_count].name) - 1);
        g_bond_cache[g_bond_count].has_name = 1;
    }
    ++g_bond_count;
    return &g_bond_cache[g_bond_count - 1];
}

static void bt_bond_cache_store_key(const struct bt_device_record *device, const uint8_t link_key[16], uint8_t key_type)
{
    struct bt_bond_record *bond = bt_bond_cache_get_or_add(device);
    if (bond == NULL) {
        bt_log_warn("Bond cache full; link key will not be stored");
        return;
    }
    memcpy(bond->link_key, link_key, 16);
    bond->link_key_type = key_type;
    bond->has_link_key = 1;
}

void bt_bond_cache_print(void)
{
    size_t i;

    if (g_bond_count == 0) {
        printf("No paired devices stored.\n");
        return;
    }

    printf("Stored bonds: %lu\n", (unsigned long)g_bond_count);
    for (i = 0; i < g_bond_count; ++i) {
        printf("%3lu. %s | %s | key=%s\n",
               (unsigned long)(i + 1),
               g_bond_cache[i].address_text,
               g_bond_cache[i].has_name ? g_bond_cache[i].name : "<unknown>",
               g_bond_cache[i].has_link_key ? "yes" : "no");
    }
}

int bt_pair_enable_secure_simple_pairing(int hci_sock, uint8_t enable)
{
    struct bt_hci_cp_write_simple_pairing_mode cp;
    cp.mode = enable ? 1 : 0;
    return bt_hci_send_req(
        hci_sock,
        BT_HCI_OPCODE(BT_OGF_CTRL_BASEBAND, BT_OCF_WRITE_SIMPLE_PAIRING_MODE),
        &cp,
        sizeof(cp),
        NULL,
        0,
        2000
    );
}

static int bt_pair_send_link_key_reply(int hci_sock, const bt_bdaddr_t *bdaddr, const uint8_t link_key[16])
{
    struct bt_hci_cp_link_key_reply cp;
    memset(&cp, 0, sizeof(cp));
    cp.bdaddr = *bdaddr;
    memcpy(cp.link_key, link_key, 16);
    return bt_hci_send_req(hci_sock, BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_LINK_KEY_REPLY), &cp, sizeof(cp), NULL, 0, 2000);
}

static int bt_pair_send_link_key_negative_reply(int hci_sock, const bt_bdaddr_t *bdaddr)
{
    struct bt_hci_cp_link_key_neg_reply cp;
    memset(&cp, 0, sizeof(cp));
    cp.bdaddr = *bdaddr;
    return bt_hci_send_req(hci_sock, BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_LINK_KEY_NEG_REPLY), &cp, sizeof(cp), NULL, 0, 2000);
}

static int bt_pair_send_pin_code_reply(int hci_sock, const bt_bdaddr_t *bdaddr, const char *pin)
{
    struct bt_hci_cp_pin_code_reply cp;
    size_t pin_len;
    memset(&cp, 0, sizeof(cp));
    cp.bdaddr = *bdaddr;
    pin_len = strlen(pin);
    if (pin_len == 0 || pin_len > 16) {
        errno = EINVAL;
        return -1;
    }
    cp.pin_len = (uint8_t)pin_len;
    memcpy(cp.pin_code, pin, pin_len);
    return bt_hci_send_req(hci_sock, BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_PIN_CODE_REPLY), &cp, sizeof(cp), NULL, 0, 2000);
}

static int bt_pair_send_pin_code_negative_reply(int hci_sock, const bt_bdaddr_t *bdaddr)
{
    struct bt_hci_cp_pin_code_neg_reply cp;
    memset(&cp, 0, sizeof(cp));
    cp.bdaddr = *bdaddr;
    return bt_hci_send_req(hci_sock, BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_PIN_CODE_NEG_REPLY), &cp, sizeof(cp), NULL, 0, 2000);
}

static int bt_pair_send_io_capability_reply(int hci_sock, const bt_bdaddr_t *bdaddr, uint8_t io_capability, uint8_t auth_requirements)
{
    struct bt_hci_cp_io_capability_reply cp;
    memset(&cp, 0, sizeof(cp));
    cp.bdaddr = *bdaddr;
    cp.io_capability = io_capability;
    cp.oob_data_present = 0x00;
    cp.authentication_requirements = auth_requirements;
    return bt_hci_send_req(hci_sock, BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_IO_CAPABILITY_REPLY), &cp, sizeof(cp), NULL, 0, 2000);
}

static int bt_pair_send_user_confirm_reply(int hci_sock, const bt_bdaddr_t *bdaddr, int accept)
{
    if (accept) {
        struct bt_hci_cp_user_confirm_reply cp;
        memset(&cp, 0, sizeof(cp));
        cp.bdaddr = *bdaddr;
        return bt_hci_send_req(hci_sock, BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_USER_CONFIRM_REPLY), &cp, sizeof(cp), NULL, 0, 2000);
    }
    else {
        struct bt_hci_cp_user_confirm_neg_reply cp;
        memset(&cp, 0, sizeof(cp));
        cp.bdaddr = *bdaddr;
        return bt_hci_send_req(hci_sock, BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_USER_CONFIRM_NEG_REPLY), &cp, sizeof(cp), NULL, 0, 2000);
    }
}

static int bt_pair_send_user_passkey_reply(int hci_sock, const bt_bdaddr_t *bdaddr, const char *pin)
{
    struct bt_hci_cp_user_passkey_reply cp;
    char *endp;
    unsigned long value;
    memset(&cp, 0, sizeof(cp));
    cp.bdaddr = *bdaddr;
    value = strtoul(pin, &endp, 10);
    if (pin[0] == '\0' || *endp != '\0' || value > 999999UL) {
        errno = EINVAL;
        return -1;
    }
    cp.passkey = (uint32_t)value;
    return bt_hci_send_req(hci_sock, BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_USER_PASSKEY_REPLY), &cp, sizeof(cp), NULL, 0, 2000);
}

static int bt_pair_send_user_passkey_negative_reply(int hci_sock, const bt_bdaddr_t *bdaddr)
{
    struct bt_hci_cp_user_passkey_neg_reply cp;
    memset(&cp, 0, sizeof(cp));
    cp.bdaddr = *bdaddr;
    return bt_hci_send_req(hci_sock, BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_USER_PASSKEY_NEG_REPLY), &cp, sizeof(cp), NULL, 0, 2000);
}

static int bt_pair_send_remote_oob_negative_reply(int hci_sock, const bt_bdaddr_t *bdaddr)
{
    struct bt_hci_cp_remote_oob_data_neg_reply cp;
    memset(&cp, 0, sizeof(cp));
    cp.bdaddr = *bdaddr;
    return bt_hci_send_req(hci_sock, BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_REMOTE_OOB_DATA_NEG_REPLY), &cp, sizeof(cp), NULL, 0, 2000);
}

static int bt_pair_send_auth_requested(int hci_sock, uint16_t handle)
{
    struct bt_hci_cp_auth_requested cp;
    memset(&cp, 0, sizeof(cp));
    cp.handle = bt_hci_cpu_to_le16(handle);
    return bt_hci_send_req(hci_sock, BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_AUTH_REQUESTED), &cp, sizeof(cp), NULL, 0, 2000);
}

static int bt_pair_create_connection(int hci_sock, const struct bt_device_record *device)
{
    struct bt_hci_cp_create_conn cp;
    struct bt_hci_ev_cmd_status status_rsp;
    uint8_t pscan;

    memset(&cp, 0, sizeof(cp));
    cp.bdaddr = device->bdaddr;
    cp.pkt_type = bt_hci_cpu_to_le16(0xCC18);
    pscan = device->page_scan_rep_mode != 0 ? device->page_scan_rep_mode : 0x01;
    cp.page_scan_rep_mode = pscan;
    cp.reserved = 0x00;
    cp.clock_offset = bt_hci_cpu_to_le16(device->clock_offset);
    cp.allow_role_switch = 0x01;
    memset(&status_rsp, 0, sizeof(status_rsp));

    return bt_hci_send_req(
        hci_sock,
        BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_CREATE_CONN),
        &cp,
        sizeof(cp),
        &status_rsp,
        sizeof(status_rsp),
        5000
    );
}

static void bt_pair_get_policy(bt_pair_profile_t profile, uint8_t *io_capability, uint8_t *auth_requirements)
{
    switch (profile) {
        case BT_PAIR_PROFILE_AUDIO_ONLY:
            *io_capability = BT_PAIR_IO_NO_INPUT_OUTPUT;
            *auth_requirements = BT_PAIR_AUTH_GENERAL_BONDING;
            break;
        case BT_PAIR_PROFILE_SMART_HEADSET:
            *io_capability = BT_PAIR_IO_DISPLAY_YES_NO;
            *auth_requirements = BT_PAIR_AUTH_MITM_GENERAL_BOND;
            break;
        case BT_PAIR_PROFILE_SMARTPHONE:
        default:
            *io_capability = BT_PAIR_IO_KEYBOARD_DISPLAY;
            *auth_requirements = BT_PAIR_AUTH_MITM_GENERAL_BOND;
            break;
    }
}

static int bt_pair_wait_for_result(int hci_sock, struct bt_pair_session *session)
{
    struct hci_filter old_filter;
    struct hci_filter filter;
    socklen_t optlen;
    struct timeval tv;
    uint8_t rxbuf[BT_MAX_HCI_EVENT_SIZE];

    memset(&filter, 0, sizeof(filter));
    bt_hci_filter_set_bit(BT_HCI_EVENT_PKT, &filter.type_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_CONN_COMPLETE, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_DISCONN_COMPLETE, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_AUTH_COMPLETE, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_LINK_KEY_REQ, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_LINK_KEY_NOTIFY, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_PIN_CODE_REQ, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_IO_CAPABILITY_REQUEST, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_USER_CONFIRM_REQUEST, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_USER_PASSKEY_REQUEST, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_REMOTE_OOB_DATA_REQUEST, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_SIMPLE_PAIRING_COMPLETE, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_CMD_STATUS, filter.event_mask);
    bt_hci_filter_set_bit(BT_HCI_EV_CMD_COMPLETE, filter.event_mask);

    optlen = sizeof(old_filter);
    if (getsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, &optlen) < 0) {
        return -1;
    }
    if (setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &filter, sizeof(filter)) < 0) {
        return -1;
    }

    tv.tv_sec = 30;
    tv.tv_usec = 0;
    if (setsockopt(hci_sock, BT_SOL_SOCKET, BT_SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
        setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
        return -1;
    }

    while (!session->paired && !session->failed) {
        ssize_t n = read(hci_sock, rxbuf, sizeof(rxbuf));
        struct hci_event_hdr *eh;
        uint8_t *payload;

        if (n < 0) {
            session->failed = 1;
            break;
        }
        if (n < 1 + (ssize_t)sizeof(struct hci_event_hdr)) {
            continue;
        }
        if (rxbuf[0] != BT_HCI_EVENT_PKT) {
            continue;
        }

        eh = (struct hci_event_hdr *)(rxbuf + 1);
        payload = rxbuf + 1 + sizeof(struct hci_event_hdr);

        if (eh->evt == BT_HCI_EV_CONN_COMPLETE) {
            struct bt_hci_ev_conn_complete *cc;
            if (eh->plen < sizeof(*cc)) {
                continue;
            }
            cc = (struct bt_hci_ev_conn_complete *)payload;
            if (!bt_bdaddr_equal_pair(&cc->bdaddr, &session->device->bdaddr)) {
                continue;
            }
            if (cc->status != 0x00) {
                session->failed = 1;
                session->failure_status = cc->status;
                continue;
            }
            session->conn_handle = bt_hci_le16_to_cpu(cc->handle);
            session->have_conn_handle = 1;
            bt_log_info("ACL connection established; requesting authentication");
            if (bt_pair_send_auth_requested(hci_sock, session->conn_handle) < 0) {
                session->failed = 1;
            }
            continue;
        }

        if (eh->evt == BT_HCI_EV_LINK_KEY_REQ) {
            struct bt_hci_ev_link_key_req *req;
            const struct bt_bond_record *bond;
            if (eh->plen < sizeof(*req)) {
                continue;
            }
            req = (struct bt_hci_ev_link_key_req *)payload;
            if (!bt_bdaddr_equal_pair(&req->bdaddr, &session->device->bdaddr)) {
                continue;
            }
            bond = bt_bond_cache_find(&req->bdaddr);
            if (bond != NULL && bond->has_link_key) {
                bt_log_info("Link key request received; replying from bond cache");
                if (bt_pair_send_link_key_reply(hci_sock, &req->bdaddr, bond->link_key) < 0) {
                    session->failed = 1;
                }
            } else {
                bt_log_info("Link key request received; forcing fresh pairing");
                if (bt_pair_send_link_key_negative_reply(hci_sock, &req->bdaddr) < 0) {
                    session->failed = 1;
                }
            }
            continue;
        }

        if (eh->evt == BT_HCI_EV_PIN_CODE_REQ) {
            struct bt_hci_ev_pin_code_req *req;
            char pin_buf[32];
            const char *pin_to_use = session->pin_code;
            if (eh->plen < sizeof(*req)) {
                continue;
            }
            req = (struct bt_hci_ev_pin_code_req *)payload;
            if (!bt_bdaddr_equal_pair(&req->bdaddr, &session->device->bdaddr)) {
                continue;
            }
            session->saw_pin_request = 1;
            bt_log_info("PIN code request received");
            if (pin_to_use == NULL && session->profile == BT_PAIR_PROFILE_SMARTPHONE) {
                if (bt_pair_prompt_passkey(pin_buf, sizeof(pin_buf)) == 0) {
                    pin_to_use = pin_buf;
                }
            }
            if (pin_to_use != NULL) {
                if (bt_pair_send_pin_code_reply(hci_sock, &req->bdaddr, pin_to_use) < 0) {
                    session->failed = 1;
                }
            } else {
                bt_log_warn("No PIN configured for this pairing profile; rejecting PIN code request");
                bt_pair_send_pin_code_negative_reply(hci_sock, &req->bdaddr);
                session->failed = 1;
            }
            continue;
        }

        if (eh->evt == BT_HCI_EV_IO_CAPABILITY_REQUEST) {
            struct bt_hci_ev_io_capability_request *req;
            uint8_t io_capability;
            uint8_t auth_requirements;
            if (eh->plen < sizeof(*req)) {
                continue;
            }
            req = (struct bt_hci_ev_io_capability_request *)payload;
            if (!bt_bdaddr_equal_pair(&req->bdaddr, &session->device->bdaddr)) {
                continue;
            }
            bt_pair_get_policy(session->profile, &io_capability, &auth_requirements);
            bt_log_info("IO capability request received");
            if (bt_pair_send_io_capability_reply(hci_sock, &req->bdaddr, io_capability, auth_requirements) < 0) {
                session->failed = 1;
            }
            continue;
        }

        if (eh->evt == BT_HCI_EV_USER_CONFIRM_REQUEST) {
            struct bt_hci_ev_user_confirm_request *req;
            int accept = 0;
            unsigned long numeric_value;
            char prompt[128];
            if (eh->plen < sizeof(*req)) {
                continue;
            }
            req = (struct bt_hci_ev_user_confirm_request *)payload;
            if (!bt_bdaddr_equal_pair(&req->bdaddr, &session->device->bdaddr)) {
                continue;
            }
            session->saw_user_confirm_request = 1;
            numeric_value = (unsigned long)req->numeric_value;
            if (session->profile == BT_PAIR_PROFILE_AUDIO_ONLY) {
                accept = 1;
            } else {
                snprintf(prompt, sizeof(prompt), "Confirm pairing with %s numeric value %06lu", session->device->address_text, numeric_value);
                accept = bt_pair_prompt_yes_no(prompt);
            }
            if (bt_pair_send_user_confirm_reply(hci_sock, &req->bdaddr, accept) < 0) {
                session->failed = 1;
            }
            if (!accept) {
                session->failed = 1;
            }
            continue;
        }

        if (eh->evt == BT_HCI_EV_USER_PASSKEY_REQUEST) {
            struct bt_hci_ev_user_passkey_request *req;
            char pin_buf[32];
            const char *pin_to_use = session->pin_code;
            if (eh->plen < sizeof(*req)) {
                continue;
            }
            req = (struct bt_hci_ev_user_passkey_request *)payload;
            if (!bt_bdaddr_equal_pair(&req->bdaddr, &session->device->bdaddr)) {
                continue;
            }
            session->saw_user_passkey_request = 1;
            bt_log_info("User passkey request received");
            if (pin_to_use == NULL && session->profile == BT_PAIR_PROFILE_SMARTPHONE) {
                if (bt_pair_prompt_passkey(pin_buf, sizeof(pin_buf)) == 0) {
                    pin_to_use = pin_buf;
                }
            }
            if (pin_to_use != NULL) {
                if (bt_pair_send_user_passkey_reply(hci_sock, &req->bdaddr, pin_to_use) < 0) {
                    session->failed = 1;
                }
            } else {
                bt_pair_send_user_passkey_negative_reply(hci_sock, &req->bdaddr);
                session->failed = 1;
            }
            continue;
        }

        if (eh->evt == BT_HCI_EV_REMOTE_OOB_DATA_REQUEST) {
            struct bt_hci_ev_io_capability_request *req;
            if (eh->plen < sizeof(*req)) {
                continue;
            }
            req = (struct bt_hci_ev_io_capability_request *)payload;
            if (!bt_bdaddr_equal_pair(&req->bdaddr, &session->device->bdaddr)) {
                continue;
            }
            bt_log_warn("Remote requested OOB data; rejecting because OOB is not implemented");
            if (bt_pair_send_remote_oob_negative_reply(hci_sock, &req->bdaddr) < 0) {
                session->failed = 1;
            }
            continue;
        }

        if (eh->evt == BT_HCI_EV_LINK_KEY_NOTIFY) {
            struct bt_hci_ev_link_key_notify *ev;
            if (eh->plen < sizeof(*ev)) {
                continue;
            }
            ev = (struct bt_hci_ev_link_key_notify *)payload;
            if (!bt_bdaddr_equal_pair(&ev->bdaddr, &session->device->bdaddr)) {
                continue;
            }
            bt_log_info("Link key notification received; storing bond");
            bt_bond_cache_store_key(session->device, ev->link_key, ev->key_type);
            session->link_key_received = 1;
            continue;
        }

        if (eh->evt == BT_HCI_EV_SIMPLE_PAIRING_COMPLETE) {
            struct bt_hci_ev_simple_pairing_complete *ev;
            if (eh->plen < sizeof(*ev)) {
                continue;
            }
            ev = (struct bt_hci_ev_simple_pairing_complete *)payload;
            if (!bt_bdaddr_equal_pair(&ev->bdaddr, &session->device->bdaddr)) {
                continue;
            }
            session->saw_simple_pairing_complete = 1;
            if (ev->status != 0x00) {
                session->failed = 1;
                session->failure_status = ev->status;
                continue;
            }
            continue;
        }

        if (eh->evt == BT_HCI_EV_AUTH_COMPLETE) {
            struct bt_hci_ev_auth_complete *ev;
            if (eh->plen < sizeof(*ev)) {
                continue;
            }
            ev = (struct bt_hci_ev_auth_complete *)payload;
            if (!session->have_conn_handle || bt_hci_le16_to_cpu(ev->handle) != session->conn_handle) {
                continue;
            }
            session->saw_auth_complete = 1;
            if (ev->status != 0x00) {
                session->failed = 1;
                session->failure_status = ev->status;
                continue;
            }
            if (session->profile == BT_PAIR_PROFILE_SMARTPHONE) {
                if (!session->saw_pin_request && !session->saw_user_passkey_request) {
                    bt_log_warn("Smartphone policy expected PIN/passkey, but remote completed pairing without requesting one");
                    session->failed = 1;
                    continue;
                }
                if (!session->saw_user_confirm_request) {
                    bt_log_warn("Smartphone policy expected confirmation, but remote completed pairing without it");
                    session->failed = 1;
                    continue;
                }
            }
            if (session->profile == BT_PAIR_PROFILE_SMART_HEADSET && !session->saw_user_confirm_request) {
                bt_log_warn("Smart headset policy expected confirmation, but remote completed pairing without it");
                session->failed = 1;
                continue;
            }
            session->paired = 1;
            continue;
        }

        if (eh->evt == BT_HCI_EV_DISCONN_COMPLETE) {
            struct bt_hci_ev_disconn_complete *ev;
            if (eh->plen < sizeof(*ev)) {
                continue;
            }
            ev = (struct bt_hci_ev_disconn_complete *)payload;
            if (session->have_conn_handle && bt_hci_le16_to_cpu(ev->handle) == session->conn_handle) {
                session->failed = 1;
                session->failure_status = ev->reason;
                continue;
            }
        }
    }

    setsockopt(hci_sock, BT_SOL_HCI, BT_HCI_FILTER, &old_filter, sizeof(old_filter));
    if (session->paired) {
        return 0;
    }
    errno = EIO;
    return -1;
}

int bt_pair_device(int hci_sock, const struct bt_device_record *device, bt_pair_profile_t profile, const char *pin_code)
{
    struct bt_pair_session session;

    if (device == NULL) {
        errno = EINVAL;
        return -1;
    }

    memset(&session, 0, sizeof(session));
    session.device = device;
    session.profile = profile;
    session.pin_code = pin_code;

    if (bt_pair_enable_secure_simple_pairing(hci_sock, 1) < 0) {
        if (profile == BT_PAIR_PROFILE_AUDIO_ONLY) {
            bt_log_warn("Failed to enable Secure Simple Pairing mode; continuing anyway");
        } else {
            return -1;
        }
    }

    bt_log_info("Pairing started with %s (%s)", device->address_text, device->has_name ? device->name : "<unknown>");
    if (bt_pair_create_connection(hci_sock, device) < 0) {
        return -1;
    }
    if (bt_pair_wait_for_result(hci_sock, &session) < 0) {
        if (session.failure_status != 0) {
            bt_log_error("Pairing failed with status/reason 0x%02X", session.failure_status);
        }
        return -1;
    }

    bt_log_info("Pairing completed successfully");
    return 0;
}
