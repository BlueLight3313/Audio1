
#include <stdio.h>
#include "bt_audio.h"

int main(){
    printf("start audio...\n");
    bt_audio_start();

    getchar();

    bt_audio_stop();
    return 0;
}
