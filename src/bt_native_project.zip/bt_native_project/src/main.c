#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bt_native.h"

static void usage(const char *prog)
{
    printf("Usage:\n");
    printf("  %s check [adapter]\n", prog);
    printf("  %s scan [adapter] [seconds]\n", prog);
    printf("  %s pair <MAC> [adapter]\n", prog);
    printf("  %s connect <MAC>\n", prog);
    printf("  %s connections [adapter]\n", prog);
}

int main(int argc, char **argv)
{
    int adapter = 0;

    if (argc < 2) {
        usage(argv[0]);
        return 1;
    }

    if (strcmp(argv[1], "check") == 0) {
        bt_result_t r;
        if (argc >= 3)
            adapter = atoi(argv[2]);

        r = bt_adapter_check(adapter);
        printf("CHECK: %s, mgmt_status=0x%02X\n",
               bt_status_str(r.status), r.mgmt_status & 0xFF);
        return r.status == BT_OK ? 0 : 1;
    }

    if (strcmp(argv[1], "scan") == 0) {
        bt_result_t r;
        int seconds = 8;
        if (argc >= 3)
            adapter = atoi(argv[2]);
        if (argc >= 4)
            seconds = atoi(argv[3]);

        r = bt_scan_classic(adapter, seconds);
        printf("SCAN: %s, found=%d, mgmt_status=0x%02X\n",
               bt_status_str(r.status), r.found_count, r.mgmt_status & 0xFF);
        return r.status == BT_OK ? 0 : 1;
    }

    if (strcmp(argv[1], "pair") == 0) {
        bt_result_t r;
        if (argc < 3) {
            usage(argv[0]);
            return 1;
        }
        if (argc >= 4)
            adapter = atoi(argv[3]);

        r = bt_pair_classic_justworks(adapter, argv[2]);
        printf("PAIR: %s, mgmt_status=0x%02X\n",
               bt_status_str(r.status), r.mgmt_status & 0xFF);
        return r.status == BT_OK ? 0 : 1;
    }

    if (strcmp(argv[1], "connect") == 0) {
        bt_result_t r;
        if (argc < 3) {
            usage(argv[0]);
            return 1;
        }

        r = bt_connect_classic_sdp(argv[2]);
        printf("CONNECT: %s\n", bt_status_str(r.status));
        return r.status == BT_OK ? 0 : 1;
    }

    if (strcmp(argv[1], "connections") == 0) {
        bt_result_t r;
        if (argc >= 3)
            adapter = atoi(argv[2]);

        r = bt_list_connected(adapter);
        printf("CONNECTIONS: %s, count=%d, mgmt_status=0x%02X\n",
               bt_status_str(r.status), r.connected_count, r.mgmt_status & 0xFF);
        return r.status == BT_OK ? 0 : 1;
    }

    usage(argv[0]);
    return 1;
}
