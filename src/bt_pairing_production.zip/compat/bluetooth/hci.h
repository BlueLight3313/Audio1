#ifndef BT_COMPAT_HCI_H
#define BT_COMPAT_HCI_H

#include <stdint.h>
#include <sys/socket.h>

#define HCI_DEV_NONE 0xFFFF
#define HCI_CHANNEL_CONTROL 3

struct sockaddr_hci {
    sa_family_t hci_family;
    uint16_t hci_dev;
    uint16_t hci_channel;
};

#endif
