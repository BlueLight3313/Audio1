
#ifndef BT_TYPES_H
#define BT_TYPES_H
#include <stdint.h>
typedef struct { uint8_t b[6]; } bt_bdaddr_t;
#endif
