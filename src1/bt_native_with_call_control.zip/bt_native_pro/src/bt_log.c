#include "bt_log.h"

static void bt_log_write(const char *level, const char *fmt, va_list args)
{
    char timestamp[64];
    time_t now;
    struct tm tm_now;

    now = time(NULL);
    localtime_r(&now, &tm_now);
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", &tm_now);

    fprintf(stdout, "%s [%s] ", timestamp, level);
    vfprintf(stdout, fmt, args);
    fputc('\n', stdout);
    fflush(stdout);
}

void bt_log_info(const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    bt_log_write("INFO", fmt, args);
    va_end(args);
}

void bt_log_warn(const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    bt_log_write("WARN", fmt, args);
    va_end(args);
}

void bt_log_error(const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    bt_log_write("ERROR", fmt, args);
    va_end(args);
}
