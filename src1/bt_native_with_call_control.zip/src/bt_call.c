#include <errno.h>
#include <stdio.h>
#include <string.h>

#include "bt_adapter.h"
#include "bt_call.h"
#include "bt_log.h"

static struct bt_call_session g_call;

static int bt_call_parse_bdaddr_text(const char *text, bt_bdaddr_t *out_bdaddr)
{
    unsigned int b5;
    unsigned int b4;
    unsigned int b3;
    unsigned int b2;
    unsigned int b1;
    unsigned int b0;

    if (text == NULL || out_bdaddr == NULL) {
        errno = EINVAL;
        return -1;
    }

    if (sscanf(
            text,
            "%02x:%02x:%02x:%02x:%02x:%02x",
            &b5,
            &b4,
            &b3,
            &b2,
            &b1,
            &b0) != 6) {
        errno = EINVAL;
        return -1;
    }

    out_bdaddr->b[5] = (unsigned char)b5;
    out_bdaddr->b[4] = (unsigned char)b4;
    out_bdaddr->b[3] = (unsigned char)b3;
    out_bdaddr->b[2] = (unsigned char)b2;
    out_bdaddr->b[1] = (unsigned char)b1;
    out_bdaddr->b[0] = (unsigned char)b0;

    return 0;
}

static void bt_call_set_remote(const bt_bdaddr_t *bdaddr, const char *address_text)
{
    if (bdaddr == NULL || address_text == NULL) {
        return;
    }

    g_call.remote_bdaddr = *bdaddr;
    memset(g_call.remote_address_text, 0, sizeof(g_call.remote_address_text));
    memcpy(g_call.remote_address_text, address_text, strlen(address_text));
    g_call.remote_present = 1;
}

static void bt_call_clear_remote(void)
{
    memset(&g_call.remote_bdaddr, 0, sizeof(g_call.remote_bdaddr));
    memset(g_call.remote_address_text, 0, sizeof(g_call.remote_address_text));
    g_call.remote_present = 0;
}

void bt_call_init(void)
{
    memset(&g_call, 0, sizeof(g_call));
    g_call.state = BT_CALL_STATE_IDLE;
}

bt_call_state_t bt_call_get_state(void)
{
    return g_call.state;
}

const char *bt_call_state_to_text(bt_call_state_t state)
{
    switch (state) {
        case BT_CALL_STATE_IDLE:
            return "idle";
        case BT_CALL_STATE_OUTGOING_DIALING:
            return "outgoing-dialing";
        case BT_CALL_STATE_INCOMING_RINGING:
            return "incoming-ringing";
        case BT_CALL_STATE_ACTIVE:
            return "active";
        default:
            return "unknown";
    }
}

int bt_call_dial_address_text(const char *address_text)
{
    bt_bdaddr_t bdaddr;

    if (g_call.state != BT_CALL_STATE_IDLE) {
        errno = EBUSY;
        return -1;
    }

    if (bt_call_parse_bdaddr_text(address_text, &bdaddr) < 0) {
        return -1;
    }

    bt_call_set_remote(&bdaddr, address_text);
    g_call.state = BT_CALL_STATE_OUTGOING_DIALING;

    bt_log_info("Outgoing call created for %s", g_call.remote_address_text);
    bt_log_warn("Call media and HFP/HSP signaling hooks are not implemented yet");
    return 0;
}

int bt_call_incoming_address_text(const char *address_text)
{
    bt_bdaddr_t bdaddr;

    if (g_call.state != BT_CALL_STATE_IDLE) {
        errno = EBUSY;
        return -1;
    }

    if (bt_call_parse_bdaddr_text(address_text, &bdaddr) < 0) {
        return -1;
    }

    bt_call_set_remote(&bdaddr, address_text);
    g_call.state = BT_CALL_STATE_INCOMING_RINGING;

    bt_log_info("Incoming call presented from %s", g_call.remote_address_text);
    return 0;
}

int bt_call_answer(void)
{
    if (g_call.state != BT_CALL_STATE_INCOMING_RINGING &&
        g_call.state != BT_CALL_STATE_OUTGOING_DIALING) {
        errno = EINVAL;
        return -1;
    }

    g_call.state = BT_CALL_STATE_ACTIVE;
    bt_log_info("Call answered with %s", g_call.remote_present ? g_call.remote_address_text : "<unknown>");
    bt_log_warn("Audio routing over SCO/eSCO is not implemented yet");
    return 0;
}

int bt_call_reject(void)
{
    if (g_call.state != BT_CALL_STATE_INCOMING_RINGING) {
        errno = EINVAL;
        return -1;
    }

    bt_log_info("Incoming call rejected from %s", g_call.remote_present ? g_call.remote_address_text : "<unknown>");
    g_call.state = BT_CALL_STATE_IDLE;
    bt_call_clear_remote();
    return 0;
}

int bt_call_hangup(void)
{
    if (g_call.state == BT_CALL_STATE_IDLE) {
        errno = EINVAL;
        return -1;
    }

    bt_log_info("Call ended with %s", g_call.remote_present ? g_call.remote_address_text : "<unknown>");
    g_call.state = BT_CALL_STATE_IDLE;
    bt_call_clear_remote();
    return 0;
}

void bt_call_print_status(void)
{
    printf("Call State      : %s\n", bt_call_state_to_text(g_call.state));
    if (g_call.remote_present) {
        printf("Call Remote     : %s\n", g_call.remote_address_text);
    } else {
        printf("Call Remote     : <none>\n");
    }
}
