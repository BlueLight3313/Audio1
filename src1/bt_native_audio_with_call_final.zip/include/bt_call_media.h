#ifndef BT_CALL_MEDIA_H
#define BT_CALL_MEDIA_H

#include "bt_types.h"

int bt_call_media_start(const bt_bdaddr_t *bdaddr);
void bt_call_media_stop(void);

#endif
