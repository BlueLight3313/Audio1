#include <errno.h>
#include <string.h>

#include "bt_defs.h"
#include "bt_types.h"
#include "bt_hci.h"
#include "bt_connect.h"
#include "bt_log.h"

#define BT_OGF_LINK_CTL             0x01
#define BT_OCF_CREATE_CONN          0x0005

#define BT_CREATE_CONN_PKT_TYPE     0xCC18
#define BT_ROLE_SWITCH_ALLOWED      0x01
#define BT_DEFAULT_PAGE_SCAN_MODE   0x00

int bt_connect_device(int hci_sock, const struct bt_device_record *device)
{
    struct bt_hci_cp_create_conn cp;

    if (device == NULL) {
        errno = EINVAL;
        return -1;
    }

    memset(&cp, 0, sizeof(cp));
    cp.bdaddr = device->bdaddr;
    cp.pkt_type = bt_hci_cpu_to_le16(BT_CREATE_CONN_PKT_TYPE);
    cp.page_scan_rep_mode = device->page_scan_rep_mode;
    cp.reserved = BT_DEFAULT_PAGE_SCAN_MODE;
    cp.clock_offset = bt_hci_cpu_to_le16(device->clock_offset);
    cp.allow_role_switch = BT_ROLE_SWITCH_ALLOWED;

    bt_log_info(
        "Connecting to device %s (page_scan_rep_mode=0x%02X, clock_offset=0x%04X)",
        device->address_text,
        device->page_scan_rep_mode,
        device->clock_offset
    );

    if (bt_hci_send_req(
            hci_sock,
            BT_HCI_OPCODE(BT_OGF_LINK_CTL, BT_OCF_CREATE_CONN),
            &cp,
            sizeof(cp),
            NULL,
            0,
            5000) < 0) {
        bt_log_error("Connection request failed: %s", strerror(errno));
        return -1;
    }

    bt_log_info("Connection request accepted by controller");
    return 0;
}
