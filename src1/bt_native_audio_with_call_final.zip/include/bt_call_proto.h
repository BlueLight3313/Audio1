
#ifndef BT_CALL_PROTO_H
#define BT_CALL_PROTO_H
#define BT_CALL_MSG_DIAL 1
#define BT_CALL_MSG_ACCEPT 2
#define BT_CALL_MSG_REJECT 3
#define BT_CALL_MSG_HANGUP 4
#define BT_CALL_MSG_IDENTITY 5
typedef struct { int type; char payload[256]; } bt_call_packet_t;
#endif
