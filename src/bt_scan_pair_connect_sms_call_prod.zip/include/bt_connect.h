#ifndef BT_CONNECT_H
#define BT_CONNECT_H

#include "bt_common.h"

bt_connect_result_t bt_connect_bredr_generic(int adapter_index, const char *mac,
                                             int verify_timeout_ms,
                                             int hold_ms);

#endif
